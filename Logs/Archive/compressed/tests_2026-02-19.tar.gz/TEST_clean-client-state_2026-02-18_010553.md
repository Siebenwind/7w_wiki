---
uuid: bb0ca72d-7a07-4591-ae99-143d3cc2837a
status: PASS
created_at: 2026-02-18T00:05:53Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.50s | Mittel 0.19s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.47 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.06 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.07 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.48 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.11 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.10 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.11 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.10 | ok |

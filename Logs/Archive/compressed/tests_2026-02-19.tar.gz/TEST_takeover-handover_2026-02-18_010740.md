---
uuid: b39aebf6-596f-41c8-b981-a514d740a2aa
status: PASS
created_at: 2026-02-18T00:07:40Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **PASS**
- PASS: 5 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.01s | Mittel 0.20s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.06 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.06 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.06 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 0.43 | ok |
| `audit-reporting` | Audit command runs and reports current state | PASS | 1 | 0.41 | ok |

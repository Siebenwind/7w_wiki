---
uuid: 801a5cb6-ac2d-4ad3-9a5c-bb012d245d5b
status: PASS
created_at: 2026-02-17T22:50:50Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.15s | Mittel 0.27s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.69 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.09 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.64 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.17 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.17 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.15 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.16 | ok |

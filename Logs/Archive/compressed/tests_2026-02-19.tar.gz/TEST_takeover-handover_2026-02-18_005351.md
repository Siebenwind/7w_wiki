---
uuid: 96d1ae06-d0e9-4b8d-9207-94e4a4b15494
status: PASS
created_at: 2026-02-17T23:53:51Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **PASS**
- PASS: 5 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.51s | Mittel 0.50s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.14 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.19 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.11 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 1.02 | ok |
| `audit-reporting` | Audit command runs and reports current state | PASS | 1 | 1.04 | ok |

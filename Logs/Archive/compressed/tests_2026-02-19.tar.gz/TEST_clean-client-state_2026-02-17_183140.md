---
uuid: 46760df5-876e-459a-8f00-632c22be51e2
status: PASS
created_at: 2026-02-17T17:31:40Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.31s | Mittel 0.16s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.40 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.05 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.05 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.39 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.10 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.10 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.10 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.11 | ok |

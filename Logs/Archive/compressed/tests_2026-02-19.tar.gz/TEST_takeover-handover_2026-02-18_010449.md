---
uuid: abe68c19-0b18-4506-a8e8-c09e80b56379
status: PASS
created_at: 2026-02-18T00:04:49Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **PASS**
- PASS: 5 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.12s | Mittel 0.22s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.06 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.05 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.05 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 0.50 | ok |
| `audit-reporting` | Audit command runs and reports current state | PASS | 1 | 0.45 | ok |

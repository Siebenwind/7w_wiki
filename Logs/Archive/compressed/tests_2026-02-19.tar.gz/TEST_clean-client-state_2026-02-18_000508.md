---
uuid: 140771e6-debc-425e-97aa-9a767fc8bbd0
status: PASS
created_at: 2026-02-17T23:05:08Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.43s | Mittel 0.43s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.07 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.15 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.14 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.77 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.32 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.30 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.29 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.40 | ok |

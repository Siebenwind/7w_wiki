---
uuid: c024c603-c8ee-4ec0-ae94-b0c24c2be643
status: FAIL
created_at: 2026-02-17T21:01:58Z
epistemic: "#meta"
---

# Test Run Report: interop-doc-links

- Suite-Datei: `.agent/tests/suites/interop-doc-links.json`
- Ergebnis: **FAIL**
- PASS: 0 | FAIL: 1 | SKIP: 0
- Laufzeit (gemessen): Summe 0.00s | Mittel 0.00s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `core-link-integrity` | Core interop/testing docs have resolvable local markdown links | FAIL | 1 | 0.00 | Broken links: .agent/workflows/handover.md -> ../... |

## FAIL: core-link-integrity - Core interop/testing docs have resolvable local markdown links

- Kommando: `link-check AGENTS.md .agent/workflows/start.md .agent/workflows/takeover.md .agent/workflows/handover.md .agent/workflows/test_run.md System/Synapse_Board/SY_INTEROP.md System/Synapse_Board/SY_WORKFLOW_CLI_MATRIX.md System/Synapse_Board/SY_TESTING.md System/AGENT_OPERATIONS_HANDBOOK.md System/COORDINATION_HUB.md`
- Laufzeit: 0.00s
- Grund: Broken links: .agent/workflows/handover.md -> ../...

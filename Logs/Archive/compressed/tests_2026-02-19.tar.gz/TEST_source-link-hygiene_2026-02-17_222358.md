---
uuid: c30699fe-ae36-4c9b-9455-b344f03b3b2e
status: FAIL
created_at: 2026-02-17T21:23:58Z
epistemic: "#meta"
---

# Test Run Report: source-link-hygiene

- Suite-Datei: `.agent/tests/suites/source-link-hygiene.json`
- Ergebnis: **FAIL**
- PASS: 0 | FAIL: 1 | SKIP: 0
- Laufzeit (gemessen): Summe 0.01s | Mittel 0.01s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `no-source-link-regressions` | No double-encoded, file://, or [[index]]-placeholder markdown source links | FAIL | 1 | 0.01 | Ungueltiger Regex '\\\\]\\\\([^)]*%25[0-9A-Fa-f]{2}': missing ), unterminated subpattern at position 5 |

## FAIL: no-source-link-regressions - No double-encoded, file://, or [[index]]-placeholder markdown source links

- Kommando: `pattern-check Siebenwind_Wiki/**/*.md Logs/Ingestion/*.md docs/COORDINATION_HUB.md`
- Laufzeit: 0.01s
- Grund: Ungueltiger Regex '\\\\]\\\\([^)]*%25[0-9A-Fa-f]{2}': missing ), unterminated subpattern at position 5

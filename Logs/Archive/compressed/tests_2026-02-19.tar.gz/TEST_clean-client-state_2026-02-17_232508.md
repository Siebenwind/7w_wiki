---
uuid: 6c2b8c93-40b1-469a-8259-9b6fef69ed81
status: PASS
created_at: 2026-02-17T22:25:08Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.07s | Mittel 0.26s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.62 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.09 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.62 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.16 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.16 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.16 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.17 | ok |

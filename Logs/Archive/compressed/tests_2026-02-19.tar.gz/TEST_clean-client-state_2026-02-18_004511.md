---
uuid: 5c355e33-3992-438f-88cd-8c1dde0ef091
status: PASS
created_at: 2026-02-17T23:45:11Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.70s | Mittel 0.46s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.40 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.12 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.12 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 1.17 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.22 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.23 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.22 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.22 | ok |

---
uuid: c2fa969b-2d6a-4402-a621-ebcac411dc15
status: PASS
created_at: 2026-02-17T22:50:32Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.33s | Mittel 0.42s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.80 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.12 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.17 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.79 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.30 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.23 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.29 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.63 | ok |

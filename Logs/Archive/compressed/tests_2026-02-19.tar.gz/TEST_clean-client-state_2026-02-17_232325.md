---
uuid: 51eff313-27f7-48de-b2a6-58c05a6aa829
status: PASS
created_at: 2026-02-17T22:23:25Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.30s | Mittel 0.29s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.67 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.13 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.11 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.64 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.18 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.19 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.20 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.17 | ok |

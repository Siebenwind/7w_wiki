---
uuid: baa8d13c-4746-49fe-b3e6-7cef820a48a4
status: PASS
created_at: 2026-02-17T22:59:59Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.09s | Mittel 0.39s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.21 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.10 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.79 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.23 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.26 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.21 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.20 | ok |

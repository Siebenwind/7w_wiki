---
uuid: 0306a5ce-9831-4827-9d8c-2a9168acb557
status: PASS
created_at: 2026-02-17T23:50:01Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.03s | Mittel 0.38s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.20 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.08 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.12 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.89 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.20 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.18 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.18 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.18 | ok |

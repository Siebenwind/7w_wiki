---
uuid: 26d2a691-3727-447a-a6fe-45034e746d7c
status: PASS
created_at: 2026-02-17T21:02:00Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.05s | Mittel 0.13s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.30 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.05 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.05 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.29 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.09 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.09 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.09 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.09 | ok |

---
uuid: 51f5635f-7d7d-443e-879f-c36f140a9fb7
status: FAIL
created_at: 2026-02-17T15:25:12Z
epistemic: "#meta"
---

# Test Run Report: rag-relevance-smoke

- Suite-Datei: `.agent/tests/suites/rag-relevance-smoke.json`
- Ergebnis: **FAIL**
- PASS: 0 | FAIL: 4 | SKIP: 0
- Laufzeit (gemessen): Summe 124.21s | Mittel 31.05s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `rag-status` | Index status reports coverage and writes archive register | FAIL | 1 | 16.75 | Exitcode 1 != erwartet 0 |
| `rag-q-dunvallo` | Query Dunvallo Linari retrieves core person article | FAIL | 0 | 38.42 | stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md' |
| `rag-q-matrix` | Query Matrixtheorie Linari retrieves matrix article | FAIL | 0 | 34.72 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md' |
| `rag-q-reagenzien` | Query Reagenzien Lehre Linari retrieves reagent article | FAIL | 0 | 34.32 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md' |

## FAIL: rag-status - Index status reports coverage and writes archive register

- Kommando: `./7w_wiki.py index --status`
- Laufzeit: 16.75s
- Grund: Exitcode 1 != erwartet 0

```text
⚠️  Config-Pfad /Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json nicht lesbar oder fehlerhaft (Permission oder Format): [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json'
📋 Config geladen: MPS (Batch: 4) aus .agent/config/runtime.json
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Indexierung                       ║
╚═══════════════════════════════════════════════════╝
  Repo:        /Users/alexandrerabe/siebenwind/7w_wiki
  Chunk-Größe: 2500 Zeichen (~357 Token)
  Modell:      jinaai/jina-embeddings-v3
  Modus:       ⚡ INKREMENTELL

  📊 Index-Status:
     siebenwind_quellen: 60151 Chunks | 288/300 Dateien (96.00% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
     siebenwind_wiki: 31700 Chunks | 157/1110 Dateien (14.14% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
Error executing .agent/skills/oracle/build_index.py: Command '['/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/venv/bin/python3', '/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py', '--status']' returned non-zero exit status 1.
```

```text
Traceback (most recent call last):
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1152, in <module>
    main()
    ~~~~^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1085, in main
    payload, md_path, json_path = build_archive_register(rag_progress)
                                  ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 335, in build_archive_register
    rec = _register_record_for_file(corpus, path)
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 289, in _register_record_for_file
    if path.suffix.lower() not in REGISTER_EXTENSIONS or not path.is_file():
                                                             ~~~~~~~~~~~~^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_abc.py", line 482, in is_file
    return S_ISREG(self.stat(follow_symlinks=follow_symlinks).st_mode)
                   ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_local.py", line 515, in stat
    return os.stat(self, follow_symlinks=follow_symlinks)
           ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PermissionError: [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/System/DELEGATION_CODEX_PHASE_20.md'
```

## FAIL: rag-q-dunvallo - Query Dunvallo Linari retrieves core person article

- Kommando: `./7w_wiki.py search Dunvallo Linari --source wiki`
- Laufzeit: 38.42s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Dunvallo Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 28.4s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 95/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 96/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 94/201 (206 Zeichen)
   ", Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 92/201 (208 Zeichen)
   "ll, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 91/201 (209 Zeichen)
   "all, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 98/201 (202 Zeichen)
   "hensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 99/201 (201 Zeichen)
   "ensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 100/201 (200 Zeichen)
   "nsvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Harwarn_Gropp]], [[Hagen_Robaar]], [[Luther_Dueff]], [[Falkenwall]], [[Benion_Sandelholz]]
   Chunk: 0/201 (2430 Zeichen)
   "# Siebenwind Bote 140

**Epistemischer Status:** #bote
**Datum:** 18. Querler 16 n.H.

## Überblick
Diese Ausgabe berichtet von der Gründung eines neuen Laienordens, einem bevorstehenden Schützenfest und der Hinrichtung eines berüchtigten Verbrechers. Zudem wird eine offizielle Liste der Lehensvasallen und Ritter von [[Siebenwind]] veröffentlicht.

## Wichtige Ereignisse
### Gründung des Ordens der Tränen Vitamas
Der Hochgeweihte **[[Benion_Sandelholz]]** (ehemals Abt des Ordo Vitamas) hat den [[Orden_der_Traenen_Vitamas]] ins Leben gerufen. Es handelt sich um einen Laienorden, der sich dem Mi..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Cavalaron_Vendell]], [[Laurec_Llewellyen]], [[Isgrim]], [[Ovelia_Galthana]], [[Luther_Dueff]]
   Chunk: 28/201 (273 Zeichen)
   "Sandelholz]]
*   [[Isgrim]]
*   [[Laurec_Llewellyen]]
*   [[Luther_Dueff]]
*   [[Ovelia_Galthana]]
*   [[Cavalaron_Vendell]]
*   [[Orden_der_Traenen_Vitamas]]

## Referenzen
- Primärquelle: [Siebenwind Bote 140](../../Quellen/Zeitung%207w%20Bote/Siebenwind%20Bote%20140.md)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 101/201 (199 Zeichen)
   "svasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 87/201 (213 Zeichen)
   "rschall, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_193.md
   Kategorie: Chronik | Entitäten: [[Custodias]], [[Claiomhs_Wacht]], [[Splitterfelsen]], [[Geduldiger_Sand]], [[Aschehorn]]
   Chunk: 0/201 (2176 Zeichen)
   "# Siebenwind Bote 193

**Epistemischer Status:** #bote
**Datum:** 17. Carmer 30 n.H.

## Überblick
Diese Ausgabe berichtet von einem Durchbruch bei den Friedensverhandlungen mit dem Lindwurm Akassvae, dem Erscheinen neuer drakonischer Bedrohungen und politischen Veränderungen in Dunquell.

## Die Lindwurm-Krise
### Friedensschluss mit Akassvae
Der Erzgeweihte **[[Custodias]]** führte erfolgreiche Verhandlungen mit dem grünen Lindwurm **[[Akassvae]]** und dem Echsen-Erdrufer **[[Geduldiger_Sand]]** in ihrer Feste in den [[Splitterfelsen]]. 
*   **Das Abkommen:** Akassvae und die ihr folgenden E..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 2/201 (298 Zeichen)
   "hekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 3/201 (297 Zeichen)
   "ekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 4/201 (296 Zeichen)
   "kar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 7/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 8/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Handelsbund]], [[Benion_Sandelholz]], [[Chronik]]
   Chunk: 11/201 (289 Zeichen)
   "ldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 5/201 (295 Zeichen)
   "ar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"
```

```text
2026-02-17 16:23:39.438 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_39-34885680‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:39.580 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_39-4111812276‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:39.670 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_39-4165467690‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:39.748 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_39-959490838‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:41.047 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_41-2598794519‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:41.292 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_41-1985540789‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:41.812 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_41-3144335554‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.038 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-1906866168‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.178 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-3495345167‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.262 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-717601805‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.373 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-3545250505‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.586 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-334716519‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.671 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-2519258026‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.723 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-140849768‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.878 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-373232230‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:42.985 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_42-2893329707‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:43.084 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_43-2648743975‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:43.091 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_43-1798523762‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:43.460 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_43-1939633569‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:44.158 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_44-2402588205‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:44.303 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_44-1597860845‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:52.229 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_52-3485502023‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:52.324 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_52-476697782‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:52.393 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_52-1676571726‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.282 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-1706126999‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.359 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-2558817381‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.364 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-3906747201‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.484 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-3485677027‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.575 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-3902874271‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.591 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-90442586‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.696 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-127322192‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:53.936 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_53-1935578400‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:54.115 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_54-2738617337‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:54.839 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_54-4224387901‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:56.616 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_56-1345499951‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:23:56.924 Python[69659:5265607] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69659-2026-02-17_16_23_56-3700467479‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-matrix - Query Matrixtheorie Linari retrieves matrix article

- Kommando: `./7w_wiki.py search Matrixtheorie Linari --source wiki`
- Laufzeit: 34.72s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Matrixtheorie Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 24.2s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Ventus]], [[Zwerge]], [[Vitama]]
   Chunk: 6/207 (2325 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Themen | [DEFINITION_BENÖTIGT] | #canon |
| Tiefenwald | [DEFINITION_BENÖTIGT] | #canon |
| Timeline | [DEFINITION_BENÖTIGT] | #canon |
| Tintin | [DEFINITION_BENÖTIGT] | #canon |
| Tion | [DEFINITION_BENÖTIGT] | #canon |
| Titel | [DEFINITION_BENÖTIGT] | #canon |
| Vandrien | [DEFINITION_BENÖTIGT] | #canon |
| Vencurius | [DEFINITION_BENÖTIGT] | #canon |
| [[Ventus]] | [DEFINITION_BENÖTIGT] | #canon |
| Verbindung | [DEFINITION_BENÖTIGT] | #canon |
| Verehrung | [DEFINITION_BENÖTIGT] | #canon |
| Verlinkte | [DEFINITION_BENÖTIGT] | #canon |
| Verwaltung | [D..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Angamon]], [[Xan]], [[Aequilibrium]]
   Chunk: 43/201 (257 Zeichen)
   "t.
*   [[Xan]] - Magie.

## Die Gegenspieler
*   [[Angamon]] - Der Dämonenfürst.

## Religionsphilosophie
*   [[Aequilibrium]] - Über den Dualismus und das göttliche Gleichgewicht.
*   [[Götter_und_Götzen]] - Abgrenzung der Viere von fremden Glaubensformen."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 14/201 (286 Zeichen)
   "e" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Aequilibrium.md
   Kategorie: Religion | Entitäten: [[Vitama]], [[Daemonen]], [[Untote]], [[Tare]], [[Codex_Astraeli]]
   Chunk: 0/201 (2189 Zeichen)
   "# Aequilibrium

**Epistemischer Status:** #überlieferung
**Autor:** [[Donarius_Derrvus]], Hochgeweihter des Ordo Astraeli
**Vollständiger Titel:** *Aequilibrium - Philosophie des Gleichgewichts das Tor des Bösen in unsere Sphäre?*

Das Werk **Aequilibrium** ist eine kritische Auseinandersetzung mit der "Theorie des Gleichgewichts", wie sie unter Druiden, Hexen, [[Elfen]] und Elementaristen verbreitet ist. Der Autor [[Donarius_Derrvus]] untersucht drei verschiedene Ebenen des Gleichgewichts und bewertet sie aus Sicht der [[Kirche_der_Viere]].

## Die drei Ebenen des Gleichgewichts

### 1. Das G..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 13/201 (287 Zeichen)
   "se" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 15/201 (285 Zeichen)
   "" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 16/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 17/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 20/201 (280 Zeichen)
   "lismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 9/201 (291 Zeichen)
   ". Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 5/201 (295 Zeichen)
   "t vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 10/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 11/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 4/201 (296 Zeichen)
   "ut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 6/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 7/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 1/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 2/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."
```

```text
2026-02-17 16:24:16.263 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_16-3723904017‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:16.356 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_16-4129442983‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:16.438 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_16-907493549‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:16.510 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_16-2740670829‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:17.742 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_17-863475078‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:17.976 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_17-1325783986‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.246 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-939265767‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.438 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-2759572367‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.554 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-2526723207‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.636 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-249012769‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.736 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-3137308843‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.836 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-3976695976‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.907 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-682452034‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:18.953 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_18-2407734645‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:19.077 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_19-4034062128‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:19.170 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_19-2576126916‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:19.267 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_19-1461468431‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:19.270 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_19-3226878791‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:19.379 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_19-2662171713‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:20.038 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_20-416219778‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:20.202 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_20-828062947‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:27.384 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_27-569472146‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:27.462 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_27-2711380700‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:27.522 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_27-1152874998‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:28.417 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_28-2362868457‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:28.487 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_28-313000695‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:28.492 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_28-1843640205‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:28.584 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_28-2510422787‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:28.672 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_28-4164760678‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:28.686 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_28-165579874‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:28.782 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_28-676692001‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:29.055 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_29-1219734925‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:29.269 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_29-2270784202‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:30.058 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_30-1781776187‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:31.850 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_31-1482695753‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:32.187 Python[69668:5266212] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-69668-2026-02-17_16_24_32-334731811‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-reagenzien - Query Reagenzien Lehre Linari retrieves reagent article

- Kommando: `./7w_wiki.py search Reagenzien Lehre Linari --source wiki`
- Laufzeit: 34.32s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Reagenzien Lehre Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 24.5s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magie_Grundlagen.md
   Kategorie: Fundament | Entitäten: [[Graumagie|Grauer Pfad]], [[Xan]], [[Brandenstein]], [[Ordo_Vitamae]], [[Sphärenkunde]]
   Chunk: 0/201 (1904 Zeichen)
   "# Magie Grundlagen

**Epistemischer Status:** #canon

Die Theorie der Magie auf [[Tare]] ist eine jahrtausendealte Wissenschaft, die das Verständnis der Elemente, der Sphären und der inneren Kraft des Geistes vereint.

## Die Quellen der Macht
### 1. Elementarmagie
Die rohe Magie wird durch die vier **[[Die_Gohor|Ur-Elemente]]** und ihre elementaren Herrscher ([[Enhor]]) gespeist:
*   **[[Ignis]] (Feuer):** Kraft der Zerstörung und radikalen Wandlung.
*   **[[Rien]] (Erde/Natur):** Kraft des Wachstums und der materiellen Stabilität.
*   **[[Ventus]] (Luft):** Kraft der Bewegung, des Schalls un..."

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Morsan]], [[Tare]], [[Astrael]], [[Dur]]
   Chunk: 0/202 (2333 Zeichen)
   "# Magietheorie (Toran [[Dur]])

**Epistemischer Status:** #überlieferung
**Autor:** Hochmagus Toran [[Dur]]
**Datum:** 26 n.H.

Dieser Artikel fasst die zentralen Lehren von Hochmagus Toran [[Dur]] zusammen, wie sie an der königlichen Akademie gelehrt werden. Er definiert Magie als die Manipulation des **Astralen Netzes** durch den sterblichen Geist.

## Definition und Ursprung
Magie gilt als eine der drei fundamentalen Konstanten der Existenz (neben Raum und Zeit). Während der Volksglaube [[Astrael]] als Schöpfer der Magie sieht, lehrt die Akademie, dass [[Astrael]] den Sterblichen lediglich..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 1/202 (850 Zeichen)
   "Lebewesen als Einheiten von **Aurenzentren** und Strömen. Die Summe dieser Ströme bildet die **Aura**.

### Theorie der größeren Ströme
Beschreibt magische Energieströme auf kontinentaler Ebene. Die Konvergenz dieser Ströme beeinflusst die Haltbarkeit von Zaubern und die Effektivität von Ritualen.

## Ritualkunde
Rituale lagern Komponenten der Magie auf Hilfsmittel (**Paraphernalia**) aus:
- **Anker:** (z.B. Edelsteine, Salz) zur Festigung von Geweben.
- **Foki:** (z.B. Lupen, Kerzen) zur Konzentration von Effekten.
- **Speicher:** (z.B. Arkanium) zum Sammeln astraler Kraft.

### Kreise
- **Ba..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Sorania]], [[Rien]], [[Tare]], [[Südfall]], [[Telandrion]]
   Chunk: 5/207 (2478 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Region | [DEFINITION_BENÖTIGT] | #canon |
| Regionen | [DEFINITION_BENÖTIGT] | #canon |
| Reich | [DEFINITION_BENÖTIGT] | #canon |
| Reiches | [DEFINITION_BENÖTIGT] | #canon |
| Reise | [DEFINITION_BENÖTIGT] | #canon |
| Religion | [DEFINITION_BENÖTIGT] | #canon |
| Richter | [DEFINITION_BENÖTIGT] | #canon |
| [[Rien]] | [DEFINITION_BENÖTIGT] | #canon |
| Ritter | [DEFINITION_BENÖTIGT] | #canon |
| Robaar | [DEFINITION_BENÖTIGT] | #canon |
| Rolle | [DEFINITION_BENÖTIGT] | #canon |
| Rothschild | [DEFINITION_BENÖTIGT] | #canon |
| Ruhe | [DEFINITION_BENÖTIGT]..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 107/202 (194 Zeichen)
   "reis:** Hält Einflüsse fern.
Beide nutzen die *Aversität* der Elemente (z.B. Feuer gegen Wasser), um Barrieren zu errichten.

## Siehe auch
- [[Das_Fundament]]
- [[Codex_Astraeli]]
- [[Astrael]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 148/201 (152 Zeichen)
   "xistenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 149/201 (151 Zeichen)
   "istenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Astrael.md
   Entitäten: [[Magie_Grundlagen]], [[Religion_Übersicht]], [[Die_Viere_Kirche]]
   Chunk: 164/200 (136 Zeichen)
   "ionen durch Verstand geleitet werden müssen.

## Verwandte Themen
- [[Religion_Übersicht]]
- [[Die_Viere_Kirche]]
- [[Magie_Grundlagen]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 154/201 (146 Zeichen)
   "z. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 155/201 (145 Zeichen)
   ". Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 152/201 (148 Zeichen)
   "enz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 145/201 (155 Zeichen)
   "r Existenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 153/201 (147 Zeichen)
   "nz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 151/201 (149 Zeichen)
   "tenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 150/201 (150 Zeichen)
   "stenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 15/201 (285 Zeichen)
   "rp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 4/201 (296 Zeichen)
   "le
*   **Corp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 33/201 (267 Zeichen)
   "r:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"
```

```text
2026-02-17 16:24:50.151 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_50-1534295052‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:50.252 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_50-1042804858‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:50.346 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_50-2117079613‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:50.412 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_50-2192644624‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:51.553 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_51-3736837958‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:51.790 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_51-612229124‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.017 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-943960305‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.225 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-2740651442‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.356 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-1376545697‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.444 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-2191594557‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.554 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-597277066‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.665 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-1929002611‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.744 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-2782805856‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.799 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-99215656‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:52.917 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_52-664021892‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:53.019 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_53-1954843381‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:53.121 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_53-3515674832‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:53.222 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_53-1873850738‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:53.316 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_53-2919275346‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:53.994 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_53-15851720‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:24:54.135 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_24_54-2369904699‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:01.696 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_01-3052086934‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:01.793 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_01-2080838962‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:01.867 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_01-85072292‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:02.794 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_02-615902977‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:02.870 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_02-478076446‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:02.875 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_02-1412292677‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:02.968 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_02-2600578900‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:03.044 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_03-2616632744‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:03.056 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_03-1425607932‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:03.133 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_03-1979913577‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:03.377 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_03-1664506087‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:03.570 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_03-63878816‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:04.271 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_04-1813800344‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:06.051 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_06-2825737599‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 16:25:06.393 Python[70327:5267595] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-70327-2026-02-17_16_25_06-442042546‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

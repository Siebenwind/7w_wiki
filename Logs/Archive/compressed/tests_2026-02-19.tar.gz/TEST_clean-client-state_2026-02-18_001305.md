---
uuid: 6ad4ee45-f016-4c9b-9e4c-df5976d5bc07
status: PASS
created_at: 2026-02-17T23:13:05Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.59s | Mittel 0.32s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.81 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.11 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.71 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.19 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.21 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.24 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.24 | ok |

---
uuid: 97b8f852-8d38-4991-8f81-384b774b57b9
status: PASS
created_at: 2026-02-17T22:16:25Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.33s | Mittel 0.29s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.82 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.10 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.59 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.19 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.20 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.17 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.17 | ok |

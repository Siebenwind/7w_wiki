---
uuid: 206cfb12-a4f3-4e1f-9d5f-4e2a788485c3
status: PASS
created_at: 2026-02-16T23:27:25Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 0.95s | Mittel 0.12s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.18 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.07 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.07 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.13 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.10 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.11 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.12 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.17 | ok |

---
uuid: 839ed55e-a37e-40ec-b238-749feb2aed2b
status: PASS
created_at: 2026-02-17T21:47:02Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.20s | Mittel 0.15s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.37 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.05 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.05 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.33 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.10 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.10 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.10 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.10 | ok |

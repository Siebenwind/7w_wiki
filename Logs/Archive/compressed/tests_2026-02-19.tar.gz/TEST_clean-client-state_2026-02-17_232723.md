---
uuid: 74900a98-f2f2-474e-83d2-62219c5da94b
status: PASS
created_at: 2026-02-17T22:27:23Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.08s | Mittel 0.26s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.66 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.09 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.08 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.58 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.18 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.18 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.15 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.15 | ok |

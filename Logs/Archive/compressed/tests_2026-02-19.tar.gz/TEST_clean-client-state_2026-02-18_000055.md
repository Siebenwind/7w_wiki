---
uuid: 7990fbc8-6187-4f58-bc96-fdb1c6a409f9
status: PASS
created_at: 2026-02-17T23:00:55Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.83s | Mittel 0.35s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.82 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.10 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.12 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.92 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.27 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.20 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.21 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.20 | ok |

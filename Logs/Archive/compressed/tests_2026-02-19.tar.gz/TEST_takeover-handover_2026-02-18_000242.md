---
uuid: cf37babe-ac3c-4cc8-a103-323a85d601ce
status: FAIL
created_at: 2026-02-17T23:02:42Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **FAIL**
- PASS: 4 | FAIL: 1 | SKIP: 0
- Laufzeit (gemessen): Summe 3.20s | Mittel 0.64s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.26 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.27 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.24 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 1.30 | ok |
| `audit-readiness` | Audit still passes | FAIL | 1 | 1.13 | Exitcode 1 != erwartet 0 |

## FAIL: audit-readiness - Audit still passes

- Kommando: `./7w_wiki.py audit`
- Laufzeit: 1.13s
- Grund: Exitcode 1 != erwartet 0

```text
============================================================
  SIEBENWIND WIKI — REGISTER-CHECK
  Report-ID: e113291c-5c4c-45ec-91d3-0800c1ce42bd
============================================================

## 1. Duplikate im Personenregister
  ✅ Keine Duplikate gefunden.

## 2. Verwaiste Profile (Datei ohne Register-Eintrag)
  ✅ Alle Profile sind registriert.

## 3. Registrierte Personen ohne Profildatei
  ✅ Alle registrierten Personen haben Profildateien.

## 4. Boten-Lücken (Quellen vorhanden, nicht integriert)
  ✅ Alle verfügbaren Boten sind integriert.

## 5. Index-Lücken (Dateien vorhanden, nicht in Die_Chronik.md)
  ✅ Alle Boten-Dateien sind im Index erfasst.

## 6. Source Link Hygiene (MkDocs Strict Risks)
  ✅ Keine kritischen Source-Link-Muster gefunden.

## 7. Ingestion Tracking & Score Distribution
  Reports gesamt: 54
  Mit Kern-Tracking (Quelle + Wer + Wann): 50
  Mit LQS: 52
  ⚠️  4 Report(s) ohne vollstaendige Tracking-Felder.
    - Logs/Ingestion/2026-02-16_Der_Flug_der_Ente..3.md
    - Logs/Ingestion/2026-02-16_Der_Flug_der_Ente..md
    - Logs/Ingestion/2026-02-16_Der_Flug_der_Ente1.md
    - Logs/Ingestion/2026-02-16_Der_letzte_Falke.md
  LQS-Verteilung: 3:1, 5:2, 7:6, 8:13, 9:14, 10:16
  Profil-Cluster: 3/3/3:29, 3/2/3:17, 3/2/2:2, 2/3/3:1, 2/2/3:1
  ⚠️  Score-Cluster auffaellig eng (Top-Profil 3/3/3 = 29/52).

## 8. Deep WikiLink Check (Internal Integrity)
  ⚠️  Quellen/Spielergeschichten/Abschied_und_Verrat.md:
    - [[Robaar von Saalhorn]] (Missing File)
    - [[Saalhorn]] (Missing File)
  ⚠️  Quellen/Spielergeschichten/Einer Löwin Traum.md:
    - [[Astralebene]] (Missing File)
  ⚠️  Quellen/Spielergeschichten/Einsame Ladengedanken.md:
    - [[Awa]] (Missing File)
    - [[Carmer]] (Missing File)
    - [[Heiltränke]] (Missing File)
  ⚠️  Quellen/Spielergeschichten/Erinnerungen_eines_alternden_Zwergen.md:
    - [[Barzak’dhan]] (Missing File)
    - [[Drachenschwingen]] (Missing File)
    - [[Isgrimm]] (Missing File)
    - [[Jolanda_Herdfeuer]] (Missing File)
    - [[Kudahar]] (Missing File)
    - [[Lorien]] (Missing File)
    - [[Seker]] (Missing File)
  ⚠️  Quellen/Spielergeschichten/Geschichten eines silbernen Adlers.md:
    - [[Iria]] (Missing File)
    - [[Tar_Sala]] (Missing File)
  ⚠️  Quellen/Spielergeschichten/Hannibal Thule.md:
    - [[Morsanschrein]] (Missing File)
    - [[Wolpertinger]] (Missing File)
  ⚠️  Quellen/Spielergeschichten/Jenseits des Walls.md:
    - [[Malthuster]] (Missing File)
  ⚠️  Quellen/Zeitung 7w Bote/Siebenwind Bote 176.md:
    - [[Bruder_Schinderle]] (Missing File)
    - [[Bruder_Zar]] (Missing File)
  ⚠️  Quellen/Zeitung 7w Bote/Siebenwind Bote 178.md:
    - [[Bumpur_Purbier]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Bestiarium_Register.md:
    - [[Djinns]] (Missing File)
    - [[Feuerwesen]] (Missing File)
    - [[Gnome]] (Missing File)
    - [[Kreuzrueckenspinne]] (Missing File)
    - [[Moorlaeuferin]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Bibliotheks_Register.md:
    - [[Die_Maid_vom_Greifenweiher]] (Missing File)
    - [[Ueber_Maerchen_und_Almanache]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Dunkeltief.md:
    - [[Tare’say]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Handwerk_Übersicht.md:
    - [[Wirtschaft_(H&H)]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Link_Test.md:
    - [[Falkensee.md]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Magie_Grundlagen.md:
    - [[Akademie]] (Missing File)
    - [[Gefühlsmagie]] (Missing File)
    - [[Schwarzmagie]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Ordo_Astraeli.md:
    - [[Astraelorden]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Organisationsregister.md:
    - [[Akademie_des_gruenen_Zweiges]] (Missing File)
    - [[Anstalt_fuer_ozeanische_Thaumaturgie]] (Missing File)
    - [[Koenigliche_Kriegerakademie]] (Missing File)
    - [[Kuenstlerakademie]] (Missing File)
    - [[Orden_vom_Roten_Salamander]] (Missing File)
    - [[Ring_der_Wissenden]] (Missing File)
    - [[Schule_der_tausend_Funken]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Personenregister.md:
    - [[01_Enhor]] (Missing File)
    - [[01_Ventus]] (Missing File)
    - [[02_Geografie]] (Missing File)
    - [[Brandestein]] (Missing File)
    - [[Daimonologie und Schwarze [[index]] (Missing File)
    - [[Delarie]] (Missing File)
    - [[Die Ordenssatzung des Ordens vom Wachenden Löwen ([[Toran_Dur]] (Missing File)
    - [[Forschungsberichte ([[Toran_Dur]] (Missing File)
    - [[Rittergarde]] (Missing File)
    - [[Stadtconsula]] (Missing File)
  ⚠️  Siebenwind_Wiki/00_Fundament/Wiki_Style_Guide.md:
    - [[COORDINATION_HUB]] (Missing File)
    - [[SY_STANDARDS]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Aequitas.md:
    - [[Hilgorad_I]] (Missing File)
    - [[Personen_Plinius_Deseglieri]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Angamon.md:
    - [[Das_Daimonicon]] (Missing File)
    - [[Irahfar]] (Missing File)
    - [[Irdirim]] (Missing File)
    - [[Kreaturen]] (Missing File)
    - [[Shag_zor_Ga_Zul]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Codex_Astraeli.md:
    - [[Akademie]] (Missing File)
    - [[Akademie_von_Brandenstein]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Codex_Iuris_Canonici.md:
    - [[Erzconsilium_der_Viere]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Der_Traum_der_Tausend.md:
    - [[Traumformung]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Der_letzte_Falke.md:
    - [[Falkenhorst]] (Missing File)
    - [[Katzchen]] (Missing File)
    - [[Sire_Aspin]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Der_naive_Mensch.md:
    - [[Gottheiten]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Die_Goldenen_Tafeln.md:
    - [[Eisernen Tafeln]] (Missing File)
    - [[Erste_Mutter]] (Missing File)
    - [[Kanath]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Die_Silbernen_Tafeln.md:
    - [[Eiserne_Tafeln]] (Missing File)
    - [[Goldene_Tafeln]] (Missing File)
    - [[Venturia]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Divinum_et_Elementum.md:
    - [[Ventos]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Rien.md:
    - [[20_Rassen_Zwerge]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Thjarek.md:
    - [[Rabainsteine]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Ventus.md:
    - [[21_Rassen_Elfen]] (Missing File)
  ⚠️  Siebenwind_Wiki/01_Pantheon/Von_dem_Boesen.md:
    - [[Rasse_Skaven]] (Missing File)
    - [[Stadtchronik_Rohehafens]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Dwarshim.md:
    - [[Handelskonto]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Feste_Seeberg.md:
    - [[Kaempferschule]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Geografie.md:
    - [[I_Siebenwind]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Bernstein.md:
    - [[Burg Bernstein]] (Missing File)
    - [[Stadt Draconis]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Falkenstein.md:
    - [[Region [[Region_Endophal]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Galadon.md:
    - [[Adelssystem Galadon]] (Missing File)
    - [[Region Taras]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Gerdenwald.md:
    - [[Friedward_von_Gerdenwald]] (Missing File)
    - [[Rasse Halblinge]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Kadamark.md:
    - [[Magie Grauer Pfad]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Kettel.md:
    - [[Rasse Rasse_Zwerge]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Khalandra.md:
    - [[Region Norland]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Morthum.md:
    - [[Gott Morsan]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Ossian.md:
    - [[Insel Siebenwind]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Rothschild.md:
    - [[Stadt Rothenbucht]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Sae.md:
    - [[Gott Angamon]] (Missing File)
    - [[Gott Astrael]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Region_Vandrien.md:
    - [[Religion Der Eine]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Skapenfestung.md:
    - [[Graumagier]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Vänskap.md:
    - [[Havarr]] (Missing File)
  ⚠️  Siebenwind_Wiki/02_Geografie/Ödland.md:
    - [[Angstdämonen]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Communis_Medici.md:
    - [[Orden_der_Viere]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Elfen.md:
    - [[Auren und die Verbreitung der Elfenvölker]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Graue_Garde.md:
    - [[Koenigliche_Magierakademie_zu_Siebenwind]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Grosser_Rat.md:
    - [[Bergheim]] (Missing File)
    - [[Gemeinschaft_der_Elementargläubigen]] (Missing File)
    - [[Landelfen]] (Missing File)
    - [[Lehnsherr]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Halblinge.md:
    - [[Baronie Gerdenwald]] (Missing File)
    - [[Göttin Vitama]] (Missing File)
    - [[Region Hügelau]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Inselrat.md:
    - [[Gesetzeskodex_der_Kronmark]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Kazla.md:
    - [[Bruchenball]] (Missing File)
    - [[Run]] (Missing File)
    - [[Suedviertel]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Kirche_der_Viere.md:
    - [[Region [[Sae]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Koenigliche_Akademie_der_Arkanen_Kuenste.md:
    - [[Magister_Konvent]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Koenigliches_Gericht.md:
    - [[Hüter_des_Grosssiegels_der_Kronmark]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Menschen.md:
    - [[Rasse_Myten]] (Missing File)
    - [[Wichtige Städte]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Orken.md:
    - [[Gott Be'rglum]] (Missing File)
    - [[Gott Ci'rgbus]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Recht_Siebenwinds.md:
    - [[Bürger]] (Missing File)
    - [[Freie]] (Missing File)
    - [[Hörige]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Ritterehre_De_Itinere_Honoris.md:
    - [[Schwertmeister_Tesion]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Sammler.md:
    - [[Galad]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Schattenjaeger.md:
    - [[Calin_Dakar]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Siebenwind_Kronregiment.md:
    - [[Militärwesen]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Tempelwache_Falkensee.md:
    - [[Tempel_der_Viere]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Gesellschaft/Zwerge.md:
    - [[Gott Ignis]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/De_Magica_Angamoniensis_(Kalveron_Dai).md:
    - [[Buckelhausen]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Die_Foki_(Dimiona).md:
    - [[Alt_Galad]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Die_Magie_(Toran_Dur).md:
    - [[Theorien der [[index]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Die_Ordenssatzung_des_Ordens_vom_Wachenden_Loewen_(Toran_Dur).md:
    - [[Orden vom Wachenden Löwen]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Forschungsberichte_(Toran_Dur).md:
    - [[Höhle Niemands]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Graue_Charta_(Zweiter_Entwurf).md:
    - [[Königliche Magierakademie]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Kompendium_der_Voelker_(Garreth_Moss).md:
    - [[Avindrell]] (Missing File)
    - [[Brockental]] (Missing File)
    - [[Buckelhausen]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Kompendium_der_Weissmagie_(Althea_Danea).md:
    - [[Asodayr_I_ahm_Erson]] (Missing File)
    - [[Odalerich_I_ap_Erson]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Lehrbuch_der_Magietheorie_(Toran_Dur).md:
    - [[Die [[index]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Magica_Curativa_(Toran_Dur).md:
    - [[Edomwayr]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/Werke/Schwarze_Ritualmagie_(Thanthul).md:
    - [[Thanthul]] (Missing File)
  ⚠️  Siebenwind_Wiki/03_Wissen/index.md:
    - [[Personen/index]] (Missing File)
    - [[Recht/index]] (Missing File)
    - [[Sprachen/index]] (Missing File)
    - [[Werke/index]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/OOC_TIMELINE.md:
    - [[Bekanntmachungen]] (Missing File)
    - [[News]] (Missing File)
    - [[Newsticker]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_124.md:
    - [[Trinso_Langenbriel]] (Missing File)
    - [[Valerast]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_125.md:
    - [[Auenwald]] (Missing File)
    - [[Hügelwald]] (Missing File)
    - [[Nordforst]] (Missing File)
    - [[Ork]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_127.md:
    - [[Stadtverordnung_Brandenstein]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_128.md:
    - [[Anijane_Salmoranes]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_132.md:
    - [[L.H.]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_133.md:
    - [[Baumwesen]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_134.md:
    - [[Auktionshaus_Graustein]] (Missing File)
    - [[C._Eibenwald]] (Missing File)
    - [[Sire_von_Steiner]] (Missing File)
    - [[Turm_der_Magie]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_137.md:
    - [[Anijane_Salmoranes]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_139.md:
    - [[Sir_Robaar]] (Missing File)
    - [[Sire_Siegfried_Steiner]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_142.md:
    - [[R.G.]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_143.md:
    - [[Sekretarius_al_Wechnett]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_147.md:
    - [[Magierturm]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_148.md:
    - [[A.D.]] (Missing File)
    - [[Daniel_Donares]] (Missing File)
    - [[Jägergilde]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_149.md:
    - [[Foth]] (Missing File)
    - [[Garilko_Wopes]] (Missing File)
    - [[Navarian_Arandal]] (Missing File)
    - [[Whyrrdin]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_151.md:
    - [[Daron]] (Missing File)
    - [[Thar_Sala]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_152.md:
    - [[Ortsrat_Brandenstein]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_158.md:
    - [[Galthana]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_161.md:
    - [[Bagarim]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_162.md:
    - [[Sichelzahngnoll]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_164.md:
    - [[Zimahn_Alni_Balurdan]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_165.md:
    - [[Jannaia_Lavrial]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_167.md:
    - [[Bjoern_Zemand]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_168.md:
    - [[Galadonier]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_171.md:
    - [[Leonard_von_Wolfenbach]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_173.md:
    - [[Taurec_von_Schildtburg]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_174.md:
    - [[Ayleen]] (Missing File)
    - [[Beladriel_Blättertanz]] (Missing File)
    - [[Hagen_Robaar_zu_Saalhorn]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_175.md:
    - [[Baldasti]] (Missing File)
    - [[Bernhardt_Wiesinger]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_176.md:
    - [[Bruder_Schinderle]] (Missing File)
    - [[Bruder_Zar]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_177.md:
    - [[Alarich_Falkenhain]] (Missing File)
    - [[Amriele_Silberfels]] (Missing File)
    - [[Hektor_Steinhauer]] (Missing File)
    - [[Hemalar]] (Missing File)
    - [[Richard_Gropp]] (Missing File)
    - [[Vaenskap]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_178.md:
    - [[Bumpur_Purbier]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_183.md:
    - [[Malthuster_Armee]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_184.md:
    - [[Toron]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_188.md:
    - [[Rhator_zeg]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_190.md:
    - [[Turm_des_Nordwinds]] (Missing File)
    - [[Zerstörung_von_Westhever]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_191.md:
    - [[03_Morsan]] (Missing File)
    - [[Vater_Custodias]] (Missing File)
  ⚠️  Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_194.md:
    - [[Angriff_auf_Brandenstein_36_nH]] (Missing File)
    - [[Herr_Geist]] (Missing File)
    - [[Khyra_Gropp]] (Missing File)
    - [[Tanja_Wolfframm]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Anschlag_auf_den_Handelsbund.md:
    - [[Brandensteiner_Zunft]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Aufstand_in_Wallenburg.md:
    - [[Viereinigkeit]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Aus_dem_Liebesleben_eines_Dichters.md:
    - [[Udor]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Blutschwert.md:
    - [[Benion]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Briefe_aus_der_Ferne.md:
    - [[Aurora]] (Missing File)
    - [[Ekre]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Der_Erlass_des_Koenigs.md:
    - [[Fürstentum_Malthust]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Die_Mazzaremer.md:
    - [[Schwarm]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Die_Spinnenplage_von_Falkensee.md:
    - [[Garde]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Die_Stadtchronik_Rohehafens.md:
    - [[Volkskunde]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Ernennung_Wim_Derfflinger.md:
    - [[Königliches_Gericht]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Geschichte_der_Mondamulette.md:
    - [[Amulettgeister]] (Missing File)
    - [[Stein_der_Macht]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Handelsbundturnier_15_nH_Ergebnisse.md:
    - [[Handelsbundturnier_15_nH]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Inquisitionsprozess_gegen_Maar_und_Llewellyen.md:
    - [[Miran_Ernesto]] (Missing File)
    - [[Sandro_Ernesto]] (Missing File)
    - [[Tirgalad_Gildin]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Massenentlassung_Kriegerakademie_15_nH.md:
    - [[Ausbildung]] (Missing File)
    - [[Avor]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Trollkrieg_von_Brandenstein.md:
    - [[Rasse_Goblins]] (Missing File)
    - [[Rasse_Trolle]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Zeitstrahl.md:
    - [[Das_Unbekannte_Meer]] (Missing File)
    - [[Fraomar_Arkad'Grembargh]] (Missing File)
    - [[Historie]] (Missing File)
    - [[Kregor_Stahlauge]] (Missing File)
    - [[Zeitrechnung]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Geschichte/Zerstoerung_von_Westhever.md:
    - [[Brecher]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Alchemie_Kompendium.md:
    - [[Bannstaub]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Antimagie_und_Gegenzauber.md:
    - [[Kampfmagie]] (Missing File)
    - [[Schutzmagie]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Arcana_Procella.md:
    - [[Aura_Primus]] (Missing File)
    - [[Magier_ohne_Namen]] (Missing File)
    - [[Mazzarener]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Arkan-Metalle.md:
    - [[02_Ingis]] (Missing File)
    - [[02_Khaleb]] (Missing File)
    - [[02_Rien]] (Missing File)
    - [[02_Xan]] (Missing File)
    - [[Elementarlehre_Erde]] (Missing File)
    - [[Elementarlehre_Feuer]] (Missing File)
    - [[Elementarlehre_Wasser]] (Missing File)
    - [[Äther]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Arkane_Kriegfuehrung.md:
    - [[Arkanium]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Artefaktlehre.md:
    - [[Sphaerenfaeden]] (Missing File)
    - [[Thaumaturgische_Gitter]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Daimonicon.md:
    - [[Sha_Naz_Ghul]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Die_arkane_Gesellschaft.md:
    - [[Dordrun]] (Missing File)
    - [[Endrûn]] (Missing File)
    - [[Glurdrûn]] (Missing File)
    - [[Ildrûn]] (Missing File)
    - [[Lit_Ita_Im_Elarum_Odalim_ir_Galadon]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Elementare_Atomlehre.md:
    - [[Blitz]] (Missing File)
    - [[Eis]] (Missing File)
    - [[Humus]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Golems.md:
    - [[Höhere_Wesenheiten]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Hoehere_Wesenheiten.md:
    - [[Lich]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Horlafstrom_Theorie.md:
    - [[Ashordon]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Magie_Theorien.md:
    - [[Zyklus_und_Selektion]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Magier_Etikette.md:
    - [[Akademie_Brandenstein]] (Missing File)
    - [[Tradition_der_Magier]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Metamorphose_und_Gestaltwandel.md:
    - [[02_Vitama]] (Missing File)
    - [[Ars_Magica_Metamorphosia]] (Missing File)
    - [[Daimonologie]] (Missing File)
    - [[Heilmagie]] (Missing File)
    - [[Visor_Noctis]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Philosophie_der_Magie.md:
    - [[Sphären]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Rituallehre_Sphaeren.md:
    - [[Hankuk]] (Missing File)
  ⚠️  Siebenwind_Wiki/05_Magie/Vjera_Batama_Magica.md:
    - [[02_Angamon]] (Missing File)
    - [[02_Rien]] (Missing File)
    - [[02_Vitama]] (Missing File)
    - [[02_Xan]] (Missing File)
    - [[Arkanogenese]] (Missing File)
    - [[Gold]] (Missing File)
    - [[Silber]] (Missing File)
  ⚠️  Siebenwind_Wiki/06_Erzählungen/Der_Flug_der_Ente.md:
    - [[Fera_Noril]] (Missing File)
  ⚠️  Siebenwind_Wiki/06_Erzählungen/Geschichten_eines_silbernen_Adlers.md:
    - [[Serafina]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Adolfo_Bastian.md:
    - [[Die_Dwarschim]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Althea_Danea.md:
    - [[Il_Drun]] (Missing File)
    - [[Kompendium_Weissmagie]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Anijane_Lavid.md:
    - [[Finanzverwaltung]] (Missing File)
    - [[Lehen_Wasserwall]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Anonymus.md:
    - [[Alchemie]] (Missing File)
    - [[Etikette]] (Missing File)
    - [[Theorie zur arkan. Magie]] (Missing File)
    - [[Wissen_Siebenwind]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Argus_Ebonhart.md:
    - [[Königliche_Akademie_der_arkane_ Künste]] (Missing File)
    - [[Königliche_Akademie_der_arkane_Künste]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Azgar_Kazanin.md:
    - [[Famir_Aldun]] (Missing File)
    - [[Toran_Dor]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Blakkurvald_Orla.md:
    - [[Tuhle]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Caieta_Ajunier.md:
    - [[Forschungsberichte ([[Toran_Dur]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Celedelair.md:
    - [[Dedelebres_Zuflucht]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Chernides.md:
    - [[Religion]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Cizra_Innuae.md:
    - [[Konflikt_Ersont_Malthust_21nH]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Daena.md:
    - [[Königliche_Akademie]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Dame_al_Javet.md:
    - [[Magierturm_zu_Siebenwind]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Dimiona.md:
    - [[Die_Foki]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md:
    - [[Alchemie_Grundlagen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Elurai_Calades.md:
    - [[Bindungslehre]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Elyran_Fischer.md:
    - [[Elemente_der_Mitte]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Enoah_Sullin.md:
    - [[Forschungsberichte ([[Toran_Dur]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Falk_Steinhauer.md:
    - [[Wasserwall]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Feanthil_(Arinth).md:
    - [[Tar’Sala]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Feestar_von_Lichtenfeld.md:
    - [[Lichtenfeld]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Fogrim_Goldaxt.md:
    - [[H&H_der_Dwarschim]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Fruger_Hansen.md:
    - [[Wirtshaftsregister]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Gerrion_Arres.md:
    - [[Sumpfland]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Heinrich_Drachenfall.md:
    - [[Fundgrube]] (Missing File)
    - [[Raufels]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Herbren_Maltis.md:
    - [[Familie_Gerdenwald]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Hevelius_Dunkelfeld.md:
    - [[Akademie_zur_Linken]] (Missing File)
    - [[Gnaden_Custodias]] (Missing File)
    - [[Tarnek]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Hilgorad_I_ap_Mer.md:
    - [[Haus_ap_Mer]] (Missing File)
    - [[Könige_Falandriens]] (Missing File)
    - [[Rückkehr_von_König_Hilgorad]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Hormtosh_Wuchthammer.md:
    - [[Ordo_Ignis]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Huns_Siebzehnruebl.md:
    - [[Baumwesen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Inoch_Ateharis.md:
    - [[Kabinett_Altor]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Isgrim.md:
    - [[Baronsforstverwaltung]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Jennaia_Lavrial.md:
    - [[Theorie_der_elementaren_Atome]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Johan_Gottfried.md:
    - [[Dunkle_Ritter]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Johann_Liebig.md:
    - [[Arkane_Verbindung]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Johannes_Klos.md:
    - [[Locus_Magicae]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Kalveron_Dai.md:
    - [[De_Magica_Angamoniensis]] (Missing File)
    - [[System_arkaner_Lokalitaeten]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Katharina_von_Tiefenwald.md:
    - [[Ulanda_von_Tiefenwald]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Kazla.md:
    - [[Hintergrund]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Khorne.md:
    - [[Astrael_Batch]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Koruun_McKevin.md:
    - [[Adelssystem_Galadon]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Landrin_Eisklinge.md:
    - [[Orden_des_Heiligen_Schwertes_Bellums]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Laylira_Hohentann.md:
    - [[Hospiz_zu_Falkensee]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Leomar_Finkenfarn.md:
    - [[Laienorden_der_Viere]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Lewyn_Anacar.md:
    - [[Ars_Magica_Metamorphosia]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Lorence.md:
    - [[Gott_Bellum]] (Missing File)
    - [[Orden_Bellums]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Lothar_Gavinwald.md:
    - [[Die Ordenssatzung des Ordens vom Wachenden Löwen ([[Toran_Dur]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Lothgar.md:
    - [[Norland]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Lucius_Gropp.md:
    - [[06_Gruppen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Madame_Lafayette.md:
    - [[Sinistrus]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Maichellis_Wanderstern.md:
    - [[Auelfen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Malika_Nohadi.md:
    - [[Falkenorden]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Maltheos_Thorn.md:
    - [[Orden_vom_Heiligen_Schwert_Bellums]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Mirian.md:
    - [[Gawain_von_Tiefenwald]] (Missing File)
    - [[Nebelberge]] (Missing File)
    - [[Nebelbergen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Myrandhir.md:
    - [[Derfflinger]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Nathar_Erres.md:
    - [[Jagd]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Nefustor.md:
    - [[Daimonologie und Schwarze [[index]] (Missing File)
    - [[Daimonologie_und_Schwarze_Magie]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Ovelia_Galthana.md:
    - [[Lehen_Suedfall]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Proveus_Herand.md:
    - [[Bernhardt_Wiesinger]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Raisha_al_Javet.md:
    - [[Invocatio_Elementharii]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Ravia_Thyrandor.md:
    - [[TharSala]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Rianna.md:
    - [[Forschungsberichte ([[Toran_Dur]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Roald_Spitzbart.md:
    - [[Morsansacker]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Roland_Telvos.md:
    - [[01_Catar]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Rolosin_Vadebor.md:
    - [[Heilkunde]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Saphyriella.md:
    - [[Finanzen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Schneid.md:
    - [[Marine_Siebenwinds]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Sean_Eire.md:
    - [[Diözese_Siebenwind]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Sire_von_Weidenbach.md:
    - [[Ausbildung]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Stephan_von_Weidenbach.md:
    - [[Weidenbach]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Svendra_Merseck.md:
    - [[Gastronomie]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Taleris_Kreytz.md:
    - [[Aurora]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Talida.md:
    - [[Handwerk]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Telandrion.md:
    - [[Ignis-Kirche]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Terenon_Sarophilan.md:
    - [[Theorien_der_Magie]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Themus_Takai.md:
    - [[Theorem_zu_den_Baumwesen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Tjure_Odal.md:
    - [[Ketzer]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Uron_Sbocaj.md:
    - [[Elementarmagie]] (Missing File)
    - [[Urmagie]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Veridon.md:
    - [[Bellum-Kirche]] (Missing File)
    - [[Benion]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/William_Glaron.md:
    - [[Diener_des_Einen]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/William_Mercator.md:
    - [[Astraelorden]] (Missing File)
  ⚠️  Siebenwind_Wiki/07_Persoenlichkeiten/Wisper.md:
    - [[Ferrins]] (Missing File)
  ⚠️  Siebenwind_Wiki/08_Bestiarium/Bestie_von_Brandenstein.md:
    - [[Adepta Hohentann]] (Missing File)
  ⚠️  Siebenwind_Wiki/08_Bestiarium/Daemonen.md:
    - [[Blinde_Maler]] (Missing File)
  ⚠️  Siebenwind_Wiki/08_Bestiarium/Gargoyles.md:
    - [[Setas_Gonar]] (Missing File)
  ⚠️  Siebenwind_Wiki/08_Bestiarium/Tardukai.md:
    - [[Fürst_Raziel]] (Missing File)
  ⚠️  Siebenwind_Wiki/09_Bibliothek/Die_Elemente_ungleiche_Geschwister.md:
    - [[En'Hor]] (Missing File)
    - [[Orogrim]] (Missing File)
    - [[Tintin_Waljakov]] (Missing File)
  ⚠️  Siebenwind_Wiki/09_Bibliothek/Die_Verbrennung_des_heiligen_Markus.md:
    - [[Kalender]] (Missing File)
  ⚠️  Siebenwind_Wiki/09_Bibliothek/Die_Zwergen_WG.md:
    - [[Rubenia_Sturmspalter]] (Missing File)
  ⚠️  Siebenwind_Wiki/09_Bibliothek/Logbuch_des_Kerkers.md:
    - [[Simil]] (Missing File)
  ⚠️  Siebenwind_Wiki/09_Bibliothek/Maerchen_und_wie_man_sie_vermeidet.md:
    - [[Kleiner_Almanach_übernatürlicher_Wesen]] (Missing File)
  ⚠️  Siebenwind_Wiki/09_Bibliothek/Von_gesplitterten_Seelen.md:
    - [[Lyril]] (Missing File)
  ⚠️  Siebenwind_Wiki/09_Bibliothek/Waldemars_Reise_Papin.md:
    - [[Aldorn]] (Missing File)
  ⚠️  Siebenwind_Wiki/10_Archiv/Akademie_der_Schwarzen_Kuenste.md:
    - [[Magie_Linker_Pfad]] (Missing File)
  ⚠️  Siebenwind_Wiki/10_Archiv/Statut_der_Kronmark_Siebenwind.md:
    - [[Gesetze]] (Missing File)

============================================================
  ERGEBNIS: 414 Probleme gefunden.
  → Siehe /audit Workflow für Bearbeitungsschritte.
============================================================

[INFO] Report gespeichert unter: /Users/alexandrerabe/siebenwind/7w_wiki/Logs/Archive/Audit_e113291c-5c4c-45ec-91d3-0800c1ce42bd.txt
Error executing .agent/scripts/register_check.py: Command '['/opt/homebrew/opt/python@3.14/bin/python3.14', '/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/scripts/register_check.py']' returned non-zero exit status 1.
```

---
uuid: df6d31ce-620d-42bb-bac8-a80f090d8d56
status: FAIL
created_at: 2026-02-17T17:06:39Z
epistemic: "#meta"
---

# Test Run Report: rag-relevance-smoke

- Suite-Datei: `.agent/tests/suites/rag-relevance-smoke.json`
- Ergebnis: **FAIL**
- PASS: 0 | FAIL: 4 | SKIP: 0
- Laufzeit (gemessen): Summe 168.01s | Mittel 42.00s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `rag-status` | Index status reports coverage and writes archive register | FAIL | 1 | 24.34 | Exitcode 1 != erwartet 0 |
| `rag-q-dunvallo` | Query Dunvallo Linari retrieves core person article | FAIL | 0 | 49.34 | stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md' |
| `rag-q-matrix` | Query Matrixtheorie Linari retrieves matrix article | FAIL | 0 | 46.89 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md' |
| `rag-q-reagenzien` | Query Reagenzien Lehre Linari retrieves reagent article | FAIL | 0 | 47.44 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md' |

## FAIL: rag-status - Index status reports coverage and writes archive register

- Kommando: `./7w_wiki.py index --status`
- Laufzeit: 24.34s
- Grund: Exitcode 1 != erwartet 0

```text
⚠️  Config-Pfad /Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json nicht lesbar oder fehlerhaft (Permission oder Format): [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json'
📋 Config geladen: MPS (Batch: 4) aus .agent/config/runtime.json
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Indexierung                       ║
╚═══════════════════════════════════════════════════╝
  Repo:        /Users/alexandrerabe/siebenwind/7w_wiki
  Chunk-Größe: 2500 Zeichen (~357 Token)
  Modell:      jinaai/jina-embeddings-v3
  Modus:       ⚡ INKREMENTELL

  📊 Index-Status:
     siebenwind_quellen: 60151 Chunks | 288/300 Dateien (96.00% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
     siebenwind_wiki: 31700 Chunks | 157/1108 Dateien (14.17% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
Error executing .agent/skills/oracle/build_index.py: Command '['/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/venv/bin/python3', '/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py', '--status']' returned non-zero exit status 1.
```

```text
Traceback (most recent call last):
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1152, in <module>
    main()
    ~~~~^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1085, in main
    payload, md_path, json_path = build_archive_register(rag_progress)
                                  ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 335, in build_archive_register
    rec = _register_record_for_file(corpus, path)
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 289, in _register_record_for_file
    if path.suffix.lower() not in REGISTER_EXTENSIONS or not path.is_file():
                                                             ~~~~~~~~~~~~^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_abc.py", line 482, in is_file
    return S_ISREG(self.stat(follow_symlinks=follow_symlinks).st_mode)
                   ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_local.py", line 515, in stat
    return os.stat(self, follow_symlinks=follow_symlinks)
           ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PermissionError: [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/System/DELEGATION_CODEX_PHASE_20.md'
```

## FAIL: rag-q-dunvallo - Query Dunvallo Linari retrieves core person article

- Kommando: `./7w_wiki.py search Dunvallo Linari --source wiki`
- Laufzeit: 49.34s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Dunvallo Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 35.1s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 95/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 96/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 94/201 (206 Zeichen)
   ", Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 92/201 (208 Zeichen)
   "ll, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 91/201 (209 Zeichen)
   "all, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 98/201 (202 Zeichen)
   "hensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 99/201 (201 Zeichen)
   "ensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 100/201 (200 Zeichen)
   "nsvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Harwarn_Gropp]], [[Hagen_Robaar]], [[Luther_Dueff]], [[Falkenwall]], [[Benion_Sandelholz]]
   Chunk: 0/201 (2430 Zeichen)
   "# Siebenwind Bote 140

**Epistemischer Status:** #bote
**Datum:** 18. Querler 16 n.H.

## Überblick
Diese Ausgabe berichtet von der Gründung eines neuen Laienordens, einem bevorstehenden Schützenfest und der Hinrichtung eines berüchtigten Verbrechers. Zudem wird eine offizielle Liste der Lehensvasallen und Ritter von [[Siebenwind]] veröffentlicht.

## Wichtige Ereignisse
### Gründung des Ordens der Tränen Vitamas
Der Hochgeweihte **[[Benion_Sandelholz]]** (ehemals Abt des Ordo Vitamas) hat den [[Orden_der_Traenen_Vitamas]] ins Leben gerufen. Es handelt sich um einen Laienorden, der sich dem Mi..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Cavalaron_Vendell]], [[Laurec_Llewellyen]], [[Isgrim]], [[Ovelia_Galthana]], [[Luther_Dueff]]
   Chunk: 28/201 (273 Zeichen)
   "Sandelholz]]
*   [[Isgrim]]
*   [[Laurec_Llewellyen]]
*   [[Luther_Dueff]]
*   [[Ovelia_Galthana]]
*   [[Cavalaron_Vendell]]
*   [[Orden_der_Traenen_Vitamas]]

## Referenzen
- Primärquelle: [Siebenwind Bote 140](../../Quellen/Zeitung%207w%20Bote/Siebenwind%20Bote%20140.md)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 101/201 (199 Zeichen)
   "svasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 87/201 (213 Zeichen)
   "rschall, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_193.md
   Kategorie: Chronik | Entitäten: [[Custodias]], [[Claiomhs_Wacht]], [[Splitterfelsen]], [[Geduldiger_Sand]], [[Aschehorn]]
   Chunk: 0/201 (2176 Zeichen)
   "# Siebenwind Bote 193

**Epistemischer Status:** #bote
**Datum:** 17. Carmer 30 n.H.

## Überblick
Diese Ausgabe berichtet von einem Durchbruch bei den Friedensverhandlungen mit dem Lindwurm Akassvae, dem Erscheinen neuer drakonischer Bedrohungen und politischen Veränderungen in Dunquell.

## Die Lindwurm-Krise
### Friedensschluss mit Akassvae
Der Erzgeweihte **[[Custodias]]** führte erfolgreiche Verhandlungen mit dem grünen Lindwurm **[[Akassvae]]** und dem Echsen-Erdrufer **[[Geduldiger_Sand]]** in ihrer Feste in den [[Splitterfelsen]]. 
*   **Das Abkommen:** Akassvae und die ihr folgenden E..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 2/201 (298 Zeichen)
   "hekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 3/201 (297 Zeichen)
   "ekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 4/201 (296 Zeichen)
   "kar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 7/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 8/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Handelsbund]], [[Benion_Sandelholz]], [[Chronik]]
   Chunk: 11/201 (289 Zeichen)
   "ldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 5/201 (295 Zeichen)
   "ar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"
```

```text
2026-02-17 18:04:35.498 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_35-595472529‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:35.649 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_35-3418404169‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:35.760 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_35-2475692594‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:35.858 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_35-2658661766‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:37.604 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_37-2803998064‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:37.869 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_37-3005329591‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:38.796 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_38-1961306183‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:39.037 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_39-2631493994‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:39.202 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_39-1196349402‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:39.307 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_39-1917722547‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:39.434 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_39-1123795228‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:39.700 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_39-1729093873‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:39.800 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_39-732841886‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:39.871 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_39-1967555590‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:40.023 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_40-2034950665‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:40.140 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_40-3137075819‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:40.259 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_40-1811859929‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:40.265 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_40-1388398866‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:40.688 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_40-3832207292‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:41.636 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_41-282065035‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:41.842 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_41-1852872282‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:50.997 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_50-2938260655‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:51.124 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_51-422576221‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:51.212 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_51-2173659694‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:52.244 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_52-716867682‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:52.339 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_52-3387357931‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:52.348 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_52-2603882259‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:52.521 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_52-50601948‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:52.606 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_52-4070352871‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:52.626 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_52-3237249005‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:52.730 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_52-3961814160‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:53.032 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_53-239239478‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:53.280 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_53-251246288‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:54.166 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_54-2925885209‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:56.100 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_56-87772924‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:04:56.582 Python[7546:5392572] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7546-2026-02-17_18_04_56-1593075741‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-matrix - Query Matrixtheorie Linari retrieves matrix article

- Kommando: `./7w_wiki.py search Matrixtheorie Linari --source wiki`
- Laufzeit: 46.89s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Matrixtheorie Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 30.2s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Ventus]], [[Zwerge]], [[Vitama]]
   Chunk: 6/207 (2325 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Themen | [DEFINITION_BENÖTIGT] | #canon |
| Tiefenwald | [DEFINITION_BENÖTIGT] | #canon |
| Timeline | [DEFINITION_BENÖTIGT] | #canon |
| Tintin | [DEFINITION_BENÖTIGT] | #canon |
| Tion | [DEFINITION_BENÖTIGT] | #canon |
| Titel | [DEFINITION_BENÖTIGT] | #canon |
| Vandrien | [DEFINITION_BENÖTIGT] | #canon |
| Vencurius | [DEFINITION_BENÖTIGT] | #canon |
| [[Ventus]] | [DEFINITION_BENÖTIGT] | #canon |
| Verbindung | [DEFINITION_BENÖTIGT] | #canon |
| Verehrung | [DEFINITION_BENÖTIGT] | #canon |
| Verlinkte | [DEFINITION_BENÖTIGT] | #canon |
| Verwaltung | [D..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Angamon]], [[Xan]], [[Aequilibrium]]
   Chunk: 43/201 (257 Zeichen)
   "t.
*   [[Xan]] - Magie.

## Die Gegenspieler
*   [[Angamon]] - Der Dämonenfürst.

## Religionsphilosophie
*   [[Aequilibrium]] - Über den Dualismus und das göttliche Gleichgewicht.
*   [[Götter_und_Götzen]] - Abgrenzung der Viere von fremden Glaubensformen."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 14/201 (286 Zeichen)
   "e" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Aequilibrium.md
   Kategorie: Religion | Entitäten: [[Vitama]], [[Daemonen]], [[Untote]], [[Tare]], [[Codex_Astraeli]]
   Chunk: 0/201 (2189 Zeichen)
   "# Aequilibrium

**Epistemischer Status:** #überlieferung
**Autor:** [[Donarius_Derrvus]], Hochgeweihter des Ordo Astraeli
**Vollständiger Titel:** *Aequilibrium - Philosophie des Gleichgewichts das Tor des Bösen in unsere Sphäre?*

Das Werk **Aequilibrium** ist eine kritische Auseinandersetzung mit der "Theorie des Gleichgewichts", wie sie unter Druiden, Hexen, [[Elfen]] und Elementaristen verbreitet ist. Der Autor [[Donarius_Derrvus]] untersucht drei verschiedene Ebenen des Gleichgewichts und bewertet sie aus Sicht der [[Kirche_der_Viere]].

## Die drei Ebenen des Gleichgewichts

### 1. Das G..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 13/201 (287 Zeichen)
   "se" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 15/201 (285 Zeichen)
   "" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 16/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 17/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 20/201 (280 Zeichen)
   "lismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 9/201 (291 Zeichen)
   ". Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 5/201 (295 Zeichen)
   "t vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 10/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 11/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 4/201 (296 Zeichen)
   "ut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 6/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 7/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 1/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 2/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."
```

```text
2026-02-17 18:05:24.644 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_24-3201044688‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:24.774 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_24-3740745834‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:24.877 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_24-1357207569‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:24.964 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_24-839364354‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:26.415 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_26-3218383425‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:26.723 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_26-2711835348‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.223 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-857344269‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.423 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-1672531351‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.533 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-1410893497‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.605 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-273141972‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.697 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-4041538655‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.826 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-3331661208‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.905 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-1309949058‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:27.958 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_27-3435261783‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:28.111 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_28-2355311618‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:28.210 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_28-1976652432‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:28.315 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_28-3670586206‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:28.322 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_28-2704106456‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:28.418 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_28-3101362019‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:29.231 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_29-2658662135‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:29.421 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_29-120876720‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:37.452 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_37-2369857972‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:37.532 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_37-4046155714‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:37.591 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_37-3380028221‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:38.598 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_38-1026265950‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:38.694 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_38-1475302007‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:38.703 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_38-1909006985‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:38.818 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_38-1063206773‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:38.916 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_38-3627495620‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:38.935 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_38-1866970895‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:39.041 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_39-725468461‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:39.397 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_39-2123700913‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:39.645 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_39-3149287258‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:40.546 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_40-831485658‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:42.487 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_42-261587578‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:05:42.956 Python[7561:5393699] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7561-2026-02-17_18_05_42-2755292538‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-reagenzien - Query Reagenzien Lehre Linari retrieves reagent article

- Kommando: `./7w_wiki.py search Reagenzien Lehre Linari --source wiki`
- Laufzeit: 47.44s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Reagenzien Lehre Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 31.5s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magie_Grundlagen.md
   Kategorie: Fundament | Entitäten: [[Graumagie|Grauer Pfad]], [[Xan]], [[Brandenstein]], [[Ordo_Vitamae]], [[Sphärenkunde]]
   Chunk: 0/201 (1904 Zeichen)
   "# Magie Grundlagen

**Epistemischer Status:** #canon

Die Theorie der Magie auf [[Tare]] ist eine jahrtausendealte Wissenschaft, die das Verständnis der Elemente, der Sphären und der inneren Kraft des Geistes vereint.

## Die Quellen der Macht
### 1. Elementarmagie
Die rohe Magie wird durch die vier **[[Die_Gohor|Ur-Elemente]]** und ihre elementaren Herrscher ([[Enhor]]) gespeist:
*   **[[Ignis]] (Feuer):** Kraft der Zerstörung und radikalen Wandlung.
*   **[[Rien]] (Erde/Natur):** Kraft des Wachstums und der materiellen Stabilität.
*   **[[Ventus]] (Luft):** Kraft der Bewegung, des Schalls un..."

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Morsan]], [[Tare]], [[Astrael]], [[Dur]]
   Chunk: 0/202 (2333 Zeichen)
   "# Magietheorie (Toran [[Dur]])

**Epistemischer Status:** #überlieferung
**Autor:** Hochmagus Toran [[Dur]]
**Datum:** 26 n.H.

Dieser Artikel fasst die zentralen Lehren von Hochmagus Toran [[Dur]] zusammen, wie sie an der königlichen Akademie gelehrt werden. Er definiert Magie als die Manipulation des **Astralen Netzes** durch den sterblichen Geist.

## Definition und Ursprung
Magie gilt als eine der drei fundamentalen Konstanten der Existenz (neben Raum und Zeit). Während der Volksglaube [[Astrael]] als Schöpfer der Magie sieht, lehrt die Akademie, dass [[Astrael]] den Sterblichen lediglich..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 1/202 (850 Zeichen)
   "Lebewesen als Einheiten von **Aurenzentren** und Strömen. Die Summe dieser Ströme bildet die **Aura**.

### Theorie der größeren Ströme
Beschreibt magische Energieströme auf kontinentaler Ebene. Die Konvergenz dieser Ströme beeinflusst die Haltbarkeit von Zaubern und die Effektivität von Ritualen.

## Ritualkunde
Rituale lagern Komponenten der Magie auf Hilfsmittel (**Paraphernalia**) aus:
- **Anker:** (z.B. Edelsteine, Salz) zur Festigung von Geweben.
- **Foki:** (z.B. Lupen, Kerzen) zur Konzentration von Effekten.
- **Speicher:** (z.B. Arkanium) zum Sammeln astraler Kraft.

### Kreise
- **Ba..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Sorania]], [[Rien]], [[Tare]], [[Südfall]], [[Telandrion]]
   Chunk: 5/207 (2478 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Region | [DEFINITION_BENÖTIGT] | #canon |
| Regionen | [DEFINITION_BENÖTIGT] | #canon |
| Reich | [DEFINITION_BENÖTIGT] | #canon |
| Reiches | [DEFINITION_BENÖTIGT] | #canon |
| Reise | [DEFINITION_BENÖTIGT] | #canon |
| Religion | [DEFINITION_BENÖTIGT] | #canon |
| Richter | [DEFINITION_BENÖTIGT] | #canon |
| [[Rien]] | [DEFINITION_BENÖTIGT] | #canon |
| Ritter | [DEFINITION_BENÖTIGT] | #canon |
| Robaar | [DEFINITION_BENÖTIGT] | #canon |
| Rolle | [DEFINITION_BENÖTIGT] | #canon |
| Rothschild | [DEFINITION_BENÖTIGT] | #canon |
| Ruhe | [DEFINITION_BENÖTIGT]..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 107/202 (194 Zeichen)
   "reis:** Hält Einflüsse fern.
Beide nutzen die *Aversität* der Elemente (z.B. Feuer gegen Wasser), um Barrieren zu errichten.

## Siehe auch
- [[Das_Fundament]]
- [[Codex_Astraeli]]
- [[Astrael]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 148/201 (152 Zeichen)
   "xistenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 149/201 (151 Zeichen)
   "istenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Astrael.md
   Entitäten: [[Magie_Grundlagen]], [[Religion_Übersicht]], [[Die_Viere_Kirche]]
   Chunk: 164/200 (136 Zeichen)
   "ionen durch Verstand geleitet werden müssen.

## Verwandte Themen
- [[Religion_Übersicht]]
- [[Die_Viere_Kirche]]
- [[Magie_Grundlagen]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 154/201 (146 Zeichen)
   "z. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 155/201 (145 Zeichen)
   ". Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 152/201 (148 Zeichen)
   "enz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 145/201 (155 Zeichen)
   "r Existenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 153/201 (147 Zeichen)
   "nz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 151/201 (149 Zeichen)
   "tenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 150/201 (150 Zeichen)
   "stenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 15/201 (285 Zeichen)
   "rp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 4/201 (296 Zeichen)
   "le
*   **Corp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 33/201 (267 Zeichen)
   "r:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"
```

```text
2026-02-17 18:06:10.749 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_10-3317324840‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:10.868 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_10-4061783864‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:10.972 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_10-3488970408‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:11.061 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_11-1545016798‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:12.409 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_12-521451820‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:12.658 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_12-3499159097‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:13.181 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_13-1141095504‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:13.398 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_13-204414849‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:13.540 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_13-2290003516‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:13.636 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_13-4172144289‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:13.751 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_13-977864414‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:13.877 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_13-1142206761‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:13.963 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_13-2225201854‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:14.021 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_14-2702473007‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:14.320 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_14-358414861‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:14.438 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_14-1287185785‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:14.547 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_14-2861765244‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:14.661 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_14-1326353790‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:15.041 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_15-2670341591‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:15.905 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_15-2122628159‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:16.097 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_16-3038439921‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:24.876 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_24-1878228580‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:25.004 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_25-202868566‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:25.090 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_25-3114271509‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.125 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-608931342‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.225 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-4255372737‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.236 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-1792252436‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.359 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-3745173318‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.486 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-3310559984‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.507 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-3524821126‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.610 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-3197672732‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:26.935 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_26-1797925947‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:27.178 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_27-3390553225‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:28.005 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_28-973097141‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:29.931 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_29-256999532‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 18:06:30.432 Python[7567:5394228] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-7567-2026-02-17_18_06_30-4067884029‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

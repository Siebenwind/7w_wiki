---
uuid: 14d2d98e-2c0a-4099-a0e5-a6a4d115c0a8
status: PASS
created_at: 2026-02-17T22:55:52Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.21s | Mittel 0.28s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.80 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.13 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.55 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.19 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.15 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.15 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.15 | ok |

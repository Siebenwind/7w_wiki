---
uuid: 7e984922-f198-475f-88b2-d5555b0966bc
status: PASS
created_at: 2026-02-17T23:54:24Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **PASS**
- PASS: 5 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.39s | Mittel 0.48s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.12 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.11 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.11 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 1.18 | ok |
| `audit-reporting` | Audit command runs and reports current state | PASS | 1 | 0.88 | ok |

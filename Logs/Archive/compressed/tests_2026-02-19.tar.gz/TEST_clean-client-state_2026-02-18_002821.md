---
uuid: 072464ae-2bd4-4686-a6be-d40c10b0b5e1
status: PASS
created_at: 2026-02-17T23:28:21Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.46s | Mittel 0.43s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.40 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.11 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.10 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.94 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.19 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.19 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.29 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.23 | ok |

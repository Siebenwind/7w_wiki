---
uuid: e0f60255-8fca-4c8f-a6da-b4aeb711c195
status: PASS
created_at: 2026-02-17T22:33:10Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.24s | Mittel 0.40s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.82 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.11 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.12 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.99 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.32 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.30 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.31 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.27 | ok |

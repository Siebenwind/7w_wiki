---
uuid: a8a5f9e7-8562-4bbf-9e82-187e99444152
status: PASS
created_at: 2026-02-17T22:36:19Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.02s | Mittel 0.25s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.63 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.10 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.57 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.16 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.17 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.15 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.16 | ok |

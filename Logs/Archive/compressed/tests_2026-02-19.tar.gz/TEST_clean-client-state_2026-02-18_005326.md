---
uuid: 05854703-687a-4de2-bfdd-bcd452d1d7ea
status: PASS
created_at: 2026-02-17T23:53:26Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.05s | Mittel 0.38s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.16 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.10 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.10 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.87 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.21 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.19 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.23 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.19 | ok |

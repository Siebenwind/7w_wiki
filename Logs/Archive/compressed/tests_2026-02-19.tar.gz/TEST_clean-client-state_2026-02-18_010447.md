---
uuid: 386b37b3-1b73-454c-b378-8a69e020dd8b
status: PASS
created_at: 2026-02-18T00:04:47Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.63s | Mittel 0.20s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.74 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.04 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.04 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.41 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.10 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.10 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.10 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.11 | ok |

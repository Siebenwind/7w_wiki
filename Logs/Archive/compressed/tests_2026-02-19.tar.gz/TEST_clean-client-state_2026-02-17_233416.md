---
uuid: 156abe3f-d015-4c34-86ca-4c3be9f36534
status: PASS
created_at: 2026-02-17T22:34:16Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.46s | Mittel 0.31s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.69 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.10 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.10 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.59 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.17 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.21 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.30 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.31 | ok |

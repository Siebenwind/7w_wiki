---
uuid: 24f51ba7-6ccf-4577-b5b4-73628a845500
status: FAIL
created_at: 2026-02-17T21:56:43Z
epistemic: "#meta"
---

# Test Run Report: rag-relevance-smoke

- Suite-Datei: `.agent/tests/suites/rag-relevance-smoke.json`
- Ergebnis: **FAIL**
- PASS: 1 | FAIL: 3 | SKIP: 0
- Laufzeit (gemessen): Summe 129.86s | Mittel 32.46s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `rag-status` | Index status reports coverage and writes archive register | PASS | 0 | 14.67 | ok |
| `rag-q-dunvallo` | Query Dunvallo Linari retrieves core person article | FAIL | 0 | 37.60 | stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md' |
| `rag-q-matrix` | Query Matrixtheorie Linari retrieves matrix article | FAIL | 0 | 34.96 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md' |
| `rag-q-reagenzien` | Query Reagenzien Lehre Linari retrieves reagent article | FAIL | 0 | 42.63 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md' |

## FAIL: rag-q-dunvallo - Query Dunvallo Linari retrieves core person article

- Kommando: `./7w_wiki.py search Dunvallo Linari --source wiki`
- Laufzeit: 37.60s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Dunvallo Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 33.3s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 95/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 96/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 94/201 (206 Zeichen)
   ", Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 92/201 (208 Zeichen)
   "ll, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 91/201 (209 Zeichen)
   "all, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 98/201 (202 Zeichen)
   "hensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 99/201 (201 Zeichen)
   "ensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 100/201 (200 Zeichen)
   "nsvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Harwarn_Gropp]], [[Hagen_Robaar]], [[Luther_Dueff]], [[Falkenwall]], [[Benion_Sandelholz]]
   Chunk: 0/201 (2430 Zeichen)
   "# Siebenwind Bote 140

**Epistemischer Status:** #bote
**Datum:** 18. Querler 16 n.H.

## Überblick
Diese Ausgabe berichtet von der Gründung eines neuen Laienordens, einem bevorstehenden Schützenfest und der Hinrichtung eines berüchtigten Verbrechers. Zudem wird eine offizielle Liste der Lehensvasallen und Ritter von [[Siebenwind]] veröffentlicht.

## Wichtige Ereignisse
### Gründung des Ordens der Tränen Vitamas
Der Hochgeweihte **[[Benion_Sandelholz]]** (ehemals Abt des Ordo Vitamas) hat den [[Orden_der_Traenen_Vitamas]] ins Leben gerufen. Es handelt sich um einen Laienorden, der sich dem Mi..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Cavalaron_Vendell]], [[Laurec_Llewellyen]], [[Isgrim]], [[Ovelia_Galthana]], [[Luther_Dueff]]
   Chunk: 28/201 (273 Zeichen)
   "Sandelholz]]
*   [[Isgrim]]
*   [[Laurec_Llewellyen]]
*   [[Luther_Dueff]]
*   [[Ovelia_Galthana]]
*   [[Cavalaron_Vendell]]
*   [[Orden_der_Traenen_Vitamas]]

## Referenzen
- Primärquelle: [Siebenwind Bote 140](../../Quellen/Zeitung%207w%20Bote/Siebenwind%20Bote%20140.md)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 101/201 (199 Zeichen)
   "svasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 87/201 (213 Zeichen)
   "rschall, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_193.md
   Kategorie: Chronik | Entitäten: [[Custodias]], [[Claiomhs_Wacht]], [[Splitterfelsen]], [[Geduldiger_Sand]], [[Aschehorn]]
   Chunk: 0/201 (2176 Zeichen)
   "# Siebenwind Bote 193

**Epistemischer Status:** #bote
**Datum:** 17. Carmer 30 n.H.

## Überblick
Diese Ausgabe berichtet von einem Durchbruch bei den Friedensverhandlungen mit dem Lindwurm Akassvae, dem Erscheinen neuer drakonischer Bedrohungen und politischen Veränderungen in Dunquell.

## Die Lindwurm-Krise
### Friedensschluss mit Akassvae
Der Erzgeweihte **[[Custodias]]** führte erfolgreiche Verhandlungen mit dem grünen Lindwurm **[[Akassvae]]** und dem Echsen-Erdrufer **[[Geduldiger_Sand]]** in ihrer Feste in den [[Splitterfelsen]]. 
*   **Das Abkommen:** Akassvae und die ihr folgenden E..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 2/201 (298 Zeichen)
   "hekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 3/201 (297 Zeichen)
   "ekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 4/201 (296 Zeichen)
   "kar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 7/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 8/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Handelsbund]], [[Benion_Sandelholz]], [[Chronik]]
   Chunk: 11/201 (289 Zeichen)
   "ldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 5/201 (295 Zeichen)
   "ar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"
```

## FAIL: rag-q-matrix - Query Matrixtheorie Linari retrieves matrix article

- Kommando: `./7w_wiki.py search Matrixtheorie Linari --source wiki`
- Laufzeit: 34.96s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Matrixtheorie Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 30.0s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Ventus]], [[Zwerge]], [[Vitama]]
   Chunk: 6/207 (2325 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Themen | [DEFINITION_BENÖTIGT] | #canon |
| Tiefenwald | [DEFINITION_BENÖTIGT] | #canon |
| Timeline | [DEFINITION_BENÖTIGT] | #canon |
| Tintin | [DEFINITION_BENÖTIGT] | #canon |
| Tion | [DEFINITION_BENÖTIGT] | #canon |
| Titel | [DEFINITION_BENÖTIGT] | #canon |
| Vandrien | [DEFINITION_BENÖTIGT] | #canon |
| Vencurius | [DEFINITION_BENÖTIGT] | #canon |
| [[Ventus]] | [DEFINITION_BENÖTIGT] | #canon |
| Verbindung | [DEFINITION_BENÖTIGT] | #canon |
| Verehrung | [DEFINITION_BENÖTIGT] | #canon |
| Verlinkte | [DEFINITION_BENÖTIGT] | #canon |
| Verwaltung | [D..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Angamon]], [[Xan]], [[Aequilibrium]]
   Chunk: 43/201 (257 Zeichen)
   "t.
*   [[Xan]] - Magie.

## Die Gegenspieler
*   [[Angamon]] - Der Dämonenfürst.

## Religionsphilosophie
*   [[Aequilibrium]] - Über den Dualismus und das göttliche Gleichgewicht.
*   [[Götter_und_Götzen]] - Abgrenzung der Viere von fremden Glaubensformen."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 14/201 (286 Zeichen)
   "e" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Aequilibrium.md
   Kategorie: Religion | Entitäten: [[Vitama]], [[Daemonen]], [[Untote]], [[Tare]], [[Codex_Astraeli]]
   Chunk: 0/201 (2189 Zeichen)
   "# Aequilibrium

**Epistemischer Status:** #überlieferung
**Autor:** [[Donarius_Derrvus]], Hochgeweihter des Ordo Astraeli
**Vollständiger Titel:** *Aequilibrium - Philosophie des Gleichgewichts das Tor des Bösen in unsere Sphäre?*

Das Werk **Aequilibrium** ist eine kritische Auseinandersetzung mit der "Theorie des Gleichgewichts", wie sie unter Druiden, Hexen, [[Elfen]] und Elementaristen verbreitet ist. Der Autor [[Donarius_Derrvus]] untersucht drei verschiedene Ebenen des Gleichgewichts und bewertet sie aus Sicht der [[Kirche_der_Viere]].

## Die drei Ebenen des Gleichgewichts

### 1. Das G..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 13/201 (287 Zeichen)
   "se" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 15/201 (285 Zeichen)
   "" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 16/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 17/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 20/201 (280 Zeichen)
   "lismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 9/201 (291 Zeichen)
   ". Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 5/201 (295 Zeichen)
   "t vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 10/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 11/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 4/201 (296 Zeichen)
   "ut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 6/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 7/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 1/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 2/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."
```

## FAIL: rag-q-reagenzien - Query Reagenzien Lehre Linari retrieves reagent article

- Kommando: `./7w_wiki.py search Reagenzien Lehre Linari --source wiki`
- Laufzeit: 42.63s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Reagenzien Lehre Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 37.6s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magie_Grundlagen.md
   Kategorie: Fundament | Entitäten: [[Graumagie|Grauer Pfad]], [[Xan]], [[Brandenstein]], [[Ordo_Vitamae]], [[Sphärenkunde]]
   Chunk: 0/201 (1904 Zeichen)
   "# Magie Grundlagen

**Epistemischer Status:** #canon

Die Theorie der Magie auf [[Tare]] ist eine jahrtausendealte Wissenschaft, die das Verständnis der Elemente, der Sphären und der inneren Kraft des Geistes vereint.

## Die Quellen der Macht
### 1. Elementarmagie
Die rohe Magie wird durch die vier **[[Die_Gohor|Ur-Elemente]]** und ihre elementaren Herrscher ([[Enhor]]) gespeist:
*   **[[Ignis]] (Feuer):** Kraft der Zerstörung und radikalen Wandlung.
*   **[[Rien]] (Erde/Natur):** Kraft des Wachstums und der materiellen Stabilität.
*   **[[Ventus]] (Luft):** Kraft der Bewegung, des Schalls un..."

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Morsan]], [[Tare]], [[Astrael]], [[Dur]]
   Chunk: 0/202 (2333 Zeichen)
   "# Magietheorie (Toran [[Dur]])

**Epistemischer Status:** #überlieferung
**Autor:** Hochmagus Toran [[Dur]]
**Datum:** 26 n.H.

Dieser Artikel fasst die zentralen Lehren von Hochmagus Toran [[Dur]] zusammen, wie sie an der königlichen Akademie gelehrt werden. Er definiert Magie als die Manipulation des **Astralen Netzes** durch den sterblichen Geist.

## Definition und Ursprung
Magie gilt als eine der drei fundamentalen Konstanten der Existenz (neben Raum und Zeit). Während der Volksglaube [[Astrael]] als Schöpfer der Magie sieht, lehrt die Akademie, dass [[Astrael]] den Sterblichen lediglich..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 1/202 (850 Zeichen)
   "Lebewesen als Einheiten von **Aurenzentren** und Strömen. Die Summe dieser Ströme bildet die **Aura**.

### Theorie der größeren Ströme
Beschreibt magische Energieströme auf kontinentaler Ebene. Die Konvergenz dieser Ströme beeinflusst die Haltbarkeit von Zaubern und die Effektivität von Ritualen.

## Ritualkunde
Rituale lagern Komponenten der Magie auf Hilfsmittel (**Paraphernalia**) aus:
- **Anker:** (z.B. Edelsteine, Salz) zur Festigung von Geweben.
- **Foki:** (z.B. Lupen, Kerzen) zur Konzentration von Effekten.
- **Speicher:** (z.B. Arkanium) zum Sammeln astraler Kraft.

### Kreise
- **Ba..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Sorania]], [[Rien]], [[Tare]], [[Südfall]], [[Telandrion]]
   Chunk: 5/207 (2478 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Region | [DEFINITION_BENÖTIGT] | #canon |
| Regionen | [DEFINITION_BENÖTIGT] | #canon |
| Reich | [DEFINITION_BENÖTIGT] | #canon |
| Reiches | [DEFINITION_BENÖTIGT] | #canon |
| Reise | [DEFINITION_BENÖTIGT] | #canon |
| Religion | [DEFINITION_BENÖTIGT] | #canon |
| Richter | [DEFINITION_BENÖTIGT] | #canon |
| [[Rien]] | [DEFINITION_BENÖTIGT] | #canon |
| Ritter | [DEFINITION_BENÖTIGT] | #canon |
| Robaar | [DEFINITION_BENÖTIGT] | #canon |
| Rolle | [DEFINITION_BENÖTIGT] | #canon |
| Rothschild | [DEFINITION_BENÖTIGT] | #canon |
| Ruhe | [DEFINITION_BENÖTIGT]..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 107/202 (194 Zeichen)
   "reis:** Hält Einflüsse fern.
Beide nutzen die *Aversität* der Elemente (z.B. Feuer gegen Wasser), um Barrieren zu errichten.

## Siehe auch
- [[Das_Fundament]]
- [[Codex_Astraeli]]
- [[Astrael]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 148/201 (152 Zeichen)
   "xistenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 149/201 (151 Zeichen)
   "istenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Astrael.md
   Entitäten: [[Magie_Grundlagen]], [[Religion_Übersicht]], [[Die_Viere_Kirche]]
   Chunk: 164/200 (136 Zeichen)
   "ionen durch Verstand geleitet werden müssen.

## Verwandte Themen
- [[Religion_Übersicht]]
- [[Die_Viere_Kirche]]
- [[Magie_Grundlagen]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 154/201 (146 Zeichen)
   "z. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 155/201 (145 Zeichen)
   ". Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 152/201 (148 Zeichen)
   "enz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 145/201 (155 Zeichen)
   "r Existenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 153/201 (147 Zeichen)
   "nz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 151/201 (149 Zeichen)
   "tenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 150/201 (150 Zeichen)
   "stenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 15/201 (285 Zeichen)
   "rp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 4/201 (296 Zeichen)
   "le
*   **Corp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 33/201 (267 Zeichen)
   "r:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"
```

---
uuid: 14b7d1ea-02b7-4216-9089-b83ff025a3d5
status: PASS
created_at: 2026-02-16T21:19:36Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0

| ID | Name | Status | Exit | Hinweis |
|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | ok |
| `help` | CLI help renders command registry | PASS | 0 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | ok |

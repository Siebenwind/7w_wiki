---
uuid: 773505f7-11c2-4ac3-a445-a5589a2bd5eb
status: PASS
created_at: 2026-02-17T22:49:52Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.96s | Mittel 0.37s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.16 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.11 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.73 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.23 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.20 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.20 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.24 | ok |

---
uuid: 223c5896-505c-4d46-bc43-b8f027ed43fa
status: PASS
created_at: 2026-02-17T22:00:27Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.86s | Mittel 0.23s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.46 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.07 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.07 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.61 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.16 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.13 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.16 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.21 | ok |

---
uuid: 4a52c096-6036-4461-8522-1f6ff86dbc65
status: FAIL
created_at: 2026-02-17T01:32:38Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **FAIL**
- PASS: 4 | FAIL: 1 | SKIP: 0
- Laufzeit (gemessen): Summe 0.36s | Mittel 0.07s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.05 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.05 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.05 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 0.13 | ok |
| `audit-readiness` | Audit still passes | FAIL | 1 | 0.08 | Exitcode 1 != erwartet 0 |

## FAIL: audit-readiness - Audit still passes

- Kommando: `./7w_wiki.py audit`
- Laufzeit: 0.08s
- Grund: Exitcode 1 != erwartet 0

```text
============================================================
  SIEBENWIND WIKI — REGISTER-CHECK
  Report-ID: 270334c9-49fe-4ca5-99b3-0ac13ceca33b
============================================================

## 1. Duplikate im Personenregister
  ✅ Keine Duplikate gefunden.

## 2. Verwaiste Profile (Datei ohne Register-Eintrag)
  ✅ Alle Profile sind registriert.

## 3. Registrierte Personen ohne Profildatei
  📝 Allakath — Profildatei fehlt

## 4. Boten-Lücken (Quellen vorhanden, nicht integriert)
  ✅ Alle verfügbaren Boten sind integriert.

## 5. Index-Lücken (Dateien vorhanden, nicht in Die_Chronik.md)
  ✅ Alle Boten-Dateien sind im Index erfasst.

============================================================
  ERGEBNIS: 1 Probleme gefunden.
  → Siehe /audit Workflow für Bearbeitungsschritte.
============================================================

[INFO] Report gespeichert unter: /Users/alexandrerabe/siebenwind/7w_wiki/Logs/Archive/Audit_270334c9-49fe-4ca5-99b3-0ac13ceca33b.txt
Error executing .agent/scripts/register_check.py: Command '['/opt/homebrew/opt/python@3.14/bin/python3.14', '/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/scripts/register_check.py']' returned non-zero exit status 1.
```

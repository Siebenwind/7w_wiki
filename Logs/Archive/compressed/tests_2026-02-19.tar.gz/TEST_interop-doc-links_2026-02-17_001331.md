---
uuid: 5fae4c54-c95d-43cb-a614-e4a384b416e1
status: FAIL
created_at: 2026-02-16T23:13:31Z
epistemic: "#meta"
---

# Test Run Report: interop-doc-links

- Suite-Datei: `.agent/tests/suites/interop-doc-links.json`
- Ergebnis: **FAIL**
- PASS: 0 | FAIL: 1 | SKIP: 0
- Laufzeit (gemessen): Summe 0.01s | Mittel 0.01s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `core-link-integrity` | Core interop/testing docs have resolvable local markdown links | FAIL | 1 | 0.01 | Broken links: System/COORDINATION_HUB.md -> Logs/Conclusions/2026-02-17_Forum_Research_Report.md |

## FAIL: core-link-integrity - Core interop/testing docs have resolvable local markdown links

- Kommando: `link-check AGENTS.md .agent/workflows/start.md .agent/workflows/takeover.md .agent/workflows/handover.md .agent/workflows/test_run.md System/Synapse_Board/SY_INTEROP.md System/Synapse_Board/SY_WORKFLOW_CLI_MATRIX.md System/Synapse_Board/SY_TESTING.md System/AGENT_OPERATIONS_HANDBOOK.md System/COORDINATION_HUB.md`
- Laufzeit: 0.01s
- Grund: Broken links: System/COORDINATION_HUB.md -> Logs/Conclusions/2026-02-17_Forum_Research_Report.md

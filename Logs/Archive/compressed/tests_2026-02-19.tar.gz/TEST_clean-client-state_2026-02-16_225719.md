---
uuid: 1693f241-7caa-4a25-a692-eadb33d19c1d
status: PASS
created_at: 2026-02-16T21:57:19Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 0.60s | Mittel 0.08s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.11 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.05 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.04 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.10 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.08 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.08 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.08 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.08 | ok |

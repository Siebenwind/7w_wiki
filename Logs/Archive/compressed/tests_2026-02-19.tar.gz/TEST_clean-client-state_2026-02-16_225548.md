---
uuid: 4132fcef-6c54-4f4c-8ced-9f8de9f4890a
status: PASS
created_at: 2026-02-16T21:55:48Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 0.69s | Mittel 0.09s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.10 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.05 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.05 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.11 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.09 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.09 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.10 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.09 | ok |

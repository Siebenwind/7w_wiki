---
uuid: 2f1eaaa3-dc16-4923-badb-dfccd99d2b0f
status: PASS
created_at: 2026-02-17T21:07:12Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.27s | Mittel 0.16s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.35 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.05 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.05 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.36 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.12 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.12 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.11 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.11 | ok |

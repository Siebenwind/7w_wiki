---
uuid: 451ad124-e6ff-484a-8338-908b3117fcb0
status: PASS
created_at: 2026-02-17T22:38:32Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.95s | Mittel 0.24s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.66 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.08 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.55 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.14 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.14 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.13 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.16 | ok |

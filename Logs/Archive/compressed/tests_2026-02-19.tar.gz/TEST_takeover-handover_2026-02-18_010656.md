---
uuid: 73d36d39-330d-4499-b307-a647cab236cc
status: PASS
created_at: 2026-02-18T00:06:56Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **PASS**
- PASS: 5 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.09s | Mittel 0.22s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.05 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.05 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.05 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 0.50 | ok |
| `audit-reporting` | Audit command runs and reports current state | PASS | 1 | 0.45 | ok |

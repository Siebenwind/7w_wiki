---
uuid: 602113a9-752c-4428-ab3d-84d0a958eff1
status: PASS
created_at: 2026-02-17T21:51:38Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.52s | Mittel 0.19s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.62 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.06 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.05 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.38 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.11 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.10 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.10 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.10 | ok |

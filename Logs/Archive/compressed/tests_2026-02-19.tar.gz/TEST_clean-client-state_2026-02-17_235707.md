---
uuid: 84e92d1c-f60e-4947-b189-d9c7c73f2aff
status: PASS
created_at: 2026-02-17T22:57:07Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.90s | Mittel 0.36s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.72 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.11 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.83 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.42 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.17 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.18 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.38 | ok |

---
uuid: 2e93be50-0d73-4450-8ffd-6a6eec26990f
status: PASS
created_at: 2026-02-17T01:41:32Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **PASS**
- PASS: 5 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 0.40s | Mittel 0.08s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.06 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.06 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.06 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 0.14 | ok |
| `audit-readiness` | Audit still passes | PASS | 0 | 0.09 | ok |

---
uuid: b1c33abc-efc0-447a-bafa-d19624613c8f
status: PASS
created_at: 2026-02-16T22:15:50Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 1.04s | Mittel 0.13s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.19 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.07 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.06 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.20 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.14 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.12 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.12 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.14 | ok |

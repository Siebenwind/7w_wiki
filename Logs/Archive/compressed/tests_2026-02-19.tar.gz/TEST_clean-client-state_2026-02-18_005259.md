---
uuid: 55c727d4-dc67-4e13-aff7-bda4b9d68fbd
status: PASS
created_at: 2026-02-17T23:52:59Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 4.65s | Mittel 0.58s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.79 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.19 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.18 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 1.42 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.45 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.25 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.18 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.19 | ok |

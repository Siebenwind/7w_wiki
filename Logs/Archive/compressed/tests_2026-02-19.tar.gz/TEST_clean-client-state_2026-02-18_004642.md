---
uuid: b9e79956-43aa-4d53-9dd6-5a363edb9c8c
status: PASS
created_at: 2026-02-17T23:46:42Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.44s | Mittel 0.43s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.39 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.11 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.11 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.97 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.22 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.24 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.20 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.20 | ok |

---
uuid: 5c344c17-a800-402a-928e-5cde4acad99a
status: PASS
created_at: 2026-02-17T22:38:26Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 2.28s | Mittel 0.28s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 0.63 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.08 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.09 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.63 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.18 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.21 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.27 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.20 | ok |

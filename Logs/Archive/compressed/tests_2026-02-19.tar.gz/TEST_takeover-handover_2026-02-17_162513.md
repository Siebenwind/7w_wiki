---
uuid: e4ab053e-b68c-429c-844b-12c9fe39bbce
status: PASS
created_at: 2026-02-17T15:25:13Z
epistemic: "#meta"
---

# Test Run Report: takeover-handover

- Suite-Datei: `.agent/tests/suites/takeover-handover.json`
- Ergebnis: **PASS**
- PASS: 5 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 0.39s | Mittel 0.08s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `cli-help-includes-workflows` | CLI help includes takeover/handover commands | PASS | 0 | 0.06 | ok |
| `takeover-view` | Takeover workflow is viewable via CLI | PASS | 0 | 0.06 | ok |
| `handover-view` | Handover workflow is viewable via CLI | PASS | 0 | 0.05 | ok |
| `advisor-readiness` | Advisor remains clean after workflow calls | PASS | 0 | 0.13 | ok |
| `audit-readiness` | Audit still passes | PASS | 0 | 0.09 | ok |

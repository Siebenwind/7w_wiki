---
uuid: 8b8899b3-2c25-4791-93ef-98926d4d50f6
status: PASS
created_at: 2026-02-17T22:05:39Z
epistemic: "#meta"
---

# Test Run Report: clean-client-state

- Suite-Datei: `.agent/tests/suites/clean-client-state.json`
- Ergebnis: **PASS**
- PASS: 8 | FAIL: 0 | SKIP: 0
- Laufzeit (gemessen): Summe 3.14s | Mittel 0.39s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `default-entry` | Default call falls back to advisor | PASS | 0 | 1.11 | ok |
| `help` | CLI help renders command registry | PASS | 0 | 0.11 | ok |
| `start` | Start workflow prints onboarding guidance | PASS | 0 | 0.12 | ok |
| `advisor` | Advisor shows priorities and queue | PASS | 0 | 0.94 | ok |
| `inbox-open` | Dispatch OPEN list works | PASS | 0 | 0.22 | ok |
| `inbox-claimed` | Dispatch CLAIMED list works | PASS | 0 | 0.21 | ok |
| `inbox-done` | Dispatch DONE list works | PASS | 0 | 0.18 | ok |
| `read-first-open` | Read first open dispatch message | PASS | 0 | 0.25 | ok |

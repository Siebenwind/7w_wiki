---
uuid: be57f16b-b51f-4ef4-a0aa-53ef5b29fdb5
status: FAIL
created_at: 2026-02-17T20:13:39Z
epistemic: "#meta"
---

# Test Run Report: rag-relevance-smoke

- Suite-Datei: `.agent/tests/suites/rag-relevance-smoke.json`
- Ergebnis: **FAIL**
- PASS: 0 | FAIL: 4 | SKIP: 0
- Laufzeit (gemessen): Summe 136.50s | Mittel 34.12s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `rag-status` | Index status reports coverage and writes archive register | FAIL | 1 | 16.66 | Exitcode 1 != erwartet 0 |
| `rag-q-dunvallo` | Query Dunvallo Linari retrieves core person article | FAIL | 0 | 38.66 | stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md' |
| `rag-q-matrix` | Query Matrixtheorie Linari retrieves matrix article | FAIL | 0 | 40.27 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md' |
| `rag-q-reagenzien` | Query Reagenzien Lehre Linari retrieves reagent article | FAIL | 0 | 40.92 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md' |

## FAIL: rag-status - Index status reports coverage and writes archive register

- Kommando: `./7w_wiki.py index --status`
- Laufzeit: 16.66s
- Grund: Exitcode 1 != erwartet 0

```text
⚠️  Config-Pfad /Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json nicht lesbar oder fehlerhaft (Permission oder Format): [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json'
📋 Config geladen: MPS (Batch: 4) aus .agent/config/runtime.json
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Indexierung                       ║
╚═══════════════════════════════════════════════════╝
  Repo:        /Users/alexandrerabe/siebenwind/7w_wiki
  Chunk-Größe: 2500 Zeichen (~357 Token)
  Modell:      jinaai/jina-embeddings-v3
  Modus:       ⚡ INKREMENTELL

  📊 Index-Status:
     siebenwind_quellen: 60151 Chunks | 288/300 Dateien (96.00% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
     siebenwind_wiki: 31700 Chunks | 157/1108 Dateien (14.17% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
Error executing .agent/skills/oracle/build_index.py: Command '['/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/venv/bin/python3', '/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py', '--status']' returned non-zero exit status 1.
```

```text
Traceback (most recent call last):
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1152, in <module>
    main()
    ~~~~^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1085, in main
    payload, md_path, json_path = build_archive_register(rag_progress)
                                  ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 335, in build_archive_register
    rec = _register_record_for_file(corpus, path)
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 289, in _register_record_for_file
    if path.suffix.lower() not in REGISTER_EXTENSIONS or not path.is_file():
                                                             ~~~~~~~~~~~~^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_abc.py", line 482, in is_file
    return S_ISREG(self.stat(follow_symlinks=follow_symlinks).st_mode)
                   ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_local.py", line 515, in stat
    return os.stat(self, follow_symlinks=follow_symlinks)
           ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PermissionError: [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/System/DELEGATION_CODEX_PHASE_20.md'
```

## FAIL: rag-q-dunvallo - Query Dunvallo Linari retrieves core person article

- Kommando: `./7w_wiki.py search Dunvallo Linari --source wiki`
- Laufzeit: 38.66s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Dunvallo Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 28.4s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 95/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 96/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 94/201 (206 Zeichen)
   ", Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 92/201 (208 Zeichen)
   "ll, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 91/201 (209 Zeichen)
   "all, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 98/201 (202 Zeichen)
   "hensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 99/201 (201 Zeichen)
   "ensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 100/201 (200 Zeichen)
   "nsvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Harwarn_Gropp]], [[Hagen_Robaar]], [[Luther_Dueff]], [[Falkenwall]], [[Benion_Sandelholz]]
   Chunk: 0/201 (2430 Zeichen)
   "# Siebenwind Bote 140

**Epistemischer Status:** #bote
**Datum:** 18. Querler 16 n.H.

## Überblick
Diese Ausgabe berichtet von der Gründung eines neuen Laienordens, einem bevorstehenden Schützenfest und der Hinrichtung eines berüchtigten Verbrechers. Zudem wird eine offizielle Liste der Lehensvasallen und Ritter von [[Siebenwind]] veröffentlicht.

## Wichtige Ereignisse
### Gründung des Ordens der Tränen Vitamas
Der Hochgeweihte **[[Benion_Sandelholz]]** (ehemals Abt des Ordo Vitamas) hat den [[Orden_der_Traenen_Vitamas]] ins Leben gerufen. Es handelt sich um einen Laienorden, der sich dem Mi..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Cavalaron_Vendell]], [[Laurec_Llewellyen]], [[Isgrim]], [[Ovelia_Galthana]], [[Luther_Dueff]]
   Chunk: 28/201 (273 Zeichen)
   "Sandelholz]]
*   [[Isgrim]]
*   [[Laurec_Llewellyen]]
*   [[Luther_Dueff]]
*   [[Ovelia_Galthana]]
*   [[Cavalaron_Vendell]]
*   [[Orden_der_Traenen_Vitamas]]

## Referenzen
- Primärquelle: [Siebenwind Bote 140](../../Quellen/Zeitung%207w%20Bote/Siebenwind%20Bote%20140.md)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 101/201 (199 Zeichen)
   "svasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 87/201 (213 Zeichen)
   "rschall, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_193.md
   Kategorie: Chronik | Entitäten: [[Custodias]], [[Claiomhs_Wacht]], [[Splitterfelsen]], [[Geduldiger_Sand]], [[Aschehorn]]
   Chunk: 0/201 (2176 Zeichen)
   "# Siebenwind Bote 193

**Epistemischer Status:** #bote
**Datum:** 17. Carmer 30 n.H.

## Überblick
Diese Ausgabe berichtet von einem Durchbruch bei den Friedensverhandlungen mit dem Lindwurm Akassvae, dem Erscheinen neuer drakonischer Bedrohungen und politischen Veränderungen in Dunquell.

## Die Lindwurm-Krise
### Friedensschluss mit Akassvae
Der Erzgeweihte **[[Custodias]]** führte erfolgreiche Verhandlungen mit dem grünen Lindwurm **[[Akassvae]]** und dem Echsen-Erdrufer **[[Geduldiger_Sand]]** in ihrer Feste in den [[Splitterfelsen]]. 
*   **Das Abkommen:** Akassvae und die ihr folgenden E..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 2/201 (298 Zeichen)
   "hekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 3/201 (297 Zeichen)
   "ekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 4/201 (296 Zeichen)
   "kar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 7/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 8/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Handelsbund]], [[Benion_Sandelholz]], [[Chronik]]
   Chunk: 11/201 (289 Zeichen)
   "ldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 5/201 (295 Zeichen)
   "ar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"
```

```text
2026-02-17 21:11:54.424 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_54-4231411251‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:54.545 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_54-3279028827‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:54.629 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_54-117795377‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:54.702 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_54-910171161‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:56.079 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_56-3488717044‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:56.338 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_56-3806828709‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.021 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-1011631583‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.213 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-182921889‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.323 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-1117403830‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.395 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-1928290794‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.484 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-363093163‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.695 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-261907228‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.766 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-4227818846‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:57.817 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_57-4123974137‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:58.064 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_58-174652204‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:58.164 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_58-2345177206‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:58.252 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_58-1938218960‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:58.259 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_58-3336449239‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:58.606 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_58-1332845059‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:59.270 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_59-4061679158‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:11:59.448 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_11_59-2756379495‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:06.969 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_06-1505473641‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:07.048 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_07-4247947817‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:07.105 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_07-3102030948‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:07.977 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_07-105561665‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.060 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-39653860‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.065 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-46158888‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.156 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-34588744‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.240 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-250716161‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.255 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-2757609861‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.349 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-5188132‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.635 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-1576692993‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:08.868 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_08-1161851179‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:09.651 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_09-378139868‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:11.403 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_11-3074103994‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:11.724 Python[27780:5559618] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27780-2026-02-17_21_12_11-2113562892‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-matrix - Query Matrixtheorie Linari retrieves matrix article

- Kommando: `./7w_wiki.py search Matrixtheorie Linari --source wiki`
- Laufzeit: 40.27s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Matrixtheorie Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 27.9s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Ventus]], [[Zwerge]], [[Vitama]]
   Chunk: 6/207 (2325 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Themen | [DEFINITION_BENÖTIGT] | #canon |
| Tiefenwald | [DEFINITION_BENÖTIGT] | #canon |
| Timeline | [DEFINITION_BENÖTIGT] | #canon |
| Tintin | [DEFINITION_BENÖTIGT] | #canon |
| Tion | [DEFINITION_BENÖTIGT] | #canon |
| Titel | [DEFINITION_BENÖTIGT] | #canon |
| Vandrien | [DEFINITION_BENÖTIGT] | #canon |
| Vencurius | [DEFINITION_BENÖTIGT] | #canon |
| [[Ventus]] | [DEFINITION_BENÖTIGT] | #canon |
| Verbindung | [DEFINITION_BENÖTIGT] | #canon |
| Verehrung | [DEFINITION_BENÖTIGT] | #canon |
| Verlinkte | [DEFINITION_BENÖTIGT] | #canon |
| Verwaltung | [D..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Angamon]], [[Xan]], [[Aequilibrium]]
   Chunk: 43/201 (257 Zeichen)
   "t.
*   [[Xan]] - Magie.

## Die Gegenspieler
*   [[Angamon]] - Der Dämonenfürst.

## Religionsphilosophie
*   [[Aequilibrium]] - Über den Dualismus und das göttliche Gleichgewicht.
*   [[Götter_und_Götzen]] - Abgrenzung der Viere von fremden Glaubensformen."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 14/201 (286 Zeichen)
   "e" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Aequilibrium.md
   Kategorie: Religion | Entitäten: [[Vitama]], [[Daemonen]], [[Untote]], [[Tare]], [[Codex_Astraeli]]
   Chunk: 0/201 (2189 Zeichen)
   "# Aequilibrium

**Epistemischer Status:** #überlieferung
**Autor:** [[Donarius_Derrvus]], Hochgeweihter des Ordo Astraeli
**Vollständiger Titel:** *Aequilibrium - Philosophie des Gleichgewichts das Tor des Bösen in unsere Sphäre?*

Das Werk **Aequilibrium** ist eine kritische Auseinandersetzung mit der "Theorie des Gleichgewichts", wie sie unter Druiden, Hexen, [[Elfen]] und Elementaristen verbreitet ist. Der Autor [[Donarius_Derrvus]] untersucht drei verschiedene Ebenen des Gleichgewichts und bewertet sie aus Sicht der [[Kirche_der_Viere]].

## Die drei Ebenen des Gleichgewichts

### 1. Das G..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 13/201 (287 Zeichen)
   "se" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 15/201 (285 Zeichen)
   "" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 16/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 17/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 20/201 (280 Zeichen)
   "lismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 9/201 (291 Zeichen)
   ". Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 5/201 (295 Zeichen)
   "t vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 10/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 11/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 4/201 (296 Zeichen)
   "ut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 6/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 7/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 1/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 2/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."
```

```text
2026-02-17 21:12:32.271 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_32-237028348‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:32.369 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_32-1682925165‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:32.464 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_32-2978170446‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:32.540 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_32-2489974024‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:33.846 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_33-2252045339‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:34.062 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_34-4141069268‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:34.748 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_34-1905742805‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:34.954 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_34-532617590‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.087 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-2128126961‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.165 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-3589757392‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.265 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-1194916349‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.365 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-2857957391‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.436 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-4229605369‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.483 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-2553306541‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.601 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-1123924100‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.698 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-3152732305‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.800 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-2171770079‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:35.803 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_35-4138085619‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:36.173 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_36-842464167‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:36.838 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_36-1242111854‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:37.016 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_37-1566892518‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:44.613 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_44-4066544209‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:44.760 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_44-1783137110‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:44.823 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_44-2301593942‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:45.742 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_45-1877984950‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:45.814 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_45-754672564‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:45.819 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_45-3293372212‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:45.948 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_45-1430739623‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:46.097 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_46-1399724756‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:46.112 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_46-3573521198‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:46.195 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_46-1417055364‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:46.518 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_46-1984921820‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:46.707 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_46-153263945‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:47.451 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_47-2050879167‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:49.269 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_49-3638138601‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:12:49.654 Python[27806:5560287] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-27806-2026-02-17_21_12_49-3348384621‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-reagenzien - Query Reagenzien Lehre Linari retrieves reagent article

- Kommando: `./7w_wiki.py search Reagenzien Lehre Linari --source wiki`
- Laufzeit: 40.92s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Reagenzien Lehre Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 30.6s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magie_Grundlagen.md
   Kategorie: Fundament | Entitäten: [[Graumagie|Grauer Pfad]], [[Xan]], [[Brandenstein]], [[Ordo_Vitamae]], [[Sphärenkunde]]
   Chunk: 0/201 (1904 Zeichen)
   "# Magie Grundlagen

**Epistemischer Status:** #canon

Die Theorie der Magie auf [[Tare]] ist eine jahrtausendealte Wissenschaft, die das Verständnis der Elemente, der Sphären und der inneren Kraft des Geistes vereint.

## Die Quellen der Macht
### 1. Elementarmagie
Die rohe Magie wird durch die vier **[[Die_Gohor|Ur-Elemente]]** und ihre elementaren Herrscher ([[Enhor]]) gespeist:
*   **[[Ignis]] (Feuer):** Kraft der Zerstörung und radikalen Wandlung.
*   **[[Rien]] (Erde/Natur):** Kraft des Wachstums und der materiellen Stabilität.
*   **[[Ventus]] (Luft):** Kraft der Bewegung, des Schalls un..."

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Morsan]], [[Tare]], [[Astrael]], [[Dur]]
   Chunk: 0/202 (2333 Zeichen)
   "# Magietheorie (Toran [[Dur]])

**Epistemischer Status:** #überlieferung
**Autor:** Hochmagus Toran [[Dur]]
**Datum:** 26 n.H.

Dieser Artikel fasst die zentralen Lehren von Hochmagus Toran [[Dur]] zusammen, wie sie an der königlichen Akademie gelehrt werden. Er definiert Magie als die Manipulation des **Astralen Netzes** durch den sterblichen Geist.

## Definition und Ursprung
Magie gilt als eine der drei fundamentalen Konstanten der Existenz (neben Raum und Zeit). Während der Volksglaube [[Astrael]] als Schöpfer der Magie sieht, lehrt die Akademie, dass [[Astrael]] den Sterblichen lediglich..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 1/202 (850 Zeichen)
   "Lebewesen als Einheiten von **Aurenzentren** und Strömen. Die Summe dieser Ströme bildet die **Aura**.

### Theorie der größeren Ströme
Beschreibt magische Energieströme auf kontinentaler Ebene. Die Konvergenz dieser Ströme beeinflusst die Haltbarkeit von Zaubern und die Effektivität von Ritualen.

## Ritualkunde
Rituale lagern Komponenten der Magie auf Hilfsmittel (**Paraphernalia**) aus:
- **Anker:** (z.B. Edelsteine, Salz) zur Festigung von Geweben.
- **Foki:** (z.B. Lupen, Kerzen) zur Konzentration von Effekten.
- **Speicher:** (z.B. Arkanium) zum Sammeln astraler Kraft.

### Kreise
- **Ba..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Sorania]], [[Rien]], [[Tare]], [[Südfall]], [[Telandrion]]
   Chunk: 5/207 (2478 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Region | [DEFINITION_BENÖTIGT] | #canon |
| Regionen | [DEFINITION_BENÖTIGT] | #canon |
| Reich | [DEFINITION_BENÖTIGT] | #canon |
| Reiches | [DEFINITION_BENÖTIGT] | #canon |
| Reise | [DEFINITION_BENÖTIGT] | #canon |
| Religion | [DEFINITION_BENÖTIGT] | #canon |
| Richter | [DEFINITION_BENÖTIGT] | #canon |
| [[Rien]] | [DEFINITION_BENÖTIGT] | #canon |
| Ritter | [DEFINITION_BENÖTIGT] | #canon |
| Robaar | [DEFINITION_BENÖTIGT] | #canon |
| Rolle | [DEFINITION_BENÖTIGT] | #canon |
| Rothschild | [DEFINITION_BENÖTIGT] | #canon |
| Ruhe | [DEFINITION_BENÖTIGT]..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 107/202 (194 Zeichen)
   "reis:** Hält Einflüsse fern.
Beide nutzen die *Aversität* der Elemente (z.B. Feuer gegen Wasser), um Barrieren zu errichten.

## Siehe auch
- [[Das_Fundament]]
- [[Codex_Astraeli]]
- [[Astrael]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 148/201 (152 Zeichen)
   "xistenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 149/201 (151 Zeichen)
   "istenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Astrael.md
   Entitäten: [[Magie_Grundlagen]], [[Religion_Übersicht]], [[Die_Viere_Kirche]]
   Chunk: 164/200 (136 Zeichen)
   "ionen durch Verstand geleitet werden müssen.

## Verwandte Themen
- [[Religion_Übersicht]]
- [[Die_Viere_Kirche]]
- [[Magie_Grundlagen]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 154/201 (146 Zeichen)
   "z. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 155/201 (145 Zeichen)
   ". Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 152/201 (148 Zeichen)
   "enz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 145/201 (155 Zeichen)
   "r Existenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 153/201 (147 Zeichen)
   "nz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 151/201 (149 Zeichen)
   "tenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 150/201 (150 Zeichen)
   "stenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 15/201 (285 Zeichen)
   "rp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 4/201 (296 Zeichen)
   "le
*   **Corp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 33/201 (267 Zeichen)
   "r:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"
```

```text
2026-02-17 21:13:11.872 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_11-1964595029‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:11.985 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_11-2700425273‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:12.070 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_12-3587586481‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:12.142 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_12-3667433506‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:13.521 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_13-1777039665‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:13.752 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_13-3771128629‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:14.541 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_14-3602916727‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:14.744 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_14-2067429740‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:14.878 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_14-1341460577‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:14.958 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_14-1186547942‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.066 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-1647546710‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.241 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-3021175830‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.323 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-941092043‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.383 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-2154063222‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.553 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-3776599915‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.666 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-1429310656‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.773 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-2812242854‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:15.885 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_15-3412117816‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:16.269 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_16-2476983922‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:17.013 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_17-452324222‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:17.185 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_17-2263480959‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:27.685 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_27-1830497341‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:27.959 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_27-1492146327‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:28.029 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_28-1364189411‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:28.873 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_28-717881863‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:28.952 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_28-857979176‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:28.959 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_28-67979214‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:29.075 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_29-2797731216‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:29.152 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_29-3063075731‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:29.165 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_29-3706130298‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:29.250 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_29-1545041776‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:29.515 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_29-3069302141‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:29.769 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_29-1663328061‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:30.643 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_30-937031866‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:32.520 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_32-2806626821‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 21:13:32.848 Python[28128:5561234] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-28128-2026-02-17_21_13_32-2727106694‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

---
uuid: 5d1a64fb-3e22-419b-b998-00418202b5b7
status: FAIL
created_at: 2026-02-17T01:32:38Z
epistemic: "#meta"
---

# Test Run Report: rag-relevance-smoke

- Suite-Datei: `.agent/tests/suites/rag-relevance-smoke.json`
- Ergebnis: **FAIL**
- PASS: 0 | FAIL: 4 | SKIP: 0
- Laufzeit (gemessen): Summe 127.91s | Mittel 31.98s

| ID | Name | Status | Exit | Laufzeit (s) | Hinweis |
|---|---|---|---|---|---|
| `rag-status` | Index status reports coverage and writes archive register | FAIL | 1 | 16.73 | Exitcode 1 != erwartet 0 |
| `rag-q-dunvallo` | Query Dunvallo Linari retrieves core person article | FAIL | 0 | 41.79 | stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md' |
| `rag-q-matrix` | Query Matrixtheorie Linari retrieves matrix article | FAIL | 0 | 35.34 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md' |
| `rag-q-reagenzien` | Query Reagenzien Lehre Linari retrieves reagent article | FAIL | 0 | 34.05 | stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md' |

## FAIL: rag-status - Index status reports coverage and writes archive register

- Kommando: `./7w_wiki.py index --status`
- Laufzeit: 16.73s
- Grund: Exitcode 1 != erwartet 0

```text
⚠️  Config-Pfad /Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json nicht lesbar oder fehlerhaft (Permission oder Format): [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/.agent/skills/oracle/config.json'
📋 Config geladen: MPS (Batch: 4) aus .agent/config/runtime.json
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Indexierung                       ║
╚═══════════════════════════════════════════════════╝
  Repo:        /Users/alexandrerabe/siebenwind/7w_wiki
  Chunk-Größe: 2500 Zeichen (~357 Token)
  Modell:      jinaai/jina-embeddings-v3
  Modus:       ⚡ INKREMENTELL

  📊 Index-Status:
     siebenwind_quellen: 60151 Chunks | 288/300 Dateien (96.00% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
     siebenwind_wiki: 31700 Chunks | 157/1107 Dateien (14.18% Coverage)
       ⚠️  Stale Index-Eintraege: 1 (Dateien nicht mehr im Dateisystem)
Error executing .agent/skills/oracle/build_index.py: Command '['/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/venv/bin/python3', '/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py', '--status']' returned non-zero exit status 1.
```

```text
Traceback (most recent call last):
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1152, in <module>
    main()
    ~~~~^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 1085, in main
    payload, md_path, json_path = build_archive_register(rag_progress)
                                  ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 335, in build_archive_register
    rec = _register_record_for_file(corpus, path)
  File "/Users/alexandrerabe/siebenwind/7w_wiki/./.agent/skills/oracle/build_index.py", line 289, in _register_record_for_file
    if path.suffix.lower() not in REGISTER_EXTENSIONS or not path.is_file():
                                                             ~~~~~~~~~~~~^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_abc.py", line 482, in is_file
    return S_ISREG(self.stat(follow_symlinks=follow_symlinks).st_mode)
                   ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.9_1/Frameworks/Python.framework/Versions/3.13/lib/python3.13/pathlib/_local.py", line 515, in stat
    return os.stat(self, follow_symlinks=follow_symlinks)
           ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PermissionError: [Errno 1] Operation not permitted: '/Users/alexandrerabe/siebenwind/7w_wiki/System/DELEGATION_CODEX_PHASE_20.md'
```

## FAIL: rag-q-dunvallo - Query Dunvallo Linari retrieves core person article

- Kommando: `./7w_wiki.py search Dunvallo Linari --source wiki`
- Laufzeit: 41.79s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/07_Persoenlichkeiten/Dunvallo_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Dunvallo Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 30.7s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 95/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 96/201 (204 Zeichen)
   "Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 94/201 (206 Zeichen)
   ", Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 92/201 (208 Zeichen)
   "ll, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 91/201 (209 Zeichen)
   "all, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 98/201 (202 Zeichen)
   "hensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 99/201 (201 Zeichen)
   "ensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 100/201 (200 Zeichen)
   "nsvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Harwarn_Gropp]], [[Hagen_Robaar]], [[Luther_Dueff]], [[Falkenwall]], [[Benion_Sandelholz]]
   Chunk: 0/201 (2430 Zeichen)
   "# Siebenwind Bote 140

**Epistemischer Status:** #bote
**Datum:** 18. Querler 16 n.H.

## Überblick
Diese Ausgabe berichtet von der Gründung eines neuen Laienordens, einem bevorstehenden Schützenfest und der Hinrichtung eines berüchtigten Verbrechers. Zudem wird eine offizielle Liste der Lehensvasallen und Ritter von [[Siebenwind]] veröffentlicht.

## Wichtige Ereignisse
### Gründung des Ordens der Tränen Vitamas
Der Hochgeweihte **[[Benion_Sandelholz]]** (ehemals Abt des Ordo Vitamas) hat den [[Orden_der_Traenen_Vitamas]] ins Leben gerufen. Es handelt sich um einen Laienorden, der sich dem Mi..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_140.md
   Kategorie: Chronik | Entitäten: [[Cavalaron_Vendell]], [[Laurec_Llewellyen]], [[Isgrim]], [[Ovelia_Galthana]], [[Luther_Dueff]]
   Chunk: 28/201 (273 Zeichen)
   "Sandelholz]]
*   [[Isgrim]]
*   [[Laurec_Llewellyen]]
*   [[Luther_Dueff]]
*   [[Ovelia_Galthana]]
*   [[Cavalaron_Vendell]]
*   [[Orden_der_Traenen_Vitamas]]

## Referenzen
- Primärquelle: [Siebenwind Bote 140](../../Quellen/Zeitung%207w%20Bote/Siebenwind%20Bote%20140.md)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 101/201 (199 Zeichen)
   "svasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_129.md
   Kategorie: Chronik | Entitäten: [[Chronik]], [[Siebenwind_Bote_129]], [[Brandenstein]], [[Handelsbund]]
   Chunk: 87/201 (213 Zeichen)
   "rschall, Lehensvasall, Oberster Statthalter, Zunftherr, **Leiter der Königlichen Zensurbehörde**.

---
**Quellen:** [[Siebenwind_Bote_129]] (Original)
**Siehe auch:** [[Chronik]], [[Brandenstein]], [[Handelsbund]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_193.md
   Kategorie: Chronik | Entitäten: [[Custodias]], [[Claiomhs_Wacht]], [[Splitterfelsen]], [[Geduldiger_Sand]], [[Aschehorn]]
   Chunk: 0/201 (2176 Zeichen)
   "# Siebenwind Bote 193

**Epistemischer Status:** #bote
**Datum:** 17. Carmer 30 n.H.

## Überblick
Diese Ausgabe berichtet von einem Durchbruch bei den Friedensverhandlungen mit dem Lindwurm Akassvae, dem Erscheinen neuer drakonischer Bedrohungen und politischen Veränderungen in Dunquell.

## Die Lindwurm-Krise
### Friedensschluss mit Akassvae
Der Erzgeweihte **[[Custodias]]** führte erfolgreiche Verhandlungen mit dem grünen Lindwurm **[[Akassvae]]** und dem Echsen-Erdrufer **[[Geduldiger_Sand]]** in ihrer Feste in den [[Splitterfelsen]]. 
*   **Das Abkommen:** Akassvae und die ihr folgenden E..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 2/201 (298 Zeichen)
   "hekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 3/201 (297 Zeichen)
   "ekar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 4/201 (296 Zeichen)
   "kar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 7/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 8/201 (292 Zeichen)
   "[[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Handelsbund]], [[Benion_Sandelholz]], [[Chronik]]
   Chunk: 11/201 (289 Zeichen)
   "ldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/04_Chronik/Siebenwind_Bote_130.md
   Kategorie: Chronik | Entitäten: [[Greifenklipp]], [[Siebenwind_Bote_130]], [[Aldaro]], [[Handelsbund]], [[Benion_Sandelholz]]
   Chunk: 5/201 (295 Zeichen)
   "ar [[Aldaro]] plant Bibliotheksgründung auf Siebenwind.
- **Schelme:** Hochwürden [[Benion_Sandelholz]] (Geweihter) verteidigt die Schelme als treue Diener Vitamas.

---
**Quellen:** [[Siebenwind_Bote_130]] (Original)
**Siehe auch:** [[Chronik]], [[Handelsbund]], [[Greifenklipp]], [[Falkensee]]"
```

```text
2026-02-17 02:31:02.146 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_02-2473418001‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:02.271 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_02-1224911770‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:02.360 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_02-2801660790‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:02.437 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_02-2094022441‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:03.752 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_03-2251162306‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:03.987 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_03-1639431413‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:04.592 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_04-1356603691‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:04.815 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_04-996160181‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:04.944 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_04-3033072925‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.024 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-1309416807‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.128 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-1171582538‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.350 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-932109390‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.440 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-3628823459‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.495 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-2926872846‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.723 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-3941415823‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.833 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-4278783692‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.927 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-3329622761‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:05.943 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_05-1916472433‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:06.306 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_06-1726710201‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:07.066 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_07-1213693956‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:07.218 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_07-3309503272‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:16.092 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_16-2011157953‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:16.252 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_16-3413349063‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:16.316 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_16-2433327940‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.160 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-264623318‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.232 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-931870860‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.237 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-3632003739‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.331 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-1402159354‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.437 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-2482225197‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.461 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-1049470366‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.570 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-37140726‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:17.833 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_17-1404302361‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:18.044 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_18-4209121664‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:18.715 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_18-2036022907‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:20.506 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_20-1952217703‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:20.835 Python[51039:5129980] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51039-2026-02-17_02_31_20-3093342868‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-matrix - Query Matrixtheorie Linari retrieves matrix article

- Kommando: `./7w_wiki.py search Matrixtheorie Linari --source wiki`
- Laufzeit: 35.34s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Matrixtheorie_Linari.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Matrixtheorie Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 24.7s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Ventus]], [[Zwerge]], [[Vitama]]
   Chunk: 6/207 (2325 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Themen | [DEFINITION_BENÖTIGT] | #canon |
| Tiefenwald | [DEFINITION_BENÖTIGT] | #canon |
| Timeline | [DEFINITION_BENÖTIGT] | #canon |
| Tintin | [DEFINITION_BENÖTIGT] | #canon |
| Tion | [DEFINITION_BENÖTIGT] | #canon |
| Titel | [DEFINITION_BENÖTIGT] | #canon |
| Vandrien | [DEFINITION_BENÖTIGT] | #canon |
| Vencurius | [DEFINITION_BENÖTIGT] | #canon |
| [[Ventus]] | [DEFINITION_BENÖTIGT] | #canon |
| Verbindung | [DEFINITION_BENÖTIGT] | #canon |
| Verehrung | [DEFINITION_BENÖTIGT] | #canon |
| Verlinkte | [DEFINITION_BENÖTIGT] | #canon |
| Verwaltung | [D..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Angamon]], [[Xan]], [[Aequilibrium]]
   Chunk: 43/201 (257 Zeichen)
   "t.
*   [[Xan]] - Magie.

## Die Gegenspieler
*   [[Angamon]] - Der Dämonenfürst.

## Religionsphilosophie
*   [[Aequilibrium]] - Über den Dualismus und das göttliche Gleichgewicht.
*   [[Götter_und_Götzen]] - Abgrenzung der Viere von fremden Glaubensformen."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 14/201 (286 Zeichen)
   "e" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Aequilibrium.md
   Kategorie: Religion | Entitäten: [[Vitama]], [[Daemonen]], [[Untote]], [[Tare]], [[Codex_Astraeli]]
   Chunk: 0/201 (2189 Zeichen)
   "# Aequilibrium

**Epistemischer Status:** #überlieferung
**Autor:** [[Donarius_Derrvus]], Hochgeweihter des Ordo Astraeli
**Vollständiger Titel:** *Aequilibrium - Philosophie des Gleichgewichts das Tor des Bösen in unsere Sphäre?*

Das Werk **Aequilibrium** ist eine kritische Auseinandersetzung mit der "Theorie des Gleichgewichts", wie sie unter Druiden, Hexen, [[Elfen]] und Elementaristen verbreitet ist. Der Autor [[Donarius_Derrvus]] untersucht drei verschiedene Ebenen des Gleichgewichts und bewertet sie aus Sicht der [[Kirche_der_Viere]].

## Die drei Ebenen des Gleichgewichts

### 1. Das G..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 13/201 (287 Zeichen)
   "se" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 15/201 (285 Zeichen)
   "" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 16/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 17/201 (283 Zeichen)
   "Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 20/201 (280 Zeichen)
   "lismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 9/201 (291 Zeichen)
   ". Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 5/201 (295 Zeichen)
   "t vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 10/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 11/201 (289 Zeichen)
   "Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 4/201 (296 Zeichen)
   "ut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 6/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 7/201 (293 Zeichen)
   "vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 1/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Religion_Übersicht.md
   Kategorie: Fundament | Entitäten: [[Angamon]], [[Enhor]]
   Chunk: 2/201 (298 Zeichen)
   ""Gut vs. Böse" Dualismus.
- **Korrekt:** Ein komplexeres Geflecht aus Ordnung (Viere), Elementargewalt ([[Enhor]]) und Zerstörung ([[Angamon]]), eingebettet in einen drachischen Schöpfungsmythos.

Bitte bestätigen Sie, dass dieses Fundament nun korrekt ist, damit ich mit **Phase 2** beginnen kann."
```

```text
2026-02-17 02:31:41.712 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_41-1036995296‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:41.810 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_41-2836683875‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:41.893 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_41-3551278557‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:41.966 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_41-2860877223‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:43.340 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_43-3160277540‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:43.580 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_43-1842420375‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.033 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-2042538460‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.225 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-2836569874‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.345 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-3687360203‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.416 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-252108569‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.504 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-1092196033‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.607 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-1734192445‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.669 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-3755704681‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:44.712 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_44-1114059767‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:45.039 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_45-88486304‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:45.163 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_45-4227218306‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:45.252 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_45-3583002097‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:45.255 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_45-1754619748‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:45.625 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_45-1012030742‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:46.279 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_46-1282643294‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:46.446 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_46-1382047807‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:53.223 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_53-1372028840‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:53.302 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_53-3754495985‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:53.358 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_53-1858412809‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.146 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-1983029286‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.217 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-919510057‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.222 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-2487338517‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.352 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-1871373913‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.424 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-2688137934‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.438 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-1887702334‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.523 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-2818323747‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:54.835 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_54-2865217323‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:55.020 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_55-4264677884‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:55.835 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_55-3912874212‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:57.600 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_57-318490617‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:31:57.913 Python[51858:5131657] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51858-2026-02-17_02_31_57-126419295‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

## FAIL: rag-q-reagenzien - Query Reagenzien Lehre Linari retrieves reagent article

- Kommando: `./7w_wiki.py search Reagenzien Lehre Linari --source wiki`
- Laufzeit: 34.05s
- Grund: stdout enthaelt nicht: 'Siebenwind_Wiki/05_Magie/Reagenzien_Lehre.md'

```text
╔═══════════════════════════════════════════════════╗
║   Das Orakel – Semantische Suche                 ║
╚═══════════════════════════════════════════════════╝
  Query: "Reagenzien Lehre Linari"
  Quelle: wiki | Top: 20 | Re-Rank: Ja

  🧠 Lade Modell... ✅

  ⏱️  Suchzeit: 23.9s
  📋 Top-20 Ergebnisse:

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magie_Grundlagen.md
   Kategorie: Fundament | Entitäten: [[Graumagie|Grauer Pfad]], [[Xan]], [[Brandenstein]], [[Ordo_Vitamae]], [[Sphärenkunde]]
   Chunk: 0/201 (1904 Zeichen)
   "# Magie Grundlagen

**Epistemischer Status:** #canon

Die Theorie der Magie auf [[Tare]] ist eine jahrtausendealte Wissenschaft, die das Verständnis der Elemente, der Sphären und der inneren Kraft des Geistes vereint.

## Die Quellen der Macht
### 1. Elementarmagie
Die rohe Magie wird durch die vier **[[Die_Gohor|Ur-Elemente]]** und ihre elementaren Herrscher ([[Enhor]]) gespeist:
*   **[[Ignis]] (Feuer):** Kraft der Zerstörung und radikalen Wandlung.
*   **[[Rien]] (Erde/Natur):** Kraft des Wachstums und der materiellen Stabilität.
*   **[[Ventus]] (Luft):** Kraft der Bewegung, des Schalls un..."

📖 [WIKI] Score: 0.001 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Morsan]], [[Tare]], [[Astrael]], [[Dur]]
   Chunk: 0/202 (2333 Zeichen)
   "# Magietheorie (Toran [[Dur]])

**Epistemischer Status:** #überlieferung
**Autor:** Hochmagus Toran [[Dur]]
**Datum:** 26 n.H.

Dieser Artikel fasst die zentralen Lehren von Hochmagus Toran [[Dur]] zusammen, wie sie an der königlichen Akademie gelehrt werden. Er definiert Magie als die Manipulation des **Astralen Netzes** durch den sterblichen Geist.

## Definition und Ursprung
Magie gilt als eine der drei fundamentalen Konstanten der Existenz (neben Raum und Zeit). Während der Volksglaube [[Astrael]] als Schöpfer der Magie sieht, lehrt die Akademie, dass [[Astrael]] den Sterblichen lediglich..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 1/202 (850 Zeichen)
   "Lebewesen als Einheiten von **Aurenzentren** und Strömen. Die Summe dieser Ströme bildet die **Aura**.

### Theorie der größeren Ströme
Beschreibt magische Energieströme auf kontinentaler Ebene. Die Konvergenz dieser Ströme beeinflusst die Haltbarkeit von Zaubern und die Effektivität von Ritualen.

## Ritualkunde
Rituale lagern Komponenten der Magie auf Hilfsmittel (**Paraphernalia**) aus:
- **Anker:** (z.B. Edelsteine, Salz) zur Festigung von Geweben.
- **Foki:** (z.B. Lupen, Kerzen) zur Konzentration von Effekten.
- **Speicher:** (z.B. Arkanium) zum Sammeln astraler Kraft.

### Kreise
- **Ba..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Menschen]], [[Myten]], [[Orken]], [[Morsan]]
   Chunk: 4/207 (2495 Zeichen)
   "gs | [DEFINITION_BENÖTIGT] | #canon |
| Lafay | [DEFINITION_BENÖTIGT] | #canon |
| Land | [DEFINITION_BENÖTIGT] | #canon |
| Leben | [DEFINITION_BENÖTIGT] | #canon |
| Lebens | [DEFINITION_BENÖTIGT] | #canon |
| Lehnsherr | [DEFINITION_BENÖTIGT] | #canon |
| Level | [DEFINITION_BENÖTIGT] | #canon |
| Librasulus | [DEFINITION_BENÖTIGT] | #canon |
| Lichtenfeld | [DEFINITION_BENÖTIGT] | #canon |
| Liebe | [DEFINITION_BENÖTIGT] | #canon |
| Lore | [DEFINITION_BENÖTIGT] | #canon |
| Luft | [DEFINITION_BENÖTIGT] | #canon |
| Löwenorden | [DEFINITION_BENÖTIGT] | #canon |
| Macht | [DEFINITION_BENÖTI..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Glossar.md
   Kategorie: Fundament | Entitäten: [[Sorania]], [[Rien]], [[Tare]], [[Südfall]], [[Telandrion]]
   Chunk: 5/207 (2478 Zeichen)
   "[DEFINITION_BENÖTIGT] | #canon |
| Region | [DEFINITION_BENÖTIGT] | #canon |
| Regionen | [DEFINITION_BENÖTIGT] | #canon |
| Reich | [DEFINITION_BENÖTIGT] | #canon |
| Reiches | [DEFINITION_BENÖTIGT] | #canon |
| Reise | [DEFINITION_BENÖTIGT] | #canon |
| Religion | [DEFINITION_BENÖTIGT] | #canon |
| Richter | [DEFINITION_BENÖTIGT] | #canon |
| [[Rien]] | [DEFINITION_BENÖTIGT] | #canon |
| Ritter | [DEFINITION_BENÖTIGT] | #canon |
| Robaar | [DEFINITION_BENÖTIGT] | #canon |
| Rolle | [DEFINITION_BENÖTIGT] | #canon |
| Rothschild | [DEFINITION_BENÖTIGT] | #canon |
| Ruhe | [DEFINITION_BENÖTIGT]..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Magietheorie_Toran_Dur.md
   Kategorie: Fundament | Entitäten: [[Codex_Astraeli]], [[Das_Fundament]], [[Astrael]]
   Chunk: 107/202 (194 Zeichen)
   "reis:** Hält Einflüsse fern.
Beide nutzen die *Aversität* der Elemente (z.B. Feuer gegen Wasser), um Barrieren zu errichten.

## Siehe auch
- [[Das_Fundament]]
- [[Codex_Astraeli]]
- [[Astrael]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Das_Pantheon.md
   Kategorie: Index | Entitäten: [[Götter_und_Götzen]], [[Aequilibrium]], [[Rien]], [[Brevier_Ordo_Vitamae]], [[Die_Gohor]]
   Chunk: 0/201 (943 Zeichen)
   "# Das Pantheon

**Epistemischer Status:** #canon

Die Mächte, die Falandrien und [[Siebenwind]] formen.

## Die Ur-Sphäre
*   [[Die_Gohor]] - Die Ur-[[Drachen]] und Schöpfer.

## Die Viereinigkeit (Die Guten)
*   [[Astrael]] - Wissen & Ordnung.
*   [[Bellum]] - Kampf & Ehre.
*   [[Vitama]] - Leben & Heilung.
*   [[Morsan]] - Tod & Ruhe.
*   [[Codex_Astraeli]] - Philosophischer Leitfaden der Astraeli.
*   [[Brevier_Ordo_Belli]] - Gebetssammlung des Kriegsordens.
*   [[Brevier_Ordo_Morsanes]] - Totenruhe & Schweigen.
*   [[Brevier_Ordo_Vitamae]] - Segen, Heilung & Fruchtbarkeit.

## Die Elemen..."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 148/201 (152 Zeichen)
   "xistenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 149/201 (151 Zeichen)
   "istenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/01_Pantheon/Astrael.md
   Entitäten: [[Magie_Grundlagen]], [[Religion_Übersicht]], [[Die_Viere_Kirche]]
   Chunk: 164/200 (136 Zeichen)
   "ionen durch Verstand geleitet werden müssen.

## Verwandte Themen
- [[Religion_Übersicht]]
- [[Die_Viere_Kirche]]
- [[Magie_Grundlagen]]"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 154/201 (146 Zeichen)
   "z. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 155/201 (145 Zeichen)
   ". Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 152/201 (148 Zeichen)
   "enz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 145/201 (155 Zeichen)
   "r Existenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 153/201 (147 Zeichen)
   "nz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 151/201 (149 Zeichen)
   "tenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Tare.md
   Kategorie: Fundament | Entitäten: [[Kirche_der_Viere]]
   Chunk: 150/201 (150 Zeichen)
   "stenz. Gelehrte der [[Kirche_der_Viere]] mahnen zur Wahrung der göttlichen Ordnung auf Tare, um den Fortbestand des Lebens gegen das Chaos zu sichern."

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 15/201 (285 Zeichen)
   "rp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 4/201 (296 Zeichen)
   "le
*   **Corp:** Tod
*   **Dyr:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"

📖 [WIKI] Score: 0.000 (re-ranked)
   Quelle: Siebenwind_Wiki/00_Fundament/Die_Sprache_Run.md
   Kategorie: Fundament
   Chunk: 33/201 (267 Zeichen)
   "r:** Wille
*   **Enwunji:** Buch
*   **Odal:** Magie

---
> [!TIP]
> Die Substantivierung erfolgt oft über die Endung **~ai** (Der, der etwas tut, z.B. *Odalj* - Magier).

**Quelle:** [Die Sprache Run.html](../../Quellen/Bibliothek%20Astrael/Die%20Sprache%20Run.html)"
```

```text
2026-02-17 02:32:15.910 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_15-2126723417‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:15.998 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_15-1663520666‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:16.070 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_16-3539086540‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:16.136 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_16-2739550751‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:17.393 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_17-1590252570‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:17.633 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_17-397010073‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:17.918 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_17-2389375598‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.126 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-245077194‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.252 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-672847860‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.340 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-3920305447‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.448 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-2894016959‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.555 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-790386882‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.630 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-3592506583‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.679 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-1599170818‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.794 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-629666966‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.889 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-896682281‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:18.998 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_18-722306902‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:19.100 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_19-103851964‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:19.175 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_19-2324330882‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:19.778 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_19-2551448701‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:19.923 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_19-2692556530‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:27.094 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_27-2165789194‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:27.178 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_27-577299346‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:27.236 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_27-3969370037‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.066 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-3259941580‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.141 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-3079168045‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.146 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-43193659‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.235 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-2903807785‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.316 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-3294794747‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.329 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-2747215719‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.412 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-2560356537‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.664 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-4193254963‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:28.845 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_28-2974936572‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:29.536 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_29-2745321579‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:31.316 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_31-187149335‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
2026-02-17 02:32:31.624 Python[51875:5132320] Error creating directory 
 You don‚Äôt have permission. You don‚Äôt have permission to save the file ‚Äúmpsgraph-51875-2026-02-17_02_32_31-3490976321‚Äù in the folder ‚Äúcom.apple.MetalPerformanceShadersGraph‚Äù.
```

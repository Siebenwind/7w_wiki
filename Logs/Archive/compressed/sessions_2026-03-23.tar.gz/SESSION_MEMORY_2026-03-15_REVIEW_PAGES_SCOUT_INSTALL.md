# Session Memory: Review / Pages / Scout / Install Runtime

- Date: 2026-03-15
- Focus: whole-wiki review batch, Pages-visible dashboards, inquisitive scout intake, and archive-first install/package paths

## What Changed
- Added `./7w_wiki.py review` with Pages-aware, read-only findings, JSON snapshots, and a Pages-readable dossier at `docs/Archiv/WIKI_REVIEW_DOSSIER.md`.
- Extended `./7w_wiki.py score` with `--json` and `--dry-run` so score inspection no longer mutates files by default.
- Reworked canonical path handling to prefer `docs/Siebenwind_Wiki` and `docs/Quellen`, and updated Pages/statistics/audit consumers accordingly.
- Rebuilt `./7w_wiki.py scout` into a confidence-based intake path with `geschichten` support, IC/OOC/Mixed routing, date confidence, duplicate checks, and a Pages-readable dashboard at `docs/Archiv/SCOUT_INTAKE.md`.
- Added `./7w_wiki.py install` and `./7w_wiki.py package` with `full` / `agent-only` profiles, `system` / `bundled` / `auto` toolchain modes, Ubuntu/Debian-first ordering, and archive-first packaging manifests.
- Extended stats output with a new `Wissensverfuegbarkeit` section plus matching machine snapshot keys, and mirrored the reader page to both canonical docs and the legacy root path.
- Synced governance inventories and tool manifest from the live CLI schema; updated workflow/docs references and registered new files in `System/COORDINATION_HUB.md`.

## Verification
- `./7w_wiki.py stats --json`
- `./7w_wiki.py review --category 00_Fundament --oracle-limit 0 --json`
- `./7w_wiki.py scout --forum geschichten --pages 1 --json`
- `./7w_wiki.py package --platform ubuntu --profile agent-only --json`
- `./7w_wiki.py tech --sync-docs`
- `./7w_wiki.py tech --sync-matrix`
- `./7w_wiki.py tech --manifest`
- `./7w_wiki.py test --suite reader-stats-contract`
- `./7w_wiki.py test --suite review-install-contract`
- `./7w_wiki.py test --suite interop-command-registry`
- `./7w_wiki.py test --suite tool-manifest-contract`

## Notes / Next
- The new review logic currently reuses the cached Pages snapshot by default and only refreshes MkDocs diagnostics with `--refresh-pages`.
- `scout --forum geschichten` returns a structured triage object even when network access blocks the forum fetch; low-confidence and scan-error cases still land in the intake queue.
- Archive packages are now produced under `dist/`; optional bundled toolchain directories are declared in config but not yet populated in this repo.

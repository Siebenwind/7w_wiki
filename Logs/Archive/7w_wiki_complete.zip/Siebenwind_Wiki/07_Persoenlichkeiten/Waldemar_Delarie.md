---
layout: wiki_page
title: Waldemar Delarie
category: Persönlichkeit
---

# Waldemar Delarie

**Titel:** Edelherr, ehemaliger Gardehauptmann der [[Finianswacht]]
**Epistemischer Status:** #canon
**Zugehörigkeit:** Ersonter Bund / Haus Delarie
**Zeitraum:** Aktiv (Bis ca. 28 n.H. als Hauptmann)

## Beschreibung
Waldemar Delarie war über Jahre hinweg der militärische Kopf von [[Falkensee]]. Als Hauptmann der Garde ([[Finianswacht]]) und überzeugter Anhänger des Ersonter Bundes trieb er den Ausbau der Infrastruktur und die militärische Sicherung der Region voran. Er gilt als stolzer, oft eigenwilliger Führer, dessen Name eng mit dem sogenannten "Putsch von [[Falkensee]]" verbunden ist.

## Karriere & Timeline
- **Frühe Jahre:** Übernahme der Hauptmannschaft von **Hauptmann Mengars**.
- **~25 n.H.:** Reise nach **Papin**, um Goldbarren zur Unterstützung von Wallenburg an den Ersonter Bund (Graf Gero) zu übergeben.
- **~26-28 n.H. (Der Putsch):** In Waldemars Abwesenheit führt sein Stellvertreter **[[Hektor]]** eine gewaltsame Aktion gegen den Rat durch. Waldemar wird bei seiner Rückkehr der Mitwissenschaft beschuldigt und verliert seinen Rang.
- **Späte Jahre:** Rückzug nach **[[Südfall]]**, wo er ein Haus bewohnt, aber politisch isoliert bleibt.

## Wirken
- Bau der Straße nach [[Südfall]].
- Herausgeber der "Ersonter Postille" (später verboten).
- Sicherung des Friedens mit den [[Rasse_Orken]] durch diplomatische Missionen.

## Konflikte
Waldemar hegte eine tiefe Feindschaft gegenüber dem Hochgeweihten **[[Custodias]]**, den er offen des Hochverrats und der Ketzerei beschuldigte.


## Überlieferungen
- [[Zeitstrahl]]: Erwähnung in der Überlieferung.
- [[Waldemar_Delaries_Reise_nach_Papin]]: Erwähnung in der Überlieferung.
- [[Der_Putsch_von_Falkensee]]: Erwähnung in der Überlieferung.
## Quellen
- [[Adelskalender]]
- [[Waldemars_Reise_Papin]] (Erzählung)

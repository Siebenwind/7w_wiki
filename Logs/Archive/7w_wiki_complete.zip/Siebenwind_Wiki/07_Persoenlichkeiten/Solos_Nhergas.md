---
layout: wiki_page
title: Solos [[Nhergas]]
category: Persönlichkeit
---

# Solos [[Nhergas]]

**Titel:** Kanzlerin des Inselrats, Freifrau, vorm. Lehenskanzlerin
**Epistemischer Status:** #canon
**Zugehörigkeit:** [[Inselrat]] / Dienstadel
**Zeitraum:** Aktiv ab ca. 15 n.H. (aktuell Kanzlerin)

## Karriere & Timeline
- **Vor 18 n.H.:** Lehenskämmerin und später Lehenskanzlerin unter Hagen Robaar (Bote 151). Ernennung zum niederen Dienstadel (Edelfrau).
- **18 n.H.:** Ernennung zur (vorübergehenden) Inselpatrizierin durch Hagen Robaar bei dessen Machtübergabe (Bote 155).
- **Später:** Wahl zur Kanzlerin des Inselrats als Nachfolgerin von Großmeister [[Adhemar_Ravenforth]] (Bote 192). Sie übernahm das Amt inmitten der Unruhen um den **Putsch der Garde** (ca. 26-28 n.H.) und profilierte sich als besonnene Vermittlerin.
- **Politische Haltung:** Sie rettete [[Waldemar_Delarie]] vor der gänzlichen Ächtung, bestand aber auf seinem Rückzug aus [[Falkensee]].

## Wirken
Sie gilt als Koryphäe der Etikette und Rechtskunde. Ihr Ziel ist die Einigung der Inselvölker gegen die Bedrohung aus dem Osten.


## Überlieferungen
- [[Zeitstrahl]]: Erwähnung in der Überlieferung.
- [[Waldemar_Delaries_Reise_nach_Papin]]: Erwähnung in der Überlieferung.
- [[Der_Putsch_von_Falkensee]]: Erwähnung in der Überlieferung.
- [[Waldemars_Reise_Papin]]: Erwähnung in der Überlieferung.
## Quellen
- [[Adelskalender]]
- [[Siebenwind_Bote_151]]
- [[Siebenwind_Bote_155]]
- [[Siebenwind]] Bote 192

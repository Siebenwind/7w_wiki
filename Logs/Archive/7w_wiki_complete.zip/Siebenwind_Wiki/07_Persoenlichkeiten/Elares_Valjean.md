---
layout: wiki_page
title: Elares Valjean
category: [[Persönlichkeiten]]
---

# Elares Valjean

**Epistemischer Status:** #bote

Ein ehemaliges Mitglied oder Protektor des Hauses von [[Gerdenwald]], der in Ungnade gefallen ist.

## [[Geschichte]]
Im [[Siebenwind_Bote_122]] wurde ein offizielles Ultimatum gegen ihn ausgesprochen. Ihm wurde vorgeworfen, Verbrechen begangen zu haben, woraufhin sein Leben als verwirkt erklärt wurde. Es wurde ein Kopfgeld auf ihn ausgesetzt, und jeder, der ihm Unterschlupf gewährt, wurde mit schwersten Strafen bedroht.

Er galt fortan als vogelfrei innerhalb der Grenzen des Barons.

---
layout: wiki_page
title: Tion Altor
category: Persönlichkeit
---

# Tion Altor

**Titel:** Erzgeweihter Bellums, Kanzler der Baronie [[Siebenwind]]
**Epistemischer Status:** #canon
**Zugehörigkeit:** Kirche des [[03_Bellum]] / [[Inselrat]]
**Zeitraum:** Aktiv (Rückkehr 29 n.H.)

## Beschreibung
Seine Eminenz Tion Altor ist ein hochrangiger Priester des Gottes [[03_Bellum]]. Er führt die Amtsgeschäfte als Kanzler der Baronie [[Siebenwind]].

## Karriere & Timeline
- **29 n.H.:** Rückkehr von einer diplomatischen Reise auf das Festland (Bote 190).
- **Aktuell:** Führung in der Krise gegen den Dämon Orgolosch.


## Überlieferungen
- [[Zeitstrahl]]: Erwähnung in der Überlieferung.
## Quellen
- [[Adelskalender]]
- [[Siebenwind]] Bote 190

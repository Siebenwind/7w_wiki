---
layout: wiki_page
title: Siegfried_Steiner
category: Persönlichkeit
---

# Siegfried Steiner

**Titel:** Großmeister der [[Ritter_der_Sieben_Winde]]
**Epistemischer Status:** #bote
**Zugehörigkeit:** [[Ritter_der_Sieben_Winde]]
**Zeitraum:** aktiv ab 18 n.H.

## Beschreibung
Siegfried Steiner (oft mit ~SS~ gezeichnet) ist ein hochrangiger Ritter und der 8. Großmeister des Ordens der [[Ritter_der_Sieben_Winde]]. Sein Handeln ist geprägt von militärischer Disziplin und einem tiefen Verantwortungsgefühl für das Wohlergehen der Insel [[Siebenwind]] und ihrer Bewohner.

### Ernennung zum Großmeister und Hochmeister (20 n.H.)
Im Jahr 20 n.H. (Bote 173) wurde Siegfried Steiner offiziell zum **Großmeister** der [[Ritter_der_Sieben_Winde]] und **Hochmeister** des [[Orden_der_Wachenden_Löwen|Drachenordens]] ernannt. Er folgte damit einer langen Tradition und übernahm die Führung in einer Zeit militärischer Umstrukturierung und der Bedrohung durch das [[Dunkeltief]].

## Persönlichkeit
Steiner gilt als pragmatischer Anführer, der bereit ist, außergewöhnliche Maßnahmen zu ergreifen, um die Ordnung zu bewahren. Seine Unterzeichnung der Siebenwindakte wird als Wendepunkt in der politischen [[Geschichte]] der Baronie angesehen. Er ist bekannt für seine enge Zusammenarbeit mit [[Mirian_Lasar]] im Zuge der militärischen Reformen.

---
**Quellen:** [[Siebenwind_Bote_155]], [[Siebenwind_Bote_173]], [[Ritter_der_Sieben_Winde]] 

## Überlieferungen
- [[Siebenwindakte]]: Erwähnung in der Überlieferung.

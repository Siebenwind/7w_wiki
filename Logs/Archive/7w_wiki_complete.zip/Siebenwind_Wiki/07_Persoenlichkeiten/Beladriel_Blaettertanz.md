---
layout: wiki_page
title: Beladriel Blättertanz
category: Persönlichkeit
---

# Beladriel Blättertanz

**Titel:** Baronin, Wohlgeboren
**Epistemischer Status:** #bote
**Zugehörigkeit:** Adel von [[Siebenwind]]
**Zeitraum:** aktiv um 18-19 n.H.

## Beschreibung
Beladriel Blättertanz ist die Baronin der Kronmark [[Siebenwind]]. Sie gilt als reformfreudige Herrscherin, die bestrebt ist, die rechtlichen und sozialen Strukturen der Insel zu modernisieren und zu festigen.

## Wirken
Im 19. Götterlauf nach König Hilgorads Krönung (19 n.H.) verkündete sie das neue **[[Statut_der_Kronmark_Siebenwind]]**. Dieses bedeutende politische Dokument ordnete die Machtbefugnisse zwischen der Ritterschaft, dem Gericht und den [[Inselpatrizier|Inselpatriziern]] neu. Zudem ordnete sie die Auflösung alter Milizverträge an, um die Sicherheit der Kronmark unter zentraler Verwaltung zu vereinheitlichen.

Ihre Entscheidungen trafen nicht überall auf ungeteilte Zustimmung, markierten jedoch einen Wendepunkt in der Verwaltung der Insel.

---
**Siehe auch:** [[Statut_der_Kronmark_Siebenwind]], [[Inselrat]]
**Quellen:** [[Siebenwind_Bote_170]], [[Siebenwind_Bote_166]]

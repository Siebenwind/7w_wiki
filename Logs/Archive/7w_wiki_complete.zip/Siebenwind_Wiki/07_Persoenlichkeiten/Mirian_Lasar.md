---
layout: wiki_page
title: Mirian_Lasar
category: Persönlichkeit
---

# Mirian Lasar

**Titel:** Heermeisterin und Hochmeisterin des [[Orden_der_Wachenden_Löwen|Greifenordens]]
**Epistemischer Status:** #bote
**Zugehörigkeit:** [[Ritter_der_Sieben_Winde]], [[Orden_der_Wachenden_Löwen]]
**Zeitraum:** aktiv ab 20 n.H.

## Beschreibung
Mirian Lasar ist eine fähige Strategin und Ritterin, die im Jahr 20 n.H. zur **Heermeisterin** der [[Ritter_der_Sieben_Winde]] und **Hochmeisterin** des Greifenordens ernannt wurde. Sie ist bekannt für ihre militärische Strenge und ihre Bemühungen, die Verteidigung der Baronie gegen das [[Dunkeltief]] zu koordinieren.

## Wirken

### Militärische Reformen (20 n.H.)
Unter ihrer Führung wurden signifikante Reformen im Militärwesen eingeleitet. Sie koordinierte die Zusammenarbeit der verschiedenen Ordenszweige und leitete die Verteidigungsmaßnahmen in [[Falkensee]] und [[Brandenstein]].

### Kampf gegen das [[Dunkeltief]]
Lasar war maßgeblich an der Planung der Vorstöße in das [[Dunkeltief]] beteiligt, um die Bedrohung durch die Schattenwesen einzudämmen.

---
**Quellen:** [[Siebenwind_Bote_173]], [[Ritter_der_Sieben_Winde]]

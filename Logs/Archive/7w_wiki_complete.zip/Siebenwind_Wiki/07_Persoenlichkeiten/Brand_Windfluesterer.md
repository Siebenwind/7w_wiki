---
layout: wiki_page
title: Brand Windflüsterer
category: Persönlichkeit
---

# Brand Windflüsterer

**Titel:** Priester des [[Enhor]]
**Epistemischer Status:** #bote
**Zugehörigkeit:** [[Ecclesia_Elementorum]]
**Zeitraum:** aktiv um 19 n.H.

## Beschreibung
Brand Windflüsterer ist ein Priester des Windgottes [[Enhor]]. Er ist bekannt für sein feuriges Temperament und seine strenge Auslegung der Ordensregeln, insbesondere was die Neutralität der Geweihten betrifft.

## Wirken
Berühmt-berüchtigt wurde er durch den Vorfall beim Kronregiment im Jahr 19 n.H. Dort geriet er mit der Heilerin **[[Isfaldia]]** in einen heftigen Streit. In seinem Zorn setzte er die "Gabe des [[Ventus]]" ein, um die Aspirantin zu blenden, und griff sie später sogar mit einem Luftgeist an.

Dieser gewaltsame Ausbruch führte zu einer offiziellen Ermahnung durch die Führung der Ecclesia. Erst nach klärenden Gesprächen zwischen dem Regiment und dem Klerus konnte die Situation beruhigt werden.

---
**Siehe auch:** [[Brand_Windfluesterers_Zorn]], [[Isfaldia]]
**Quellen:** [[Siebenwind_Bote_169]]

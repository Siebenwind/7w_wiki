---
layout: wiki_page
title: Marnie Ruatha
category: Persönlichkeit
---

# Marnie Ruatha

**Titel:** Überlebende des Ödlands
**Epistemischer Status:** #canon / #perspektive
**Zugehörigkeit:** Volk der [[Rasse_Menschen]] / [[Falkensee]]
**Zeitraum:** Aktiv ca. 25-30 n.H.

## Beschreibung
Marnie Ruatha ist eine Bewohnerin von [[Falkensee]], die in die Schrecken jenseits des Walls hineingezogen wurde. Sie wurde Zeugin der Transformation von **[[Sorania]]** und des Todes von **[[Emanuel]]**.

## Schicksal: [[Jenseits_des_Walls]]
- **Die Gefangenschaft:** Marnie wurde gemeinsam mit [[Sorania]] und [[Emanuel]] von den Schlangenwesen verschleppt. In den Verliesen wurde sie Zeugin von grausamen Experimenten und rituellen Folterungen.
- **Flucht/Rettung:** Während [[Sorania]] und [[Emanuel]] dem [[Ödland]] verfielen, gelang Marnie (möglicherweise mit Hilfe des Löwenordens) die Rückkehr in bewohntes Gebiet.
- **Trauma:** In ihren Berichten schildert sie die Sammler (Schlangenwesen) als "schlechte Gastgeber", die ihre Gefangenen mit Wein betäuben und sie dann psychisch und physisch brechen.


## Überlieferungen
- [[Zeitstrahl]]: Erwähnung in der Überlieferung.
- [[Die_Tragödie_am_Wall]]: Erwähnung in der Überlieferung.
## Quellen
- [[Jenseits_des_Walls]] (Erzählung)

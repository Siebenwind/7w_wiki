---
layout: wiki_page
title: Yves_Rondragon
category: Persönlichkeit
---

# Yves Rondragon

**Titel:** Ritter / Lehnsherr von [[Seeberg]]
**Epistemischer Status:** #bote
**Zugehörigkeit:** [[Ritter_der_Sieben_Winde]]
**Zeitraum:** aktiv ab 20 n.H.

## Beschreibung
Yves Rondragon ist ein [[Ritter_der_Sieben_Winde]], der im Jahr 20 n.H. seinen Ritterschlag erhielt. Kurz darauf wurde er zum **Lehnsherrn von [[Seeberg]]** ernannt, was seinen schnellen Aufstieg innerhalb der Adelshierarchie markiert.

## Wirken

### Ritterschlag und Belehnung (20 n.H.)
Yves wurde im Onar des Jahres 20 n.H. zum Ritter geschlagen. Seine Ernennung zum Lehnsherrn von [[Seeberg]] erfolgte im Zuge der Reorganisation der Kronmark.

---
**Quellen:** [[Siebenwind_Bote_172]], [[Siebenwind_Bote_173]]

---
layout: wiki_page
title: [[Siebenwind]] Bote 122
category: Chronik
---

# [[Siebenwind]] Bote 122

**Epistemischer Status:** #bote

## [Sonderausgabe] Ultimatum der Garde des Barons
**Persona:** [[Elares_Valjean]]
**Fraktion:** Bund der Tapferen / Garde des Barons
**Thema:** Hochverrat und Ultimatum.
**Inhalt:** [[Elares_Valjean]] wird aufgefordert, sich innerhalb von drei Tagen und Nächten unbewaffnet in der Burg zu ergeben und Rechenschaft abzulegen. Andernfalls gilt sein Leben als verwirkt. Jegliche Unterstützung für ihn oder seine Begleiter wird mit schwersten Strafen belegt.
**Autor:** *J.D.* (im Namen des Barons, Lehensherr zu Tannenstein, Protektor des Hauses v. Gerdenwald)

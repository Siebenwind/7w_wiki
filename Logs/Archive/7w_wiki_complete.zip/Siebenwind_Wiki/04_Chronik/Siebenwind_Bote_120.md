---
layout: wiki_page
title: [[Siebenwind]] Bote 120
category: Chronik
---

# [[Siebenwind]] Bote 120

**Epistemischer Status:** #bote

## Bekanntmachung der Lehensverwaltung
**Thema:** Mietzahlungen in [[Brandenstein]].
**Inhalt:** Mietschulden führen zum Rauswurf aus dem jeweiligen Haus. Zahlungen sind direkt beim Magistrat oder im Rathaus zu entrichten.
**Aktenzeichen:** BS 34
**Autor:** *Au*

## Ein Rückblick auf die Auktion
**Thema:** Güter vom Festland.
**Inhalt:** Rückblick auf ein Spektakel, das die Kluft zwischen Arm und Reich aufzeigte. Seltene, teilweise exotische Früchte und Stoffe wurden im Hafen ausgestellt und unter Bewachung versteigert.
**Autor:** *Au*

## Bauarbeiten in der neuen Hauptstadt
**Thema:** Stadtentwicklung Brandensteins.
**Inhalt:** Transformation einer wilden Waldlandschaft in eine prächtige Stadt. Es wird händeringend nach Bauarbeitern gesucht ("Bauarbeiter gesucht!").
**Autor:** *Au*

## [[Goblins]] - eine Gefahr für [[Brandenstein]]?
**Thema:** Übergriffe durch [[Goblins]].
**Inhalt:** Ein Augenzeugenbericht schildert, wie zwei kleine [[Goblins]] (einen halben Schritt groß) den Zeugen angriffen, um Fischbrot zu stehlen. Dukaten ließen sie unbeachtet.
**Autor:** *J.D.*

## Vorkommnisse in der Thar'Sala
**Thema:** Ermittlungen in der Thar'Sala.
**Inhalt:** Es wird gemunkelt, eine namentlich nicht genannte Person stünde mit "dem Einen" im Bunde. Eine Hausdurchsuchung wurde eingeleitet.
**Autor:** *Au*

## Sicherheit oder ein gutes Geschäft
**Thema:** Handelsrisiken und Wildnisgefahren.
**Inhalt:** Kritik am gedankenlosen Handel in gefährlichen Zeiten. Erwähnung von Trollen und Bären, die Siedlungen und Häuser bedrohen.
**Autor:** *Au*

## Der Regen
**Typ:** Lyrik
**Text:** "Schwere Tropfen prasseln nieder..."
**Autor:** *J.D.*

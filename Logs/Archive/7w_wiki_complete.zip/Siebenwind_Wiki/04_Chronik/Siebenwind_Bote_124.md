---
layout: wiki_page
title: [[Siebenwind]] Bote 124
category: Chronik
---

# [[Siebenwind]] Bote 124

**Epistemischer Status:** #bote

## Die Lage an der Front - Ein Soldat berichtet
**Persona:** [[Randur_Kantrin]] (Sire), [[Schwarzenfels]] (Obergefreiter), [[Luther_Dueff]] (Sire)
**Thema:** Kampf gegen das Dunkel.
**Inhalt:** Bericht aus dem vordersten Frontlager. Sire [[Randur_Kantrin]] und [[Luther_Dueff]] stehen an vorderster Front an der Seite der Mannen des Banners. Hoher Respekt für die Soldaten, die dem Dunkel entgentreten.
**Autor:** *Arn*

## Gesucht & Gefunden.
**Persona:** [[Laurelin]] (Frau [[Laurelin]])
**Thema:** Koordination der Hauptstadtplanung.
**Inhalt:** Frau [[Laurelin]] fungiert als "rechte Hand seiner Gnaden" und koordiniert Audienzen, Bauarbeiten und die allgemeine Planung der neuen Hauptstadt [[Brandenstein]]. Ihre Arbeit wird als extrem arbeitsintensiv aber interessant beschrieben.
**Autor:** *Arn*

## Mitarbeiter für die Botenredaktion gesucht
**Location:** [[Brandenstein]] (Marktplatz)
**Thema:** Personalsuche.
**Inhalt:** Die Redaktion sucht Schreiber und Berichterstatter. Vorstellung am Botengebäude am Marktplatz von [[Brandenstein]].
**Autor:** *J.D.*

## Botenabonnement
**Thema:** Abonnements.
**Inhalt:** Interessenten können sich an die Redaktion wenden; Zustellung erfolgt durch Botenjungen.
**Autor:** *J.D.*

## Die Reise sucht sich ihren Weg
**Typ:** Lyrik
**Inhalt:** "Mein Fuße betritt [[Siebenwind]]..."
**Autor:** *HTd*

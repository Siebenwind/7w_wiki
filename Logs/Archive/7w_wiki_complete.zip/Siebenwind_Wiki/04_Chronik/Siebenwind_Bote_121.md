---
layout: wiki_page
title: [[Siebenwind]] Bote 121
category: Chronik
---

# [[Siebenwind]] Bote 121

**Epistemischer Status:** #bote

## Grußwort des Handelsbundes
**Inhalt:** Offizielles Grußwort an die Bürger von [[Siebenwind]].
**Autor:** *J.D.* (im Namen des Handelsbundes)

## Verkündung der Kriegerakademie
**Thema:** Disziplinarmaßnahmen an der Königlichen Akademie der Kriegskünste.
**Inhalt:** Mehrere Schüler wurden wegen mangelnden Interesses entlassen (nach einer Schülerzählung). Eine 14-tägige Frist zur Klärung von Missverständnissen wurde eingeräumt.
**Autor:** *J.D.*

## Zombieschaf in [[Brandenstein]]
**Thema:** Kurioser Vorfall in der Stadt.
**Inhalt:** Ein verwirrter Schütze wurde nach einem absurden Vorfall (Zombieschaf-Täuschung oder ähnliches?) von einem Gefreiten des Banners abgeführt.
**Autor:** *J.D.*

## Bauarbeiten des Bellumschrein
**Thema:** Sakralbau des [[Ordo_Belli]].
**Termin:** Donnerstag, 19. August, 16 Uhr.
**Inhalt:** Aufruf zur Unterstützung der Bauarbeiten. Helfer erhalten Speis und Trank.
**Autor:** *J.D.*

## Handwerker Siebenwinds!
**Location:** Siedlung [[Greifenklipp]] im [[Fenwald]].
**Thema:** Siedlungsbau des Aetts des Roten Stieres.
**Inhalt:** Suche nach Handwerkern für den Ausbau der Siedlung.
**Autor:** *HTd* (Jarle des Aetts des Roten Stieres von Tuhle)

## Die Ballade vom Ritter, der den Wein so mochte
**Typ:** Lyrik/Ballade
**Inhalt:** "Habt Dank dafür, dass ich kein Ritter mit Helme bin!"
**Autor:** *HTd*

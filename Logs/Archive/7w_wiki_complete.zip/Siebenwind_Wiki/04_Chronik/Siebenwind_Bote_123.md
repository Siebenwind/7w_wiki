---
layout: wiki_page
title: [[Siebenwind]] Bote 123
category: Chronik
---

# [[Siebenwind]] Bote 123

**Epistemischer Status:** #bote

## Aufruf zur Mietbegleichung
**Location:** [[Brandenstein]] (Westen)
**Thema:** Pachtland und Mietrückstände.
**Inhalt:** Neues Bauland im Westen der Stadt verfügbar. Magistrat warnt vor Beschlagnahmung bei unbezahlter Miete.
**Autor:** *J.D.*

## Mitteilung des Königlichen Gerichtes
**Persona:** [[Altumion_Eisenbruch]] (Inselrichter, [[Dwarshim]])
**Thema:** Rechtsprechung und Einigkeit.
**Inhalt:** Plädoyer für die Zusammenarbeit der Institutionen (Kirche und Staat) zur Wahrung der Ordnung in [[Tare]]. Lobpreisung des [[Astrael]]-Eides.
**Autor:** *TR* (Königlicher Richter)

## Eine [[Geschichte]]
**Persona:** [[Arman_von_Draconis]] ([[Arman]]), [[Karamir]], [[Jalina]]
**Location:** [[Drakenwald]], [[Draconis]]
**Fraktion:** [[Orden_der_Herrin_Vitama]]
**Thema:** Werdegang eines jungen Mannes, der fälschlich für einen Hexer gehalten wurde. Er schloss sich in [[Draconis]] dem Orden der [[Vitama]] an.
**Autor:** *J.D.*

## Das große Turnier des Handelsbundes
**Persona:** [[Paule_Bitterling]] (Gewinner)
**Thema:** Turniersieg.
**Inhalt:** [[Paule_Bitterling]] siegte in einem nervenaufreibenden Finalkampf und wurde von den Massen gefeiert.
**Autor:** *Arn*

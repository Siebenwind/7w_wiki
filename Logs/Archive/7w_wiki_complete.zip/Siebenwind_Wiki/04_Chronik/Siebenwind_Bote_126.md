---
layout: wiki_page
title: [[Siebenwind]] Bote 126
category: Chronik
---

# [[Siebenwind]] Bote 126

**Epistemischer Status:** #bote

## SONDERAUSGABE
**Thema:** Rückkehr zur Normalität und der Glaube.
**Inhalt:** Ein Plädoyer für den Alltag und die Ruhe in den Hallen Morsans für jene, die ihr Leben ließen. Der Glaube soll die Plagen des Ruchlosen hinwegfegen.
**Autor:** *SvS*

## Aufruf zur Messe
**Location:** Kapelle zu [[Brandenstein]].
**Termin:** 16. Carmar, Mitte des 7. Zyklus.
**Inhalt:** Einladung zur gemeinsamen Messe, um Licht in die Herzen zu tragen und die Dunkelheit zu vertreiben.
**Autor:** *SvS*

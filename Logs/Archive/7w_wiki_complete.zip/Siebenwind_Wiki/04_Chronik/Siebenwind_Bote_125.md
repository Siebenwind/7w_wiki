---
layout: wiki_page
title: [[Siebenwind]] Bote 125
category: Chronik
---

# [[Siebenwind]] Bote 125

**Epistemischer Status:** #bote

## Trophäenhändler in [[Brandenstein]]
**Location:** [[Brandenstein]]
**Thema:** Handel mit Monster-Trophäen.
**Inhalt:** Ein Trophäenhändler besucht die Stadt und nimmt Kostbarkeiten von Jägern entgegen.
**Autor:** *J.D.*

## Die [[Orken]]
**Thema:** Völkerverständigung und Konflikte.
**Inhalt:** Diskussion über Vorfälle im Zusammenhang mit [[Orken]] und den langen Weg der Völkerverständigung.
**Autor:** *R.*

## Rundreise über [[Siebenwind]]
**Location:** [[Greifenwald]] (Unterlehen), [[Nortraven]]-Lager.
**Thema:** [[Geografie]] und Sicherheit.
**Inhalt:** Bericht über das Unterlehen [[Greifenwald]]. Das Dorf der [[Nortraven]] wird von zwei hochgewachsenen Nordmännern bewacht, um es vor Dieben und [[Orken]] zu schützen.
**Vorschau:** Nächste Ausgabe: [[Seeberg]] (Unterlehen).
**Autor:** *J.D.*

## Vitamaschrein Einweihung
**Typ:** Lyrik/Festbericht
**Inhalt:** "Ein fröhliches Fest, eine rauschende Feier..." Lobpreisung der Göttin [[Vitama]].
**Autor:** *B.*

## Umbau des Botengebäudes
**Location:** [[Brandenstein]]
**Thema:** Einrichtung der Redaktion.
**Inhalt:** Suche nach Handwerkern/Einrichtern für erstklassige Innenausstattung der Redaktion.
**Autor:** *J.D.*

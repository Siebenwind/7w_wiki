---
layout: wiki_page
title: Kirche der Viere
category: Religion
author: [[Siebenwind]] Chronicler
---

# Kirche der Viere

**Epistemischer Status:** #canon

**Kategorie:** Religion
**Götter:** [[02_Astrael]], 03_Bellum, [[04_Vitama]], [[05_Morsan]]
**Verbreitung:** Staatsreligion in Galadon

## Einleitung
Die Kirche der Viereinigkeit ist die dominierende religiöse Institution im Königreich Galadon. Sie vereint die Kulte der vier "Guten Götter" unter einem Dach, auch wenn die einzelnen Orden oft autonom agieren.

## Philosophie und Metaphern
Gelehrte beschreiben die Gemeinschaft der Geweihten oft als einen **Baum**:
*   **Wurzeln:** Das Volk Galadons.
*   **Stamm:** Die Kirche als Institution.
*   **Äste:** Die verschiedenen Orden.
*   **Zweige/Blätter:** Schulen und einzelne Gemeinden.

Trotz dieses Bildes der Einheit herrscht innerhalb der Kirche oft Uneinigkeit über politische oder ethische Fragen, etwa wenn [[Bellum]]-Gläubige auf verschiedenen Seiten eines weltlichen Krieges gegeneinander kämpfen.

## Die Vier Götter und ihre Orden
1.  **[[02_Astrael]] (Das Allsehende Auge):**
    *   Aspekt: Wissen, Magie, Ordnung, Herrschaft.
    *   Orden: "Orden des Allsehenden Auges Astraels".
    *   Anhänger: Gelehrte, Magier, Richter, Herrscher.
    *   Zentrum: Herzogtum [[Region [[Sae]]|Sae]] (Lafay's Stab).

2.  **[[03_Bellum]] (Das Heilige Schwert):**
    *   Aspekt: Kampf, Ehre, Schutz, Kraft.
    *   Orden: "Orden vom Heiligen Schwerte Bellums".
    *   Anhänger: Soldaten, Ritter, Wächter.
    *   Zentrum: Oft in militärischen Provinzen wie [[Region Herder|Herder]] oder [[Region Ersont|Ersont]].

3.  **[[04_Vitama]] (Der Liebliche Kelch):**
    *   Aspekt: Leben, Heilung, Fruchtbarkeit, Familie.
    *   Orden: "Orden von Vitamas Lieblichen Kelche".
    *   Anhänger: Heiler, Bauern, Mütter, [[Rasse_Halblinge]].
    *   Zentrum: Weit verbreitet, viele Schreine in ländlichen Gegenden.

4.  **[[05_Morsan]] (Der Ruhende Hauch):**
    *   Aspekt: Tod, Übergang, Ruhe, Frieden (nicht Böse!).
    *   Orden: "Orden vom Ruhenden Hauche Morsans".
    *   Anhänger: Bestatter, Sterbebegleiter, jene die Trost suchen.
    *   Besonderheit: Die Verehrung Morsans wird oft missverstanden, ist aber essenzieller Teil des Zyklus.

## Politische Struktur
Theoretisch sieht die galadonische Ordnung eine klare Trennung vor:
1.  **Der Adel:** Kümmert sich um weltliche Belange und den Frieden.
2.  **Die Ritterschaft:** Kümmert sich um das Kriegswerk.
3.  **Die Geweihtenschaft:** Schützt das Volk vor den dunklen Mächten.

In der Praxis sind diese Grenzen oft fließend. In Krisengebieten übernimmt die Kirche oft Aufgaben von Justiz, Ordnung und Verteidigung, während der Adel in anderen Regionen eigenständige Heere führt.

## Rolle im Reich
*   **Status:** Seit König Arakam II. ap Galad ist der Glaube an die Viere die "gewählte Religion der Könige".
*   **Rechte:** Diener der Viere sind unantastbar ("Kein Bürger lege Hand an...").
*   **Pflichten:** Bürger sind zur Spende aufgefordert.
*   **Macht:** In manchen Regionen übernimmt die Kirche weltliche Aufgaben (Rechtsprechung, Verteidigung), wenn der Adel schwach ist.

## Überlieferungen
- [[Die Kirche der Viere in Galadon]]: Grundlegende Abhandlung über Struktur und Rechte.

## Quellen
- [[Die Kirche der Viere in Galadon]] (#canon)
- [[Adelskalender]]

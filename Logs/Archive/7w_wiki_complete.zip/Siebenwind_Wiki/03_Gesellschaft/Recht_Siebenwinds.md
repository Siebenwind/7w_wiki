---
layout: wiki_page
title: Recht Siebenwinds (De Iuribus)
category: [[Gesellschaft]]
tags: [Gesetz, Recht, Verfassung, Strafe, Adel, Bürger]
status: #überlieferung
---

# Recht Siebenwinds (De Iuribus)

**Epistemischer Status:** #canon

Das **De Iuribus [[Siebenwind]]** ist das grundlegende Gesetzeswerk des Lehens [[Siebenwind]]. Es wurde im Jahr 14 nach [[Hilgorad_I_ap_Mer|Hilgorad]] unter Graf [[Koruun_McKevin]] und den königlichen Richtern Aurax Ellrothon und Lario Anderus erlassen.

## Constitutio [[Siebenwind]] (Verfassung)

Die Verfassung regelt die Standeshierarchie und die Souveränität der Krone.
*   **Oberhoheit:** Hilgorad I. ap Mea ist uneingeschränkter Herrscher.
*   **Ständewesen:** Unterteilung in [[Adel]], [[Bürger]], [[Freie]] und [[Hörige]].
*   **[[Ritter_der_Sieben_Winde]]:** Sie fungieren als Verwalter und Hüter der Ordnung.
*   **Heilige Kirche:** Die Rechte der [[Viere|Kirche der Viere]] werden geschützt; die Inquisition kann in Einvernehmen mit der Krone eingerichtet werden.

## Codex Criminalis (Strafrecht)

Regelt die Ahndung von Untaten auf königlichem Grund.
*   **Kapitalverbrechen:** Mord, Hochverrat, Aufruhr und Angriffe auf die Obrigkeit. Strafen reichen von 80 Zyklen Haft bis zur Todesstrafe.
*   **Verbrechen & Vergehen:** Diebstahl, Landfriedensbruch, Beleidigung und Missbrauch von [[Magie]].
*   **Strafen:** Pranger, Kerkerhaft (mit Strafarbeit), Züchtigung, Verbannung und Todesstrafe.

## Codex Privatae (Zivilrecht)

Regelt private Rechtsverhältnisse und Verträge.
*   **Rechtsfähigkeit:** [[Menschen]] ab 15 Jahren, [[Zwerge]] ab 30 und [[Elfen]] ab 50 Jahren.
*   **Verträge:** Handschlag gilt bei Händlern als bindend. Verträge gegen die guten Sitten sind nichtig.
*   **Verjährung:** Zivilrechtliche Ansprüche verjähren nach 3 Monaten.

## Lex Patritiorum (Adelsrecht)

Definiert die Privilegien des Adels und des hohen Klerus (ab Erzgeweihtem).
*   **Ehrenduell:** Adlige haben das Recht, Beleidigungen durch ein Duell unter Aufsicht eines [[Bellum]]-Geweihten zu klären.
*   **Asylrecht:** Adlige können Schutzbefohlenen Asyl gewähren, das sie vor weltlicher Verfolgung schützt.

## Lex Exceptionis (Sonderrechte)

Enthält Ausnahmeregelungen für bestimmte Völker:
*   **Dwarschim ([[Zwerge]]):** Es ist ihnen gestattet, stets offen Waffen und Rüstungen zu tragen, ungeachtet ihres Standes (solange ihre Königstreue außer Zweifel steht).

---
> [!IMPORTANT]
> Des Königs Wille ist das höchste Gesetz. Das De Iuribus steht über allen anderen Gilden- oder Stadtsatzungen.

**Quelle:** [De Iuribus [[Siebenwind]].html](file:///Quellen/Bibliothek%20Astrael/De%20Iuribus%20Siebenwind.html)

---
layout: wiki_page
title: Falkensee
category: [[Geografie]]
---

# Falkensee

**Typ:** Stadt / Hauptstadt
**Epistemischer Status:** #canon
**Zugehörigkeit:** [[Siebenwind]]

## Beschreibung
**Falkensee** ist die größte Stadt und das politische sowie wirtschaftliche Zentrum der Insel [[Siebenwind]]. Sie beherbergt den [[Inselrat]], die großen Handwerksgilden und ist Sitz des [[Siebenwind_Kronregiment|Kronregiments]].

## Wichtige Orte
- **Burg [[Finianswacht]]**: Sitz der Verwaltung und des Militärs.
- **Marktplatz**: Zentrum des Handels.
- **Hafenviertel**: Lebensader des Überseehandels.

---
**Siehe auch:** [[Brandenstein]], [[Geografie]]
**Quellen:** [Kanon]

## Überlieferungen
- [[Atmender_Tod]]: Erwähnung in der Überlieferung.
- [[Orkenaufstand_17_nH]]: Erwähnung in der Überlieferung.
- [[Der_Sichelzahngnoll]]: Erwähnung in der Überlieferung.
- [[Der_Putsch_von_Falkensee]]: Erwähnung in der Überlieferung.
- [[Zeitstrahl]]: Erwähnung in der Überlieferung.
- [[Waldemar_Delaries_Reise_nach_Papin]]: Erwähnung in der Überlieferung.
- [[Myten_in_Falkensee]]: Erwähnung in der Überlieferung.
- [[Geschichten_eines_silbernen_Adlers]]: Erwähnung in der Überlieferung.

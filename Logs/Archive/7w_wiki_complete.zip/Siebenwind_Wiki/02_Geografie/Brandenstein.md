---
layout: wiki_page
title: Brandenstein
category: [[Geografie]]
---

# Brandenstein

**Epistemischer Status:** #bote

Die neue Hauptstadt von [[Siebenwind]]. Sie befindet sich derzeit im Aufbau und transformiert eine ehemals wilde Waldlandschaft in ein prächtiges urbanes Zentrum.

## Bergbau & Handwerk
Die Siedlung ist bekannt für ihren Bergbau (Eisen, Quarz). Im Jahr 18 n.H. wurde hier die innovative [[Staubbindungs_Mechanik]] von [[Albert_Metzler]] eingeführt, um die Arbeitsbedingungen in der nordöstlichen Mine zu verbessern.

## Bekannte Orte
*   Redaktion des **[[Siebenwind]] Boten** (Marktplatz)
*   Kapelle zu Brandenstein
*   Rathaus / Magistrat
*   Handelsbund-Haus (aufgelöst)
*   **Obdachlosenheim:** Ein Projekt von [[Dame_Rose]] zur kostenfreien Beherbergung von Reisenden und Bedürftigen.

## Infrastruktur
*   **Wegbeleuchtung:** Die Ritterschaft (Orden des Falken) installierte im Jahr 15 n.H. eine durchgehende Beleuchtung auf den Wegen nach [[Falkensee]].

## Überlieferungen
- [[Atmender_Tod]]: Erwähnung in der Überlieferung.
- [[Angriff_der_Schwarzmagier]]: Erwähnung in der Überlieferung.
- [[Zeitstrahl]]: Erwähnung in der Überlieferung.
- [[Der_Flug_der_Ente]]: Erwähnung in der Überlieferung.

---
layout: wiki_page
title: Region Ravel
category: Index
author: [[Siebenwind]] Chronicler
---

# Region Ravel

**Epistemischer Status:** #canon

**Kategorie:** [[index]] / Baronie
**Hauptstadt:** Meerfest
**Herrscher:** Baronin Luvaril von Ravel

## Beschreibung
Ein wildes, kaum kontrollierbares Land an der Ostgrenze.
*   **Orkenland:** Der Großteil der Baronie besteht aus Sümpfen und Steppen, die von (Grün-)[[Rasse_Orken]] bewohnt werden.
*   **Meerfest:** Die einzige nennenswerte Menschenstadt, eine Festung auf den Klippen ("Arsch Falandriens").

## Wirtschaft & Kultur
*   **Überleben:** Die [[Rasse_Menschen]] hier sind zäh und unabhängig. Der Baronstitel gilt als undankbar ("Schleudersitz").
*   **Krieg:** Ständige Scharmützel mit den [[Rasse_Orken]].

## Verlinkte Themen
*   [[Rasse Orken]]
*   [[Region Ersont]]

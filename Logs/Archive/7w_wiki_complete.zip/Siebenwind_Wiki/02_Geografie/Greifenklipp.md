---
layout: wiki_page
title: Greifenklipp
category: [[Geografie]]
---

## Stadtteile & Orte
*   **Vitamalinviertel:** Ein ehemaliger Brennpunkt der Kriminalität. Unter der Aufsicht von [[Sire_Fedral_Lavid]] wurde das Viertel geräumt, wobei zahlreiche kriminelle Nordmänner identifiziert wurden. Es gibt Pläne, das Viertel in ein Heim für Gossenkinder umzuwandeln ([[Siebenwind_Bote_141]]).

# Greifenklipp

**Epistemischer Status:** #bote

Eine Siedlung im [[Fenwald]], die vom Aett des Roten Stieres von Tuhle gegründet wurde. Sie gilt als Musterbeispiel für die Zusammenarbeit der Völker, insbesondere der [[Nortraven]].

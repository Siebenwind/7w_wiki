---
layout: wiki_page
title: Region Kadamark
category: Index
author: [[Siebenwind]] Chronicler
---

# Region Kadamark

**Epistemischer Status:** #canon

**Kategorie:** [[index]] / Baronie
**Hauptstadt:** Gofilm
**Herrscher:** Baron Siegfried von Kadamark

## Beschreibung
Eine hügelige, waldreiche Region im Nordosten. Bekannt für die **Feuerwälder** und das **Kadamassiv**. Hier wird der Großteil des Holzes für das Reich geschlagen.

## Wichtige Orte
*   **Gofilm:** Eine Stadt, die sich tief in den Berg schlängelt, berühmt für ihre Fachwerkbauten und das "Haus der Zünfte".
*   **Die Grauen Höhlen:** Ein Tunnelsystem unter Gofilm, Sitz einer Magierakademie (Grauer Pfad).

## Wirtschaft & Kultur
*   **Holz:** Exportiert in alle Welt.
*   **Handwerk:** Die Kadamarker gelten als die tüchtigsten Handwerker (Schreiner, Zimmerleute).

## Verlinkte Themen
*   [[Region Kettel]]
*   [[Magie Grauer Pfad]]

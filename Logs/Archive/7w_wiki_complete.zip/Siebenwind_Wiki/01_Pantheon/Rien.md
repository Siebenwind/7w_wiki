---
layout: wiki_page
title: Rien
type: Religion
status: Kanon (Level 1)
tags: [Elementarherrin, [[Enhor]], Erde, [[Rasse_Zwerge]], Magie]
---

# Rien

**Epistemischer Status:** #canon

**Rien** ist eine der vier Elementarherren ([[Enhor]]) und die Herrscherin über die Erde, den Fels und das Mineral. Sie steht für Stabilität, Beständigkeit, Fruchtbarkeit (als Nährboden) und Verteidigung.

## Aspekte und Prinzipien
- **Element:** Erde
- **Charakter:** Ruhig, unerschütterlich, mütterlich, aber auch starrköpfig.
- **Domäne:** Berge, Höhlen, Ebenen, Ackerkrume.
- **Symbole:** Der Fels, der Berg, der Kristall.

## Mythologie
Rien ist eng mit *[[03_Bellum]] (Krieg/Schmied)* verbunden. Zusammen schufen sie die **Rasse_Zwerge**, wobei Rien ihnen den Körper aus Fels gab und [[03_Bellum]] ihnen den Geist des Handwerks einhauchte. Sie ist auch die Patronin der Landwirte, die ihre Erde bestellen.

## Verehrung
[[Rasse_Zwerge]] ehren sie als die "Erste Mutter". Bauern opfern ihr die erste Ernte. Erdmagier rufen sie an, um Felswände zu erschaffen oder Erdbeben zu besänftigen.

## Magie (Elementarer Pfad)
Der Pfad der Erde ist langsam, aber mächtig. Seine Anhänger können Mauern aus dem Boden wachsen lassen, sich in Stein verwandeln oder die Tragkraft von Erde beeinflussen.

## Beziehungen
- **[[06_Ignis]] (Feuer):** Oft der Zerstörer ihrer Werke.
- **[[08_Ventus]] (Luft):** Erosion trägt Fels ab. Rien ist oft genervt von seiner Flüchtigkeit.
- **[[09_Xan]] (Wasser):** Wasser wäscht Stein aus, kann aber auch Leben spenden.

## Verwandte Themen
- [[00_Religion_Uebersicht]]
- [[12_Magie_Grundlagen]]
- [[20_Rassen_Zwerge]] - Ihre Kinder.

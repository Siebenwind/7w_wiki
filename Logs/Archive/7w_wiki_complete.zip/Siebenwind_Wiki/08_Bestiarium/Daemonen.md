---
layout: wiki_page
title: Dämonen
category: Bestiarium
---

# Dämonen

**Epistemischer Status:** #canon

## Überblick
**Dämonen** sind die Diener und das Volk des dunklen Gottes [[Angamon]]. Sie sind Wesen der zweiten Sphäre, die nur Stärke respektieren und Schwächere gnadenlos unterjochen.

## Die Hierarchie der Hörner
Die Macht eines Dämons wird durch die Anzahl seiner Hörner symbolisiert.
- **Eingehörnte:** Die schwächste und dümmste Form der Dämonen.
- **Dämonenfürsten:** Die mächtigsten Diener mit sechs Hörnern. Es gibt insgesamt sechs Dämonenfürsten.
- **[[Angamon]]:** Legenden besagen, dass der dunkle Herrscher selbst sieben Hörner trägt.

Die Hierarchie ist dynamisch; ein Dämon kann durch den Sieg über einen Ranghöheren dessen Status (und Hornanzahl) übernehmen.

## Beschwörung auf [[Tare]]
Dämonen können die erste Sphäre ([[Tare]]) nicht aus eigener Kraft betreten, ohne den Zorn aller Götter und Elementarherren heraufzubeschwören. Stattdessen nutzt [[Angamon]] sterbliche Schwarzmagier, um Dämonen nach [[Tare]] zu rufen.
- **Abbilder:** Auf [[Tare]] erscheint lediglich ein Abbild des Dämons. Wird dieses zerstört, verbleibt die Essenz in der zweiten Sphäre, benötigt aber lange Zeit, um sich zu regenerieren.
- **Gefahren:** Fehler bei der Beschwörung führen dazu, dass der Dämon seinen Beschwörer angreift. Wer zu oft Dämonen ruft, riskiert, die Aufmerksamkeit Angamons zu erregen, der einen mächtigeren Bestrafungs-Dämon senden kann.

## Mysteriöse Chaoswesen
Es gibt Berichte über Wesen wie die **Scheeter** oder **Reendompekas**, die nur zur Zerstörung auf [[Tare]] erscheinen. Sie verfügen über seltsame Magie und werden oft sogar von Anhängern Angamons gejagt, da sie reine Chaosstifter sind.

---
**Siehe auch:** [[Bestiarium_Register]], [[Angamon]]

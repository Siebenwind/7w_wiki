---
layout: wiki_page
title: Chimären
category: Bestiarium
---

# Chimären

**Epistemischer Status:** #canon

## Überblick
Chimären sind magisch erschaffene Mischwesen, die aus der Verschmelzung verschiedener Lebensformen hervorgegangen sind. Die Entdeckung ihrer Herkunft wird einer Abenteuergruppe zugeschrieben, die in der "Wüste der tausend Tode" die Ruinen einer Festung untersuchte.

## Ramic ap Falos
Der Magier **Ramic ap Falos** gilt als der (unfreiwillige) Schöpfer der bekanntesten Chimären-Rassen. In seinen Forschungen zur Verbesserung körperlicher Eigenschaften entwickelte er ein Ritual zur Verschmelzung von Lebewesen. Trotz Verbotes durch seine Kollegen forschte er heimlich weiter, bis er schließlich von seinen eigenen Schöpfungen getötet wurde.

## Bekannte Rassen

### Harpyien
Harpyien entstanden aus der Verschmelzung einer Magierin und eines Gebirgsgeiers.
- **Biologie:** Sie sind rein weiblich und können sich bei Bedarf ungeschlechtlich fortpflanzen (Eiablage).
- **Verhalten:** Harpyien besitzen eine tierische Intelligenz und sind extrem aggressiv. Ihre Aggressivität verhindert größere Gruppenbildungen, was ihre Ausbreitung auf [[Tare]] begrenzt.

### Ferrin
Die Ferrin sind eine Verschmelzung aus Mensch und Ratte.
- **Biologie:** Sie sind intelligent (menschliches Niveau), folgen aber einer für [[Menschen]] oft unverständlichen Logik.
- **Verhalten:** Ferrin sind extrem ängstlich und meiden den Kontakt zu anderen humanoiden Völkern. Sie agieren meist nur in großen Gruppen offensiv.

---
**Siehe auch:** [[Bestiarium_Register]], [[Magie_Grundlagen]]

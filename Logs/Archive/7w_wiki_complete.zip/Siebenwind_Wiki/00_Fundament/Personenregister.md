---
layout: wiki_page
title: Personenregister
category: [[Geografie]]
---

# Personenregister

**Epistemischer Status:** #canon

Dieses Register dient der Erfassung aller namentlich erwähnten oder relevanten Personen und [[Persönlichkeiten]] der Welt [[Siebenwind]].

## Zentrale Personenliste
| Name | Rolle / Titel | Erstes Auftreten (Quelle) | Aktivitätszeitraum | Status |
| :--- | :--- | :--- | :--- | :--- |
| [[Aaron]] | Wegelagerer (verhaftet) | [Bote 133] | ~15 n.H. | #bote |
| [[Abdolus_Nachengalle]] | Forscher / Mystiker | [[Draconis]] | 18 n.H. | #bote |
| [[Adalbert_der_Heiler]] | Heiler | [Kanon] | amtierend | #canon |
| [[Adhemar_Ravenforth]] | Kanzler | [Kanon] | amtierend | #canon |
| [[Agatha_Sumpfendotter]] | Autorin | [Bote 163] | 18 n.H. | #bote |
| [[Albert_Metzler]] | Erfinder | [[Brandenstein]] | 18 n.H. | #bote |
| [[Al-Barlis-Nekor]] | Magier (Zirkel) | [Kanon] | amtierend | #canon |
| [[Aldaro]] | Bibliotheksleiter | [Bote 130] | ~15 n.H. | #bote |
| [[Aleis]] | Entdecker | [Bote 145] | ~15 n.H. | #bote |
| [[Altumion_Eisenbruch]] | Inselrichter ([[Dwarshim]]) | [Bote 123] | ~15 n.H. | #bote |
| [[Argus_Ebonhart]] | Magier | [Kanon] | amtierend | #canon |
| [[Arman]] | Ordensmitglied / "Hexer" | [Bote 123] | ~15 n.H. | #bote |
| [[Arnim_Estragons]] | Stellv. Botenleitung / Lehensherr | [Bote 131] | ~15 n.H. | #bote |
| [[Beladriel_Blaettertanz]] | Baronin | [[Siebenwind]] | 19 n.H. | #bote |
| [[Benion_Sandelholz]] | Hochwürden | [Bote 130] | ~15 n.H. | #bote |
| [[Biskulon]] | Bibliothekar / Bauleiter | [[Falkensee]] | 17 n.H. | #bote |
| [[Brandeis]] | Wachmann (verstorben) | [Bote 130] | ~15 n.H. | #bote |
| [[Brand_Windfluesterer]] | Priester ([[Enhor]]) | [[Ecclesia_Elementorum]] | 19 n.H. | #bote |
| [[Custodias]] | Hochgeweihter | [Kanon] | amtierend | #canon |
| [[Daena_Maga]] | Magierin | Akademie | 18 n.H. | #bote |
| [[Dame_Rose]] | Leitung Obdachlosenheim | [Bote 131] | ~15 n.H. | #bote |
| [[Der_Krämer]] | Bürger (Hause [[Gropp]]) | [Bote 136] | ~15 n.H. | #bote |
| [[Divero]] | Schankknecht | [Bote 123] | ~15 n.H. | #bote |
| [[Donarius_Derrvus]] | Priester ([[Morsan]]) | [Kanon] | amtierend | #canon |
| [[Dur]] | Magier / Exzellenz | [[Siebenwind]] | 18 n.H. | #bote |
| [[Elares_Valjean]] | Gesuchter / Flüchtling | [Bote 122] | ~15 n.H. | #bote |
| [[Elias_von_Rothschild]] | Adliger | [Kanon] | amtierend | #canon |
| [[Emanuel]] | Paladin | [Kanon] | amtierend | #canon |
| [[Erzpriester_Vencurius]] | Klerus ([[Xan]]) | [Kanon] | amtierend | #canon |
| [[Famir]] | Bürger / Gefreite | [[Falkensee]] | 15 n.H. | #bote |
| [[Felix_Allon]] | Angler | [Bote 144] | ~15 n.H. | #bote |
| [[Fraomar_Arkad_Grembargh]] | Arkadhrall (Zwergenpriester) | [Bote 150] | 17 n.H. | #bote |
| [[Fred]] | Schankknecht | [Bote 123] | ~15 n.H. | #bote |
| [[Frederik_Hamsberg]] | Ritter (Löwenorden) | [[Falkenwall]] | 18 n.H. | #bote |
| [[Friedward_von_und_zu_Gerdenwald]] | Graf | [Kanon] | amtierend | #canon |
| [[G.K.]] | Autor | [Bote 134] | ~15 n.H. | #bote |
| [[Gerion_Flammwurf]] | Magieranwärter | [Bote 133] | ~15 n.H. | #bote |
| [[Gropp]] | Inselpatrizier | [[Falkensee]] | 18 n.H. | #bote |
| [[Hadrian]] | Ritter (Löwenorden) | [Bote 167] | 18 n.H. | #bote |
| [[Hagen_Robaar_von_Saalhorn_und_Siebenwind]] | König | [Kanon] | alt | #canon |
| [[Harlas]] | Feldmeister | [Bote 143] | ~15 n.H. | #bote |
| [[Harok]] | Krieger | [Kanon] | amtierend | #canon |
| [[Hektor]] | Söldner | [Kanon] | amtierend | #canon |
| [[Herr_Distelstein]] | Bürger | [Bote 144] | ~15 n.H. | #bote |
| [[Hilgorad_I._ap_Mer_von_Galadon]] | Großkönig | [Kanon] | amtierend (15-30 n.H.) | #canon |
| [[Horan_Erandel]] | Anwärter Kriegerakademie | [Bote 133] | ~15 n.H. | #bote |
| [[Isfaldia]] | Heilerin | [[Ecclesia_Elementorum]] | 19 n.H. | #bote |
| [[Jabin]] | Leiter der [[Communis_Medici]] | [[Falkensee]] | 18 n.H. | #bote |
| [[Jack_the_Ripper]] | Gesuchter | [Bote 122] | ~15 n.H. | #bote |
| [[Jorwo]] | Oberjäger | [Bote 136] | ~15 n.H. | #bote |
| [[Josef_Gaumann]] | Bürger (Opfer) | [Bote 141] | ~15 n.H. | #bote |
| [[Juppert]] | Bauer | [[Falkensee]] | 18 n.H. | #bote |
| [[Kaspian_Tiefenwald]] | Leiter der [[Ventusreiter]] | [[Falkensee]] | 18 n.H. | #bote |
| [[Koruun_McKevin]] | Vogt | [Kanon] | amtierend | #canon |
| [[Kregor_Arthax_Stahlauge]] | Herr unter dem Berg | [Kanon] | amtierend | #canon |
| [[Laurus_Delany]] | Geweihter | [[Falkensee]] | 17 n.H. | #bote |
| [[Lea_Sonnenschein]] | Heilerin | [Bote 127] | ~16 n.H. | #bote |
| [[Lettre_Ulyssees]] | Redakteur | [[Draconis]] | 18 n.H. | #bote |
| [[Llewellyen]] | Feldmeister | [Bote 143] | ~15 n.H. | #bote |
| [[Madame_Delevha]] | Ex-Botenleitung / Wahrsagerin | [Bote 131] | ~15-17 n.H. | #bote |
| [[Madame_Estrella]] | Chefredakteurin | [Bote 131] | ~15 n.H. | #bote |
| [[Maluk]] | Page | [[Falkensee]] | 17 n.H. | #bote |
| [[Markward_von_Falkensee]] | Putschist / Graf | [Bote 120] | ~26-30 n.H. | #bote |
| [[Marlon_Brandner]] | Berater | [[Siebenwind]] | 18 n.H. | #bote |
| [[Marnie_Ruatha]] | Baronin | [Kanon] | amtierend | #canon |
| [[Nhergas]] | Edeldame | [Bote 162] | 18 n.H. | #bote |
| [[Niemand]] | Mysteriöse Gestalt | [Bote 136] | ~15 n.H. | #bote |
| [[Niklas_Rattenfaenger]] | Tagelöhner | [[Falkensee]] | 18 n.H. | #bote |
| [[Paule_Bitterling]] | Fischer / Turniersieger | [Bote 123] | ~15-16 n.H. | #bote |
| [[Proveus_Herand]] | Magier | [Kanon] | amtierend | #canon |
| [[S.L.]] | Autor / Dichter | [Bote 133] | ~15 n.H. | #bote |
| [[Safiriel]] | Elfin (Zirkel) | [Kanon] | amtierend | #canon |
| [[Siegfried_Steiner]] | Großmeister (Rd7W) | [[Finianswacht]] | 18 n.H. | #bote |
| [[Sir_Ecanas]] | Adeliger / Ritter | [Bote 143] | ~15-16 n.H. | #bote |
| [[Sire_Fedral_Lavid]] | Adeliger / Offizier | [Bote 141] | ~15 n.H. | #bote |
| [[Solos_Nhergas]] | Kanzlerin | [Bote] | amtierend (seit ~28 n.H.) | #bote |
| [[Sorania]] | Waldelfin | [Kanon] | amtierend | #canon |
| [[Telandrion]] | Elfenpriester | [Kanon] | amtierend | #canon |
| [[Tionne]] | Hauptmann | [[Siebenwind_Kronregiment]] | 19 n.H. | #bote |
| [[Tintin_(Waljakov)]] | Abenteurer | [Kanon] | amtierend | #canon |
| [[Tion_Altor]] | Händler | [Kanon] | amtierend | #canon |
| [[Truba_Bierbart]] | Wirtin / Jägerin | [Bote 136] | ~15 n.H. | #bote |
| [[V._Catrone]] | Autor / Bürger / Händler | [Bote 131] | ~15 n.H. | #bote |
| [[Vincent_Ebenstein]] | Ritter | [Kanon] | amtierend | #canon |
| [[Waldemar_Delarie]] | Gardehauptmann | [Kanon] | ~15-28 n.H. | #canon |
| [[Winzlig]] | Obergefreiter | [[Falkensee]] | 17 n.H. | #bote |
| [[Woran_Lebensmüh]] | Stellv. Kastellan / Einsiedler | [Bote 130] | ~15-16 n.H. | #bote |
| [[Zacharias_Gropp]] | Knappe | [[Finianswacht]] | 18 n.H. | #bote |
| [[al_Wechnett]] | Beamter / Buchhändler | [Bote 143] | ~15 n.H. | #bote |
| [[Alassea]] | Heilerin | [Bote 174] | 20 n.H. | #bote |
| [[Laske]] | Hochmeister (Falkenorden) | [Bote 172] | 20 n.H. | #bote |
| [[Markus_Panscher]] | Alchemist | [Bote 174] | 20 n.H. | #bote |
| [[Mirian_Lasar]] | Heermeisterin | [Bote 173] | 20 n.H. | #bote |
| [[Pharalis_Avistur]] | Ritterin | [Bote 172] | 20 n.H. | #bote |
| [[Yves_Rondragon]] | Lehnsherr ([[Seeberg]]) | [Bote 172] | 20 n.H. | #bote |
| [[Cendaric_Tibur]] | Baron | [Bote 172] | 20 n.H. | #bote |

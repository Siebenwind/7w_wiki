---
layout: wiki_page
title: Bestiarium Register
category: Index
---

# Bestiarium Register

**Epistemischer Status:** #canon

Dieses Register dient der systematischen Erfassung aller Kreaturen, Unholde und mystischen Wesen, die die Insel [[Siebenwind]] und das Königreich Galadon bevölkern.

## Kreaturenverzeichnis

| Name | Klassifizierung | Primärer Lebensraum | Epistemischer Status |
| :--- | :--- | :--- | :--- |
| [[Chimären]] | Bestien (Magische Kreuzungen) | Wüsten, Gebirge | #canon |
| [[Drachen]] | Mystische Wesen / Bestien | Unbekannt / Gebirge | #canon |
| [[Dämonen]] | Beelzebuben / [[Daemonen]] | Zweite Sphäre / [[Tare]] | #canon |
| [[Elementare]] | [[Elementare]] | Orte arkaner Energie | #canon |
| [[Feen]] | Übernatürliche Wesen | Wälder / Zweite Sphäre | #canon |
| [[Gargoyles]] | Bestien (Magische Konstrukte) | Ruinen, Gebirge | #canon |
| [[Goblins]] | Humanoide (Kleingestalten) | Untergrund, Ruinen | #canon |
| [[Kopflose]] | Bestien (Mutationen) | Höhlen, Sümpfe | #canon |
| [[Liche]] | [[Untote]] (Geisterwesen) | Schlachtfelder, Krypten | #canon |
| [[Oger]] | Humanoide | Wälder, Grönland | #canon |
| [[Orken]] | Humanoide (Kriegervolk) | [[Ödland]], Gebirge | #canon |
| [[Riesen]] | Humanoide (Riesengestalten) | Gebirge, Abgeschiedenheit | #canon |
| [[Skorpione]] | Bestien (Insekten) | Wüsten, Wälder | #canon |
| [[Trolle]] | Humanoide (Riesengestalten) | Gebirge, Wälder | #canon |
| [[Untote]] | [[Untote]] (Überblick) | Ganz [[Tare]] | #canon |
| [[Waldwesen]] | Pflanzenwesen / Bestien | Wälder, Sümpfe | #canon |
| [[Der_Grix]] | Mystisches Wesen | Unbekannt | #bote |
| [[Magiefresser_Wolke]] | Magisches Konstrukt | Akademie / Konstruiert | #bote |
| [[Schleimwesen]] | Bestien | Kanäle, Höhlen | #bote |
| [[Seelenfresser]] | Geisterwesen | Schattenwelt / Urbane Legenden | #bote |
| [[Wasserkreaturen]] | Bestien (Gefahren aus der Tiefe) | Weiher, Küsten | #bote |
| [[Weiher_Ungetuem]] | Insekten / Krebstiere | [[Greifenweiher]] | #bote |

## Erläuterung der Klassifizierung
- **Beelzebuben/[[Daemonen]]:** Wesenheiten der Niederhöllen.
- **[[Elementare]]:** Manifestationen der Urkräfte.
- **[[Untote]]:** Wiedergänger und körperlose Geister.
- **Bestien:** Gefährliche Raubtiere arkaner oder natürlicher Herkunft.

---
**Siehe auch:** [[Gesellschaft]], [[Geografie]], [[Religion_Übersicht]]

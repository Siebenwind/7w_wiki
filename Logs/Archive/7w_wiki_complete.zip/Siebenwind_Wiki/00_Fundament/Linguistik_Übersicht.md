---
layout: wiki_page
title: Linguistik Übersicht
category: Fundament
---

# Linguistik Übersicht

**Epistemischer Status:** #canon

Diese Übersicht dokumentiert die verschiedenen Sprachen und Dialekte, die auf dem Kontinent Falandrien und darüber hinaus gesprochen werden. Jede Sprache spiegelt die Kultur und [[Geschichte]] ihres Volkes wider.

## Sprachen der [[Elfen]] (Isdira)
Die [[Elfen]]-Sprache **Isdira** zeichnet sich durch ihre Melodie und den häufigen Gebrauch von Apostrophen aus, die oft Glottalstopps oder Lautverschiebungen markieren.

- **Besonderheiten:** Pluralbildung oft durch Suffix `-i`.
- **Wichtige Begriffe:**
    - *[[Region_Auren]]:* Das Elfenland.
    - *Ma'ahn:* Das unbekannte Land.
    - *Miandrell:* Auenelfen-Dorf.

## Sprachen der [[Zwerge]] (Dwarschim)
Die Zwergen-Sprache **Dwarschim** ist kehlig und präzise. Sie wird oft in Komposita verwendet, die durch ein Apostroph getrennt werden.

- **Besonderheiten:** Pluralbildung durch Suffix `-a`.
- **Wichtige Begriffe:**
    - *Bresch:* Bruder.
    - *Trosh:* Bier.
    - *Arphet'dwarschim:* Talzwerg.
    - *Binge:* Zwergenbehausung.

## Die Run-Sprache (Altgaladonisch)
Die Sprache der [[Die_Gohor]] (Gohor) und Grundstein aller modernen Zivilisationssprachen. Sie wird heute vor allem in der Magie und in antiken Inschriften verwendet. Sie bildet die Grundlage für magische Formeln und Gelehrtentexte.

## Orkisch (Schlachtruf-Dialekt)
Die Sprache der [[Orken]] wird oft als "lautgesprochenes Galadonisch" (verfälschtes Deutsch) beschrieben. Sie zeichnet sich durch eine harte, gutturale Aussprache und lautmalerische Verzerrungen aus.

**Merkmale:**
- **Vokalverschiebung:** `ei` -> `ai`, `ie` -> `ee`, `u` -> `uu`.
- **Konsonanten:** `s` -> `z`, `ch` -> `gh`, `w` -> `f`.
- **Endungen:** `-er` -> `-är`, `-en` -> `-änz`.
- **Vokabular:**
    - *Zpitzohrän* ([[Elfen]])
    - *haarlozän Affänz* ([[Menschen]])
    - *Tözängitze* ([[Zwerge]])
    - *Funkälsteinä* (Gold/Edelsteine)

## Weitere Sprachen
- **Alt-Linfan:** Eine antike Sprache, die im heutigen Linfan kaum noch aktiv gesprochen wird, aber in akademischen Kreisen überlebt hat. Sie ist in ihrer Struktur und Strenge dem **Lateinischen** sehr ähnlich. Viele Gesetzestexte (wie das [[Recht_Siebenwinds]]) sind darin verfasst.
- **Mazzarem:** Bruchstücke einer verschollenen oder isolierten Kultur, deren Linguistik derzeit noch erforscht wird.

---
> [!TIP]
> Die Kenntnis von Sprachen wie Run oder Alt-Linfan ist oft eine **Verwandte Themen:** [[Das_Pantheon]], [[Recht_Siebenwinds]], [[Die_Sprache_Run]]

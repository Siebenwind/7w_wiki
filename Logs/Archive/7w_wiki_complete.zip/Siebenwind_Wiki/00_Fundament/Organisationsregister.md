---
layout: wiki_page
title: Organisationsregister
category: [[Gesellschaft]]
---

# Organisationsregister

**Epistemischer Status:** #canon

Dieses Register erfasst alle Gilden, Orden, religiöse Gemeinschaften und politischen Vereinigungen auf [[Siebenwind]].

## Zentrale Organisationen

| Name | Typ | Sitz | Status |
| :--- | :--- | :--- | :--- |
| [[Communis_Medici]] | Heilergilde | [[Falkensee]] | #bote |
| [[Ecclesia_Elementorum]] | Religionsgemeinschaft | Inselweit | #canon |
| [[Handelskontore_der_Dwarschim_(H&H)]] | Handelsvertretung | [[Dwarshim]] | #canon |
| [[Inselrat]] | Politische Verwaltung | [[Burg_Finianswacht]] | #canon |
| [[Orden_der_Wachenden_Löwen]] | Religiöser Ritterorden | [[Falkenwall]] / [[Finianswacht]] | #canon |
| [[Siebenwind_Kronregiment]] | Armee der Krone | [[Burg_Finianswacht]] | #canon |
| [[Ventusreiter]] | Berittene Post / Miliz | [[Falkensee]] | #bote |
| [[Zirkel_der_Magie]] | Magische Vereinigung | Akademie | #bote |
| [[Schattenjaeger]] | Elite-Wächter der Ecclesia | Inselweit | #bote |
| [[Nortraven]] | Kriegerische Gemeinschaft / Grenzwächter | Nord-[[Siebenwind]] | #bote |
| [[XIII_Kronregiment]] | Armee der Krone | [[Brandenstein]] / [[Falkenwall]] | #bote |
| [[Orden_der_Traenen_Vitamas]] | Religiöser Orden | Inselweit | #bote |
| [[Terra_Dorotor]] | Kult (zerschlagen) | [[Brandenstein]] | #bote |

## Handwerks- und Handelsgilden
*Noch im Aufbau / Ingestion läuft*
- **[[Gilde_der_Feinschmiede]]:** (dw.: *Angar-Gôm*) Zentrales Handwerk für Metallveredelung.
- **[[Hafengilde_Brandenstein]]:** Verwaltung der Docks und des Handels in [[Brandenstein]].
- **Die Redaktion:** Herausgeber des [[[Siebenwind]] Bote](Siebenwind_Bote_Index.md).

## Politische Gremien
- **[[Der_Große_Rat]]**: Oberstes Entscheidungsgremium der Allianz.
- **Truchsess-Amt:** Verwaltung der Kronmark.

---
**Siehe auch:** [[Gesellschaft]], [[Personenregister]]

---
layout: wiki_page
title: WORKFLOW LORE CONSISTENCY
category: Sonstiges
---

# WORKFLOW LORE CONSISTENCY

**Epistemischer Status:** #perspektive

To maintain the quality and consistency of the Siebenwind Wiki while processing mass data, the following rules apply:

## 1. Wiki Style Convention (Frontmatter)

Every document in the wiki must have the following YAML frontmatter:

```yaml
---
layout: wiki_page
title: [Display Title]
category: [Persönlichkeit | Geschichte | Erzählung | Geografie | Religion | Magie]
---
```

The first level-1 heading (`# Title`) must exactly match the `title` field in the frontmatter.

## 2. Lore-Police & Epistemic Status

To distinguish between ground truth and subjective accounts, the following tags must be used:
- `#canon`: Absolute Ground Truth (Verified world laws, geography).
- `#bote`: Periodic newspaper records (High reliability, but context-limited).
- `#perspektive`: Subjective accounts (Player stories, letters).
- `#überlieferung`: Legends, myths, and unverified oral traditions.

**Granular Tagging**: Mixed articles must use `(Status: #tag)` at the paragraph/section level to clearly separate sources.

**Consistency Checks**:
1. **Axiom Check**: Does the story contradict the Götter-Kanon or Magie-Axiome?
2. **Time Check**: Use the `Time Keeper` skill to validate dates.
3. **Conflict Logging**: Mark unproven subjective claims with `(Status: #perspektive)`.

## 3. Git History

- **Batch Commits**: After processing a batch of documents (e.g., 10 stories), a git commit must be made.
- **Commit Message Pattern**: `Batch-Processing: [Count] player stories integrated. [Conflict Count] conflicts listed in /Logs.`

## 4. Bi-directional Linking

- **In Story**: Link every mentioned Entity (Entity, Place, Event) to its `/Siebenwind_Wiki/` article.
- **In Wiki**: Add a section `## Überlieferungen` (Traditions) at the bottom of the wiki article and link back to the story.

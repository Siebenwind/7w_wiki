---
layout: wiki_page
title: Toran Dur - Die Magie
category: Sonstiges
---

Die Magie

von Edelmann Toran Dur, Hochmagus Ita\'Glur

Magister Magus der königlichen Akademie der arkanen Künste zu Siebenwind

26\. nach Hilgorad

Inhaltsverzeichnis

# Toran Dur - Die Magie

**Epistemischer Status:** #perspektive

[Was ist Magie [4](#was-ist-magie)](#was-ist-magie)

[Der Ursprung der Magie [4](#_Toc523856296)](#_Toc523856296)

[Unterschiedliche Magien
[4](#unterschiedliche-magien)](#unterschiedliche-magien)

[Die drei Pfade der hohen Magie
[4](#die-drei-pfade-der-hohen-magie)](#die-drei-pfade-der-hohen-magie)

[Der dunkle Pfad [5](#der-dunkle-pfad)](#der-dunkle-pfad)

[Hexen [5](#hexen)](#hexen)

[Druiden [5](#druiden)](#druiden)

[Elfen [5](#elfen)](#elfen)

[Myten [5](#myten)](#myten)

[Schamanen [5](#schamanen)](#schamanen)

[Aufbau der Sphären [6](#aufbau-der-sphären)](#aufbau-der-sphären)

[Mandon [6](#mandon)](#mandon)

[Horandon [6](#horandon)](#horandon)

[Vidon [6](#vidon)](#vidon)

[Der Limbus [6](#der-limbus)](#der-limbus)

[Magietheorie [6](#magietheorie)](#magietheorie)

[Aufbau des sterblichen Geistes
[7](#aufbau-des-sterblichen-geistes)](#aufbau-des-sterblichen-geistes)

[Harmonie des Seins [7](#harmonie-des-seins)](#harmonie-des-seins)

[Fadentheorie [8](#fadentheorie)](#fadentheorie)

[Aurentheorie [9](#aurentheorie)](#aurentheorie)

[Theorie der größeren Ströme
[9](#theorie-der-größeren-ströme)](#theorie-der-größeren-ströme)

[Ritualkunde [10](#ritualkunde)](#ritualkunde)

[Definition Rituale [10](#definition-rituale)](#definition-rituale)

[Die Kreise [10](#die-kreise)](#die-kreise)

[Paraphernalia [11](#paraphernalia)](#paraphernalia)

[Anker [11](#anker)](#anker)

[Foki [12](#foki)](#foki)

[Speicher [12](#speicher)](#speicher)

[Auswahl des Ortes [12](#auswahl-des-ortes)](#auswahl-des-ortes)

[Vorbereitung des Ortes & des Selbst
[13](#vorbereitung-des-ortes-des-selbst)](#vorbereitung-des-ortes-des-selbst)

[Durchführung von Ritualen
[13](#durchführung-von-ritualen)](#durchführung-von-ritualen)

[Illusionistik [14](#illusionistik)](#illusionistik)

[Anzahl der Sinne [15](#anzahl-der-sinne)](#anzahl-der-sinne)

[Objektiv [15](#objektiv)](#objektiv)

[Subjektiv [15](#subjektiv)](#subjektiv)

[Kampfmagie [16](#kampfmagie)](#kampfmagie)

[Translokation [17](#translokation)](#translokation)

[Sphärenrisse [17](#sphärenrisse)](#sphärenrisse)

[Geistreise [17](#geistreise)](#geistreise)

# Was ist Magie

So wollen wir dieses Werk am Anfang beginnen, wie es sich für jedes Werk
gehört. Und so stellt sich die Frage des erhellten Geistes, der sich dem
Studium der Magie verpflichtet fühlt: was ist überhaupt Magie? Natürlich
wird es auch einem einfachen Bauern leichtfallen, Beispiele der Magie zu
benennen, seien es dunkle Flüche die seine Ernte vertrocken lassen oder
mächtige Kampfzauber, die einen Troll niederstrecken. Doch während ein
generelles Verständis existiert, genügt es dem hohen Arkanisten auf
keinen Fall, sich mit solchen Ungenauigkeiten abzugeben. Der angehende
Arkanist sollte stets bedenken, dass die Dominanz der Hochtürme und
Akademien auf der Präzision ihrer Methoden basiert. Nur so ist es dem
Arkanisten möglich, zur Spitze aller sterblichen Wesen aufzusteigen,
durch die Beherrschung der Magie.

Diesem Gedanken folgend wollen wir definieren, dass wir von Magie
sprechen, wenn ein sterbliches Wesen das astrale Netz mittels seines
Geistes manipuliert.

Denn nur entlang der Sterblichkeit einer Wesenheit, können wir zwischen
jenen Kreaturen unterscheiden deren Existenz mit dem Verlust der Seele
endet und jenen, die durch einen Mangel an Seele unsterblich sind. Denn
jene Wesenheiten gehören in das Reich der karmalen Kräfte, dem der
Götter und anderer höherer Wesenheiten, die in einem späteren Kapitel
eingehend behandelt werden sollen. Auch zur Natur des astralen Netzes
und des sterblichen Geistes soll zu späterer Zeit mehr gesagt werden.

[]{#_Toc523856296 .anchor}**Der Ursprung der Magie**

Während der Volksmund und auch einfache Kleriker die Meinung vertreten,
die Magie sei vom Patron der Magie, dem Sa'Hor Astrael, geschaffen
worden, so muß dieser Author dem widersprechen. Denn die Magie ist eine
der drei Konstanten der gesamten Existenz des Kosmos, zusammen mit der
Zeit und dem Raum selbst, verkörpert durch die Drachen Galamnor und
Tiamnor. Ob es einst einen dritten Drachen der Magie gab, welcher seinen
Leib aufgab um die Magie zu schaffen, oder ob sie das Verbindungselement
der beiden anderen Konstanten ist, ist nicht überliefert, wobei dieser
Author zu letzterem tendiert. Dies soll jedoch in keinster Weise das
Wirken des Sa'Hor Astrael beschränken, denn die meisten Arkanisten sind
sich einig, dass es erst sein Wirken war, welches den Sterblichen die
Möglichkeit eröffnete, die Magie zu manipulieren. Es steht indessen zur
Debatte, warum die Gabe, die Magie zu beeinflussen, manchen sterblichen
Wesen offensteht und anderen nicht. Manch einer vermutet den direkten
Einfluß der Götter selbst, wieder andere verweisen auf die
Konstellationen der Gestirne und nicht wenige glauben an eine Vererbung
ähnlich der Haarfarbe von Vater an den Sohn. Keine dieser Theorien kann
jedoch durch Beweise belegt werden.

## Unterschiedliche Magien

Für jenen, der sich neu mit der Magie befasst, mag es so scheinen als
gäbe es eine ganze Reihe von Magien in der Welt. Diese unterscheiden
sich stark in ihrer Art, Auswirkung und Verbreitung sowie natürlich in
ihrer Effizienz und Effektivität. Nachfolgend soll ein grober Überblick
über diese Magien geführt werden, bevor wir uns dem Aufbau der Sphären
widmen.

### Die drei Pfade der hohen Magie

Die wohl höchste Kunst in der Magie haben wohl jene erreicht, die sich
den drei Ita\'eij Glur, Il und En angeschlossen haben. Denn in den hohen
Hallen der Magierakademien Tares werden die präzisesten Theorien der
Magie, aufgebaut auf jahrtausendealten schriftlichen Traditionen,
entwickelt und debatiert. Die höchsten der Magier sind zu ganz
aussergewöhnlichen Taten im Stande, doch die wahre Macht liegt in der
Kombination ihrer Kräfte in Ritualen welche tareerschütternde Wirkungen
entfalten können.

### Der dunkle Pfad

Nie sollte man die drei wahren Pfade erwähnen, ohne auch den vierten zu
benennen. Der Ita\'Dor, der Pfad der schwarzen Magie. In seinen
Ansichten oft ähnlich, was die genaue Auslegung und Weiterentwicklung
magischer Theorien angeht liegt der Fokus des dunklen Pfades jedoch oft
auf der Macht höherer Wesen, die er zu knechten sucht. Doch auch hier
haben die schriftlichen Überlieferungen, sowie die Kultur genauer
Diskussionen zu überragenden Fähigkeiten geführt.

### Hexen

Obwohl jene, die allgemein als Hexen bezeichnet werden, sich im
Volksglauben kaum von den Wirkern der schwarzen Magie unterscheiden
lassen, haben sie sehr wenig mit jenen zu tun. Die Hexen hängen generell
dem Glauben an höhere Wesen an, welche sie in den planetaren Objekten
des Kosmos vermuten, so in Tare als Mutter und in Fela als Vater.
Demnach ist ihre Magie sehr intuitiv gesteuert, aus dem Unterbewußtsein
heraus gelenkt und demnach sowohl sehr wandelbar, als auch tendentiell
unpräzise.

### Druiden

Die Nähe zur Natur, welche die Hexen besitzen, ist auch den Druiden
gemein. Doch wo die Hexen die Natur als ein höheres Wesen ansehen,
betrachten die Druiden sich als Herren und Meister. Dementsprechend ist
ihre Magie weniger auf dem Glauben an solche Kräfte basiert, sondern auf
verbalen Überlieferungen vorangegangener Generationen und der
Manipulation der fünf Elemente, welche die Druiden mehr großer
Genauigkeit zu kontrollieren wissen.

### Elfen

Im Gegensatz zu den Menschen, ist ein jeder Elf in der Lage, die Magie
in geringer Art und Weise zu beeinflußen. Je nach Art der Elfen,
spiegelt sich dies in einer zunehmenden Nähe zur Natur wieder, welche
gleichzeitig mit einer stärkeren glaubensbasierten Magie einhergeht.
Während die Hochelfen Magie oft in ähnlicher Manier wie die Magier der
Türme wirken, ja dort sogar oft studieren, glauben die Waldelfen an die
höhere Macht des Therthao. Die ihre natürliche Affinität zur Magie,
womöglich auch basiert auf der Tatsache, dass die Elfen ursprünglich der
zweiten Sphäre entsprangen, vermögen die Elfen die Magie auf sehr
intuitive Weise zu kontrollieren.

### Myten

Die Myten, jenes Experiment, wenn man den alten Schriften glauben
möchte, des Sa'Hor Morsan welches man durchweg als gemischten Erfolg
betrachten kann, verfügen ebenfalls über eine eigene Form der Magie. Ein
jeder Myte ist in der Lage, ähnlich wie die Elfen auch, diese Magie zu
beeinflußen und zu formen, auch wenn sich eine elitäre Kaste innerhalb
ihrer Gesellschaft expliziter damit befasst. Genauere Kenntnisse über
ihre Magie sind diesem Autor jedoch nicht bekannt.

### Schamanen

Angesiedelt ebenfalls im Bereich der intuitiveren Magier finden sich die
Schamanen der verschiedenen Völker. Vermutlich eine der frühsten Formen
der Magie basiert sie sehr stark auf der Beschwörung, Kommunikation und
Unterwerfung verschiedener Naturgeister und Elementare. Dies kann, je
nach Ausprägung, entweder sehr kooperativ oder sehr imperativ ausfallen.

## Aufbau der Sphären

Nachdem die scheinbar unterschiedlichen Arten der Magie kurz erläutert
wurden, wollen wir uns nun dem Aufbau der Sphären im bestehenden Kosmos
widmen. So gibt es der Sphären drei, wobei die erste jene ist in der die
Sterblichen ihr Dasein fristen, genannt Mandon in der alten Sprache Run.
Die zweite Sphäre ist jene, in welcher die Götter und höheren Wesen
existieren, genannt Horandon. In der dritten Sphäre verweilen die
Geister der gestorbenen Sterblichen, sie ist das exklusive Reich
Morsans, genannt Vidon. Alle jener Sphären werden umschlossen vom
Drachen Rillamnor, dessen funkelnder Leib die Sterne unseres
Nachthimmels bildet.

### Mandon

Die erste Sphäre wird dominiert vom Drachen Tare, auf dessen Rücken wir
uns befinden und der umschlungen in den Tiefen seines Leibes den Yehorn,
den Weltenstein, hält. Auch die Drachen Fela und Vitamalin dürften den
meisten bekannt sein, welche die Form planetarer Objekte unseres Kosmos
annahmen. Im Gegensatz dazu finden sich die Monde Astreyon und Dorayon,
ersterer erschaffen als Dank für die Gabe der Magie aus reinem Silber,
letzterer durch den Einen aus der abgeschlagenen Klaue Tares selbst.
Mehr wäre zu sagen über die Schöpfung und den Kampf der Götter, doch mag
dies ein eigenes Werk werden.

### Horandon

Die zweite Sphäre, Heim der Götter und unsterblichen Wesen ist
unterteilt in drei Domänen. Die erste ist Ashordon, Reich der Sahor und
Enhor und beeinhaltet den Horlaf, das ätherische Spiegelbild des
Weltensteines, auch hier bewacht vom Geiste Tares. Die zweite Domäne ist
Mandor, oder auch Yerrodon genannt in der Sprache seiner Bewohner. Es
ist das Reich des Einen und seiner Dämonen, auch wenn Stimmen davon
sprechen, dass Mandor und seine Bewohner einst von einer Gottheit des
Chaos geformt wurden, welche dann vom Einen vertrieben wurde. Die letzte
Domäne ist das sagenumwobene Nidihor, welches in so wenigen Schriften
beschrieben wird, dass seine Existenz bezweifelt werden mag. Sollte es
jedoch existieren, wird ihm nachgesagt die Heimat fabelhafter Wesen wie
Feen und Kobolde zu sein.

### Vidon

Die dritte Sphäre ist das Reich des Sahors Morsan, in welches die
Geister der Gestorbenen geleitet werden um ihre letzte Ruhe zu finden.
Nichts ist bekannt über jenes Reich, ausser dessen was die wortkargen
Priester von sich geben. So lässt sich vermuten, dass es ein Reich der
Ruhe, des Schlafes und der Dunkelheit ist.

### Der Limbus

Nicht vergessen werden soll jener Raum, welcher sich zwischen den
Sphären erstreckt. Dies ist der Limbus, ein Äther negativer Energie. Er
trennt Mandon von Horandon, womöglich auch Horandon von Vidon, auch wenn
dies noch kein Sterblicher prüfen konnte. Er kann von geübten Magiern
kurzfristig mittels einer Geistreise besucht werden, ebenso ist es
möglich eine in der ersten Sphäre verankerte Globule in den Limbus zu
projezieren, doch ist dies mit erheblichen Gefahren verbunden da im
Limbus zahlreiche Kreaturen verschollen sind die dort auf Gelegenheit
warten zu entkommen.

# Magietheorie

Wollen wir uns nun den Theorien der Magie selbst zuwenden. Man sagt,
dass jeder gute Magier eine eigene Theorie verwendet um sein Wirken zu
erklären und letztendlich ist es das Zeichen eines wahren Magiers, dass
er sein Wirken vollständig und schlüssig erklären kann ohne sich auf
Aberglauben berufen zu müssen. Doch lassen sich alle Theorien und selbst
die Magie exotischerer Wirker auf einen gemeinsamen Nenner herunter
brechen, der sich offenbart, wenn wir uns zuerst mit der Einheit von
Korpus und Animus befassen. Wenden wir uns zuerst dem Animus zu.

## Aufbau des sterblichen Geistes

Der Geist aller sterblichen Wesen, unabhängig von Alter, Geschlecht oder
Rasse, besteht aus den drei gleichen Komponenten. Zuerst ist dort das
Bewußtsein, Sitz der Persönlichkeit, des rationalen Denkens, der Logik
und der Sprache. Nachfolgend ist das Unterbewußtsein, Sitz der
Instinkte, der Gefühle, der Sinne und der Träume. Zuletzt, der Zensor.
Jener befindet sich zwischen den Bewußtseinen und limitiert den Fluß von
Informationen zwischen den beiden. Denn, könnten alle Dinge, die unsere
Sinne sammeln gleichzeitig in unser Bewußtsein dringen, würden wir gar
dem Ansturm erliegen. Somit filtert der Zensor jene Dinge heraus, die
unbedeutend sein mögen für den Augenblick. Nur besonders starke
Intuitionen vermögen ihn gänzlich zu überwinden, wie auch manchenortes
Träume in unser Bewußsein aufsteigen mögen. Doch anders herum, vom
Bewußtsein zum Unterbewußtsein ist der Transfer von Wissen noch viel
restriktiver, mit der Ausnahme von jenen Wesen die der Magie fähig sind.
Denn, der Zensor jener Wesenheit ist durchlässig, so dass das Bewußtsein
dem Unterbewußtsein sehr klare Kunde übermitteln kann, wenn diese Kunde
mit entsprechender Form übermittelt wird.

## Harmonie des Seins

Diese Form wird erreicht durch die Harmonie des Seins, durch den
Einklang von Körper und Geist. Dieser Zustand wird als Gnosis bezeichnet
und kann durch Meditation erlangt werden, wobei geübte Magier ihren
Geist jederzeit in Gnosis versetzen können. In diesem Zustand vermag der
Magier es, dem Unterbewußtsein klare Vorstellungen von dem zu
vermitteln, was er erreichen möchte. Hierzu verwendet er eine Reihe von
Methoden, die von allen Anwendern der Magie zu größerem oder kleinerem
Ausmaß verwendet werden. Diese Methoden sind Wille, Geste und Wort. An
erster Stelle steht der Wille etwas zu erreichen, Ausdruck des Geistes
des Magiers. An zweiter Stelle folgt die Geste, der begleitende
korporale Ausdruck durch den Leib des Magiers. Zuletzt erfolgt das Wort,
welches die perfekte Symbiose von Körper und Geist darstellt und den
Willen in einen Laut verwandelt, der durch den Korpus wiedergegeben
wird.

Unabhängig von der Art der Magie und unabhängig von der Macht des
Wirkers, wird man immer eine oder mehrere dieser Methoden auffinden.
Doch dies alleine genügt zwar den Zensor zu überwinden, aber noch nicht,
dem Unterbewußtsein zu vermitteln was geschehen soll. Die Magie selbst
ist für den Geist der Sterblichen vermutlich letztendlich unergründlich,
genauso wie das Wesen der Zeit nicht vollständig begriffen werden kann.
Dennoch kann man Modelle der Magie erstellen, welche in der Lage sind
bestimmte Zusammenhänge zu erklären und entsprechend vorher zu sagen.
Diese Modelle bezeichnen die Magier der Türme als Magietheorien, die
Elfen nennen sie das Thertao, die Hexen die Mutter.

Letztendlich, egal wie man seine Magie erklären mag. Solange es sich
nicht um die tatsächliche karmale Kraft eines übernatürlichen Wesens
handelt ist es ein Model das versucht zu erklären, wie die Magie
funktioniert. Bezüglich dieser Modelle gibt es, offensichtlich, große
Unterschiede: Die der Magier zeichnen sich durch große Komplexität und
Detailgenauigkeit aus, was es den Turmmagiern ermöglicht sehr komplexe
Rituale zu wirken, sie aber bei anderen Dingen vor unlösbare Probleme
stellt. Auf der anderen Seite haben Hexen weniger komplexe Modelle der
Magie, die sie intuitiv auffassen und die in der Lage sind erstaunliche
Effekte hervor zu bringen. Allerdings mit deutlich geringerer
Genauigkeit. Die arkane Betrachtung, die Fähigkeit ein magisches
Konstrukt zu untersuchen, ist daher bei den Magiern der Türme an besten
ausgebildet, da diese versuchen, bestehende Magie durch die Linse eines
(oder mehrerer) bestehenden Modells zu interpretieren.

Somit spielt es keine Rolle, welches Modell ein Magier anwendet um seine
Anweisungen an das Unterbewusstsein zu übermitteln. Was essentiell
hierbei ist, ist die Überzeugung des Magiers, dass sein Modell
funktioniert. Im Rahmen der Möglichkeiten des verwendeten Modells lassen
sich dann entsprechende Effekte durch das Unterbewußtsein
materialisieren. Nachfolgend sollen nun einige der gängisten Theorien
der Magier der Türme dargestellt werden, welche auf jahrtausendelanger
Forschung beruhen und ineinander integriert sind.

## Fadentheorie

Die Astralfäden gehört zu den grundlegendsten Theorien der Türme. Es
wird zu Grunde gelegt, dass es Elementarfäden gibt, welche sich durch
alle Sphären des Kosmos ziehen und dabei das sogenannte Astralnetz
formen. Sie ist insbesondere für direkte Manipulation von Elementen
geeignet und findet auf Grund ihrer sehr hohen Detaildichte und
Fähigkeit, Zauber ins Kleinste hinunter zu brechen, bei Graumagiern
starke Anwendung.

Diese Fäden unterteilen sich in fünf Kategorien, je einem der Elemente
zugeordnet die da wären, Fe:Feuer, Kah:Luft, Ri:Erde, Xa:Wasser,
Wrathe:Geist. Diese Fäden ihrerseits unterliegen Abstoßungskräften die
auf den Aversionen der Elemente beruhen. So stoßen sich Feuer und Wasser
ab, sowie Erde und Luft. Andererseits ziehen Knoten eines Elements
weitere Knoten an, weshalb die Elemente dazu neigen sich in homogenen,
großen Ansammlungen zu häufen. Als Beispiel seien hier die Meere
genannt.

Dieses astrale Netz, bestehend aus den fünf Fäden, wird zum Zwecke
einfacher Betrachtung in zwei Bereiche unterteilt. Einmal das fixe und
einmal das lose Netz. Das fixe Netz kann auch schlicht als Realität
bezeichnet werden, so ist ein Stein nichts Anderes als eine fixe
Ansammlung von Erdknoten. Das fixe Netz unterliegt den grundlegenden
Gesetzen der Natur und kann von einem Magier nur in sehr beschränktem
und zumeist indirektem Maße verändert werden. Das lose Netz hingegen
entzieht sich dem Auge eines normalen Betrachters, offenbart sich jedoch
dem geübten Auge des Magus. Dies kann er manipulieren, Fäden miteinander
verweben und verschieben. Jedoch, damit ein Effekt entsteht, muß der
Magus Knoten bilden, denn nur, wenn Elementarknoten geformt werden,
zeigt sich auch ein korporaler Effekt im fixen Netz. Sprich, um einen
Feuerball zu schaffen, muß der Magus Feuerknoten in ausreichender Menge
formen oder zusammenziehen, damit dieser sichtbar wird. Würde er nur
Feuerfäden zusammenziehen, hätte dies keinen sichtbaren Effekt.

Die Fähigkeiten eines Magus, das Netz in seiner Umgebung zu
manipulieren, sind durch mehrere Faktoren begrenzt. Zuerst einmal
natürlich die Konzentrationsfähigkeit des Magus, die der Anzahl von
Fäden die er effektiv manipulieren kann, limitiert. Des Weiteren jedoch
auch die Präsenz der Anti-Fäden zu jenen, die der Magus zu manipulieren
sucht. Eine hohe Anzahl von Wasserfäden wird es deutlich erschweren
einen Feuerzauber zu wirken. Zusätzlich ist das astrale Netz nicht
permanent, sondern unterliegt einem beständigen Wandel dessen Tempo sich
je nach Ort und Zeit stark unterscheiden kann. Und natürlich unterliegt
das lose astrale Netz auch den Effekten des fixen Netzes, somit
reduziert auch ein starker Regen die Möglichkeit einen Feuerball zu
schaffen. Hier sei jedoch angemerkt, dass die notwendige Dichte an
Fäden, um entsprechende Interferenz durch Aversion zu erschaffen, sehr
hoch sein muß und ein guter Magus durch einen einfachen Regen nicht
nennenswert daran gehindert sein wird einen Feuerball zu schaffen.

## Aurentheorie

Die Aurentheorie findet inbesondere in Kreisen der Weißmagier Anwendung,
da sie eine weniger detailgetreue Betrachtung ermöglicht, dafür aber
erlaubt größere Zusammenhänge zu erkennen. Dies hat sich insbesondere in
der Heilmagie als extrem nützlich herausgestellt, wenn man den Korpus
der verwundeten Person als Einheit betrachtet. Die Aurentheorie geht
hierbei davon aus, dass im Korpus eines jeden lebenden Wesens eine Reihe
von Aurenzentren existiert, welche Ströme aussenden, die durch den
Korpus wandern. Diese Ströme, würde man sie im Detail betrachten, wären
jedoch nichts Anderes als gebündelte Elementarknoten und -fäden, die
sich durch den Leib bewegen, auch wenn so eine genaue Betrachung nicht
sinnbringend wäre. Die Aurenzentren hingegen bilden fokale Punkte, an
denen die Fäden zu Strömungen vereint werden. Wird ein solches
Aurenzentrum zerstört, wird der Gesamtstrom des Leibes so sehr gestört,
dass eine Heilung nicht mehr möglich ist und der Tod kurz darauf
einsetzt. Die Summe alle Strömungen im Leib eines sterblichen Wesens ist
die sogenannte Aura der Person. Diese kann als ganzes betrachtet
gestärkt, geschwächt, verformt, bewegt oder zerstört werden. Sie kann
jedoch auch gezielt an einzelnen Stellen, sprich im Bezug auf einzelne
Strömungen manipuliert werden. Eine Wunde am Arm beispielsweise würde
sich als Störung des Stromes vom Aurenzentrum im Herzen zur Hand hin
darstellen und ein Magus könnte diese Störung relativ einfach
ausgleichen.

Den Leib eines Menschen im Rahmen der Aurentheorie detailliert
dazurstellen, übersteigt die Möglichkeiten dieses Werkes jedoch bei
Weitem und somit sei es der praktischen Anwendung überlassen, dies zu
demonstrieren. Es sei noch gesagt, dass die Aurentheorie ebenso in der
Lage ist, andere Wesenheiten zu betrachten, sowie deren Verbindung zu
möglichen Kraftquellen zu anaylsieren und gegebenenfalls auch zu kappen,
was in der Bannungsmagie Anwendung findet.

## Theorie der größeren Ströme

Die Theorie der größeren Ströme betrachtet das Konzept der Fäden auf der
Ebene ganzer Landstriche und Kontinente. Dabei gelten zwei wichtige
Annahmen, basierend auf den grundlegenden Gesetzen der Fadentheorie.
Durch die Aversion der zwei Elementargruppen Feuer/Wasser und Erde/Luft,
trennen sich die Elemente in relativ homogene Gruppen, wobei Mischungen
zwischen Wasser/Erde und Luft/Feuer häufiger vorkommen. Durch die
Anziehungskraft größerer Elementarknotenansammlungen auf kleinere
hingegen tendieren diese Gruppen dazu, relativ massiv zu werden. Dies
ist mitunter der Grund, warum die Elemente sich insofern getrennt haben,
dass wir von einer natürlichen Ordnung sprechen können. So streben die
Flüsse ins Meer, so steigen Wasserblasen an die Oberfläche, so fallen
Steine gen Boden und steigen Funken und Flammen nach oben, gen Fela. Je
nach Natur des betroffenen Elements und den Umständen, sind diese
Prozesse jedoch ausgesprochen langsam und teilweise hoch komplex. Da
Aversion stärker wird, je geringer der Abstand zwischen zwei Elementen
ist, jedoch schon bei moderaten Abständen kaum bemerkbar wird, ist die
Anziehungskraft hier das deutlich stärkere der beiden Gesetze.

Diese Gesetzmäßigkeiten betreffen sowohl das fixe, als auch das lose
astrale Netz, wobei in ersterem diese Kräfte deutlich langsamer von
statten gehen, als in letzterem. Es gilt generell, dass wo Kräfte des
fixen Netzes walten, auch im losen Netz Kräfte sind, jedoch nicht
unbedingt im Gegensatz. Nehmen wir ein Lavabecken in der Ödnis, welches
geschmolzenes Gestein an die Oberfläche bringt. Hier werden zwei Ströme
aktiv, einmal der des Feuers einer der Erde. Im fixen Netz bildet sich
im Umkreis starke Hitze und flüssiges Gestein mag langsam über den Boden
fließen. Im losen Netz hingegen steigen Feuerströme gen Himmel auf
während Erdströme über die Oberfläche in der Umgebung fließen und sich
dabei mitzunehmender Entfernung auflösen. Dementsprechend könnte der
geneigte Magus auch in einiger Entfernung von besagter Lavaquelle die
Erdströme, die von ihr ausgehen, prüfen und somit Rückschlüsse auf
Vorkommnisse an diesem Ort ziehen.

Größere Bedeutung entwickelt die Theorie der größeren Ströme jedoch in
Bezug auf die Haltbarkeit von Zaubern und die Effektivität von Ritualen.
Jeder Magus, wie auch viele Laien, weiß, dass kein Zauber unbegrenzt
lange existiert. Beschworene Flammenwände erlischen, Schutzzauber lösen
sich auf, beschworene Kreaturen kehren in ihre Heimat zurück. Dies ist
auf die beständigen Verschiebungen der Elementarfäden zurück zu führen,
deren stärkste Ausprägung sich in den größeren Strömen wiederfindet. Ein
Zauber, der sich zahlreicher Luftfäden bedient, würde in der Nähe dieser
Lavaquelle, bzw. im Strom der größeren Erdströme, die dort entstehen,
weniger lange bestehen als an einem Ort, wo die Verschiebung der
Elementarfäden schwächer ist. Ebenso wäre es natürlich erheblich
schwieriger, in einem solchen Strom ein Ritual durchzuführen, so dieses
nicht vom Strom selbst profitieren kann. Bei der Auswahl eines
geeigneten Ritualortes ist daher auf die Konvergenz magischer Ströme
explizit zu achten, um den Erfolg zu garantieren.

Auch wenn es noch zahlreiche andere Magietheorien gibt, so mögen die
hier benannten ausreichen um einem jeden Magus ausreichende Kenntnisse
zu vermitteln. Wollen wir uns nun jedoch der höheren Magie zuwenden.

# Ritualkunde

Wie bereits oben erwähnt wurde, ist die Fähigkeit eines Magus das
astrale Netz in seiner Umgebung zu manipulieren durch mehrere Faktoren
limitiert, nicht zuletzt durch die Konzentrationsfähigkeit des Magus
selbst. Doch all jenes, was ein Magus innerhalb weniger Atemzüge
schaffen kann, verblasst im Vergleich zu jenen tareerschütternden Werken
die durch präzise geplante und ordentlich ausgeführte Rituale mehrerer
Magier erreicht werden können. Im nachfolgenden Kapitel sollen die
Grundlagen der Rituale beschrieben werden, denn so vielversprechend ihre
Anwendung ist, so groß sind die Gefahren, die damit einhergehen.

## Definition Rituale

Rituale sind eine Erweiterung der üblichen Magie. Demnach sind Rituale
die Manipulation des astralen Netzes durch den Geist eines Sterblichen
unter Berücksichtigung von Hilfsmitteln, die den Effekt dieser
Manipulation über das normale Maß hinaus verstärken. Muss ein Magier in
einer normalen Wirkung sämtliche Komponenten des Zaubers aus sich heraus
wirken, so kann er beim Ritual manche Komponenten auslagern.

## Die Kreise

Eines der wichtigsten Werkzeuge bei der Verwendung von Ritualen sind die
Kreise. In der klassischen arkanen Literatur gibt es nach Fahnduk und
Hankuk eine starke Neigung zur Verwendung von geometrischen Mustern im
Aufbau von Ritualen, diese sind jedoch zu meist einer zu starken
Zuneigung zur Mathematik und dem Aberglauben geschuldet. Letztendlich
fußt die Verwendung von Ritualformen auf der Magietheorie und den
grundlegenden Gesetzen die dort etabliert wurden. Dementsprechend
unterscheiden wir zwei fundamentale Kreise in der Ritualmagie: Den
Bannkreis und den Schutzkreis. Beide funktionieren nach dem selben
Prinzip, jedoch mit unterschiedlicher Wirkung die durch eine
geringfügige Modifikation erreicht wird. Die Aversität der Elemente wird
hierbei genutzt um eine Barriere zu bilden. In beiden Kreisen ist das
Ziel des wirkenden Magiers, solch eine Barriere zu formen um entweder
etwas in dem Kreis zu halten, oder es aus dem Kreis heraus zu halten.
Dementsprechend wird aus den Elementarfäden ein Netz um den Magier
gebildet, wobei jedes Element vertreten sein muss. Aus diesem Grund wird
ein Kreis in der astralen Ebene wie eine Zwiebel aufgebaut, wobei jedes
Element eine der Schichten bildet. Ein dichtes Netz aus Feuerfäden
verhindert dementsprechend, dass Wasserknoten/Fäden die Barriere
durchdringen, während eine zweite Schicht aus Wasserfäden das gleiche
für Feuerfäden/Knoten tut. Die über einander liegenden fünf Schichten
bilden somit, auf Grund der Aversität der Elemente, einen Widerstand für
jeden Zauber aber auch Gegenstand des fixen astralen Netzes, der
versucht dieses Gewebe zu durchdringend. Natürlich ist die Dichte und
Plastizität des Gewebes hier ausschlaggebend für die Stärke des
Schutzes, ein Netz das aus erheblich mehr Knoten geweben wird, wird auch
deutlich größere Aversion gegen einen anfliegenden Pfeil ausüben und ein
Netz, welches starrer und fester gehalten wird und weniger nachgibt,
wird dies ebenso tun.

Zur Kontrolle und Stabilisierung dieser Kreise verwendet der wirkende
Magier Geistfäden, die er direkt kontrolliert und durch alle diese
Schichten hindurch wirkt. Die Geistfäden verhindern, dass das Gewebe aus
einander weicht, wenn es unter Druck gerät und verhindern ebenso eine
Manipulation durch andere Magier. Der Hauptunterschied bei den Bann- und
Schutzkreisen ist hierbei, dass neben den vier Schichten Feuer, Erde,
Wasser und Luft, die man relativ beliebig anordnen kann, entweder Innen
oder Aussen aber immer dem Magier zugewandt, sich die Geistschicht
befindet. Wenn es sich um einen Schutzkreis handelt, befindet sich der
Magier darin, ebenso natürlich die Schicht des Geistelementes.

Die Funktion der Kreise ist durch ihre Namensgebung relativ
offensichtlich. Schutzkreise dienen dazu, sowohl magische als auch
pysische Effekte vom Magier oder einem Ort fernzuhalten, dementsprechend
werden sie auch dazu benutzt Ritualorte von äußeren Einflüssen
abzuschirmen. Allerdings, je größer der Kreis, desto gering die
Schutzwirkung bzw, desto größer der magische Aufwand. Bannkreise
hingegen haben den Zweck einen Effekt oder eine Kreatur einzudämmen und
werden einerseits benutzt um das Herz eines Rituals zu umgeben, für den
Fall das unkontrollierte magische Effekte auftreten, die sonst die
Rituallteilnehmer verletzten würden, oder aber um eine Kreatur die
gebannt oder beschworen werden soll, unter Kontrolle zu halten.

## Paraphernalia

Neben der Verwendung von Kreisen wird in Ritualen auch in den meisten
Fällen auf verschiedene Materialien zurückgegriffen, die dazu dienen die
Magie zu fokusieren, zu binden und zu erhalten. Diese Materialien lassen
sich, generell gesprochen, in drei Katergorien einteilen. An erster
Stelle stehen die Anker, welche in der Lage sind Fäden zu festigen, so
dass diese ein Gewebe länger erhalten können. An zweiter Stelle stehen
die Foki, welche in der Lage sind Wirkungen von Zaubern zu fokussieren.
An letzter Stelle stehen die Speicher, die in der Lage sind arkane Kraft
zu sammeln und für eine spätere Verwendung nutzbar zu machen.

### Anker

Viele Gegenstände eignen sich in ihrer Form dazu, die Fäden des astralen
Netzes im astralen Raum zu fixieren und damit magischen Geweben eine
längere Haltbarkeitsdauer zu geben, als diese natürlicher Weise hätten.
An erster Stelle stehen hierbei die Edelsteine, die durch ihre große
Reinheit und kristalline Struktur besonders geeignet sind, Fäden
zeitweilig zu halten. Allerdings zeichnen sich Edelsteine durch eine
relativ schwierige Beschaffung aus und sind für viele Magier mit
beschränkten Mitteln nicht das Werkzeug der Wahl. Auf der anderen Seite
gibt es aber eine ganze Reihe von kristallinen Strukturen, die günstig
beschafft und verwendet werden können z.B. Salz, welches zwar durch
seine übliche Verwendung in der dunklen Magie etwas in Verufenheit
geraten ist, aber sich hervorragend eignet. Inbesondere für die
Erschaffung von Bann- und Schutzkreisen eignet sich eine feinkörnige
kristalline Form besser als eine grobe, d.h. es ist effektiver Salz in
einem Kreis zu streuen statt fünf Edelsteine abzulegen, da die
Edelsteine das magische Gewebe nur an fünf Punkten sichern und damit
zwischen diesen Punkten eine Schwachstelle entsteht.

### Foki

Foki sind Gegenstände, die es erlauben einen magischen Effekt zu
fokussieren. Dies bedeutet nicht, dass der Effekt ingesamt stärker wird,
sondern dass er schlichtweg konzentrierter auftritt. Foki werden also
dazu genutzt, magische Effekte durch einen zentralen Punkt zu erzeugen,
welcher die Eigenschaft aufweist, den Effekt zu konzentrieren wie eine
Stromschnelle eines Flusses.

Ein konkretes Beispiel umfasst hier zum Beispiel eine sauber
geschliffene Lupe, die wir in einem Ritual zur Erschaffung einer
Landkarte verwendet haben. Dazu sandten wir eine Reihe von Geistfäden
über die Oberfläche der Insel um die Form der Landschaft abzutasten und
verwendeten dann die Lupe um dieses extrem große Gewebe magisch zu
verkleinern so dass es mit einem Blick erfasst werden konnte. Andere
Foki umfassen, z.B. in der schwarzen Magie, Kerzen die aus dem Blut oder
Fett von Menschen gewonnen werden und die in der Lage sind, Bannkreise
zu fokussieren und deshalb gemeinsam mit Edelsteinen oder anderen
kristallinen Konstrukten verwendet werden. Auch Foki aus dem Bereich der
Elemente (z.B. reines Wasser, seltene Hölzer, Elfenatem) sind bekannt.

Eine genauere Erklärung für die Funktionsweise von Foki ist im Übrigen
nicht bekannt, oftmals werden diese nach dem Prinzip der
Vergleichbarkeit ihrer Funktion im fixen astralen Netz ausgewählt, womit
ihre logische Bedeutung für das Unterbewußtsein vermutlich gegeben ist.
Eine weitere Erforschung dieses Feldes wäre ratsam.

### Speicher

Im Gegensatz zu Ankern und Foki sind Speicher Gegenstände, die in der
Lage sind astrale Kraft, wie sie in der Aura des Magiers generiert wird,
zu sammeln und über längere Zeiträume zu erhalten. Damit dies gelingen
kann, muß der Magier eine Übertragung seiner Kraft zuerst durchführen,
danach kann der Speicher aber in arkane Gewebe eingewoben werden um
diese zu speichern bis seine Kraft verbraucht ist. Nur wenige Objekte
eignen sich sehr gut dafür, arkane Kraft zu sammeln. Auch hier zeichnen
sich Edelsteine, wegen ihrer kristallinen Struktur, als geeignet aus.
Arkanium hingegen, ein Material, das unseres Wissens nach, nur auf der
Insel Siebenwind gefunden werden kann, ist in der Lage sehr große Mengen
arkaner Kraft für sehr lange Zeiten (womöglich viele Jahre) zu
speichern. An der königlichen Magierakademie wurde ein solcher
Arkaniumspeicher sogar dafür verwendet, einen Felaturm zu betreiben,
auch wenn die Kristalle im geladenen Zustand beständig gekühlt werden
mussten.

## Auswahl des Ortes

Zur guten Vorbereitung eines Rituals gehört die Auswahl des Ortes, an
dem das Ritual stattfinden soll. Dabei sollte sich der Magier von
mehreren Überlegungen treiben lassen. Zuerst einmal sollte, rein
pragmatisch gesehen, der Ort so gewählt sein, dass das Ritual selbst im
Falle eines schlimmen Unfalls keine größeren Schäden anrichtet. Von
daher sind besiedelte Orte und Akademien in aller Regel zu vermeiden.
Zusätzich sollte ein Ort natürlich geschützt und ungestört sein, gerade
bei Ritualen die in einer Konfliktsituation gewirkt werden ist der
Schutz vor dem Feind essentiell. Doch abgesehen von diesen Überlegungen,
die der gesunde Menschenverstand sowieso gebieten sollte, muß der Magus
sich auch bewußt sein, dass die Effektivität seines Rituals von mehreren
magischen Faktoren abhängt.

An erster Stelle stehen hierbei die größeren Ströme. Wie in
vorhergehenden Kapiteln erwähnt, unterliegen alle gewobenen Zauber dem
Druck der Elemente in der Form, dass das astrale Netz sich in Bewegung
befindet und daher bestehende Gewebe durch den Strom und Sog der
Elemente mit der Zeit aus ihrer Form gebracht werden und dann zerfallen.
Dies ist jedoch nicht an allen Orten im gleichen Maße der Fall, so sind
besonders elementare Ort nahe Feuerquellen, Flüssen oder Bergspitzen
besonders den Elementen Feuer, Wasser oder Luft, respektive, ausgesetzt.
Dies kann für das Ritual von Vor- und Nachteil sein, je nachdem wie die
größeren Ströme genutzt werden. Ein Feuerritual in der Nähe eines
Flusses zu halten würde z.B. weniger effektiv sein, als in der Nähe
eines Lavabeckens, wo es einfacher wäre die nötigen Knoten zu sammeln.
Dementsprechend sollte der Magus die größeren Ströme untersuchen und
danach entscheiden, ob der Ort geeignet ist oder nicht.

Zweitens gilt es, die natürlichen Bewohner des astralen Raumes nicht
gegen das Ritual aufzubringen. da Rituale generell nicht in Städten
abgehalten werden sollte, finden viele davon in der freien Natur statt.
In den Wäldern, Auen und Wiesen der Landschaften leben jedoch sehr viele
Naturgeister und auch wenn die meisten von ihnen sich nicht durch große
Macht auszeichnen gibt es einerseits sehr mächtige Ausnahmen und
andererseits kann die reine Masse der Geister ein Ritual erheblich
beeinflussen. Es gilt hierbei, das Wohlwollen oder zumindest die
Neutralität der Geister zu sichern, indem der Magus z.B. seine
Intentionen vor Beginn des Rituals erklärt um die Geisterwelt davon zu
überzeugen, dass ihrer Welt kein Schaden droht. Die Involvierung eines
Schamanen oder Naturmagiers ist hier empfohlen, wenn möglich.

## Vorbereitung des Ortes & des Selbst

Nach dem Ort ausgewählt wurde, gilt es ihn und die Teilnehmer für das
Ritual zu präparieren. Dazu gehört neben der Entfernung von störenden
Elementen (z.B. Gaffer, Abfall oder ähnlichem), auch die magische
Reinigung des Ortes dazu. Ich verweise hier auf die Methoden des Hankuk
(siehe Hankukscher Faustschlag) für eine praktische Schilderung der
Vorgehensweise und werde mich auf die arkane Umsetzung konzentrieren.
Letztendlich gilt es, störende magische Einflüsse die zufälilg
entstanden sein könnten oder aber von anderen Magiewirkern
zurückgelassen wurden zu entfernen um eine Interferenz mit dem zu
webenden Ritual zu vermeiden. Gerade an Orten, die oftmals von Magiern
frequentiert werden findet man oft noch Reste von arkanen Geweben, die
unter ungünstigen Umständen mit einem neuen Gewebe auf sehr negative
interagieren können. Es gilt also, einen Zauber basierend auf dem
Element Geist zu weben um diese Gewebe endgültig aufzulösen.

Im zweiten Schritt sollten auch alle Teilnehmer des Rituals sich selbst
reinigen. Eine Ortsreinigung ist normalerweise nicht in der Lage die
Aura und damit die natürliche Magiereisistenz der anderen Magier zu
überwinden, daher muß dieser Akt von jedem selbst durchgeführt werden.
Auch hier wird sichergestellt, dass an dem Magier keine Reste alter
Magie mehr haften die interagieren können.

## Durchführung von Ritualen

Es folgt nun eine generelle Beschreibung von Vorgehensweisen, die für
ein Ritual angewandt werden können. Es gilt für Rituale, was auch für
andere Magie gilt: Mit Wille, Wort und Geste wird die Magie verändert,
nur, dass dies hier nicht nur durch einen Magier für einen kurzen
Augenblick passiert, sondern ein größerer Effekt oftmals mit vielen
Magiern geschaffen wird. Hierbei gibt es zwei generelle Klassen von
Ritualen, die aber alle mehrere Dinge gemein haben. Erstens muß der Ort
begründet ausgewählt sein. Zweitens müssen mögliche Störfaktoren
beseitigt sein, bevor der Ort und die Teilnehmer gereinigt werden.
Danach werden die notwendigen Kreise gezogen, dabei ist es höchste
empfehlenswert um das zu erschaffende magische Gewebe einen Bannkreis zu
ziehen um im Fall einer unerwarteten magischen Reaktion vor ebendieser
geschützt zu sein. Ein Schutzkreis empfiehlt sich, wenn Störungen von
ausserhalb zu erwarten sind oder, wenn die Ritualteilnehmer sich
individuell schützen möchten.

Durch einen gemeinsamen Ritualtext in Run lässt sich dann die Kraft der
Magier in Einklang bringen und kann auf zwei Arten zu dem zu wünschenden
Gewebe gemacht werden.

Parallel

In einem Parallellritual erschaffen alle Teilnehmer des Rituals das
magische Gewebe gleichzeitig, d.h. alle Weben am gleichen Werk. Dies
verlangt von allen Teilnehmern die notwendigen Fähigkeiten und ist daher
für erfahrene Magier ab dem Adeptus zu empfehlen. Der Vorteil dieser
Vorgehensweise ist, dass komplexe Gewebe relativ schnell erschaffen
werden können, was die arkanen Kosten reduziert da längere
Erhaltungsarbeiten nicht notwendig sind. Auch kann höhere Komplexität
somit erreicht werden. Dies verlangt jedoch auch eine intensive
Vorbereitung.

Fokusiert

In einem fokusierten Ritual webt nur einer der beteiligten Magier, der
Ritualleiter, das zu schaffende Gewebe während die anderen Magier ihm
einen Teil ihrer Kraft übertragen um dies zu ermöglichen und
gleichzeitig ihre verbleibende Kraft dafür einsetzen die bereits
gewobenen Teile zu erhalten, damit diese nicht verfallen. Diese Methode
eignet sich für eher einfache Rituale in denen große Kraft angewandt
werden soll (z.B. in der Kampfmagie) und ist gut geeignet um Novizen an
Rituale heranzuführen da der Schaden, den diese anrichten können hier
stark beschränkt ist.

In einem Ritual werden demnach unter Verwendung verschiedener
Hilfsmittel und unter Beseitigung aller möglichen Störfaktoren stärkere
(im Sinne von größerer Potenz und oder Haltbarkeit) magische Effekte
geschaffen, die aus dem \"Stehgreif\" schlichtweg nicht möglich sind.
Eine Reihe von gut dokumentierten Ritualen ist an der Magierakademie zu
Siebenwind für den interesierten Novizen und Adepten verfügbar.

# Illusionistik

Die Illusonistik ist eine Unterart der Magie, die dem grauen Pfad
besonders naheliegt. Es handelt sich hierbei um die gezielte Täuschung
der Sinne eines sterblichen Wesens durch Magie und wird dem grauen Pfad
aus einer Tradition der Verschwiegenheit, Täuschung und Manipulation
nahegelegt. Und auch wenn niemand ernsthaft bestreiten mag, dass diese
Punkte im Ita\'Glur durchaus vorkommen und auch gezielt gefördert
werden, so hängt die Nähe zur Illusionistik nicht damit zusammen.
Vielmehr ergibt sich diese Nähe aus dem Credo, dass Wissen Macht ist.
Aber alles Wissen, welches ein Sterblicher erringen kann ist direkt
davon abhängig, was seine Sinne ihm vermitteln, denn unser Geist ist von
der Realität durch die Sinne vollständig abhängig. Von daher ist die
Illusionistik die höchste Kunst des grauen Pfades, auch wenn dieser
allgemein eher für seine Kampfmagie bekannt sein mag.

## Anzahl der Sinne

Die Manipulation der Sinne beginnt natürlich mit deren Anzahl, bzw. der
Kunde darum. So hat ein normales Sterbliches Wesen fünf Möglichkeiten,
seine Realität zu erfassen: Sehen, Hören, Tasten, Riechen und Schmecken.
Ich habe diese fünf Sinne in Reihenfolge Ihrer Bedeutung im alltäglichen
Leben gelistet, denn normale Sterbliche verlassen sich zuerst auf ihre
Augen, dann auf Ihre Ohren während der Geschmackssinn am seltensten
verwendet wird. Es kommt jedoch dazu, dass Magier einen weiteren Sinn
besitzen, nämlich die Möglichkeit die Magie wahrzunehmen und zu
interpretieren. Dies kann in der Form arkaner Sicht geschehen, es kann
aber auch auf andere Art gelingen. Der arkane Sinn ist von den anderen
Sinnen unabhängig und erlaubt es Magiern daher relativ schnell,
Illusionen auf diese Art und Weise zu entlarven.

Illusionen zu weben ist einerseits unkomplixiert in der Theorie und doch
komplex in der Praxis. In den allermeisten Fällen wird die Fadentheorie
herangezogen um das Weben von Illusionen zu beschreiben. Um die Sicht
einer Person zu täuschen genügt es, Feuer- und Luftfäden zu Licht zu
verweben und in die richtige Konstellation und Form zu bringen, so dass
das gewünschte Abbild entsteht. Dieses hat natürlich noch keine Substanz
und verursacht keine Geräusche, um dies zu erreichen müsste man
Erdknoten für Festigkeit und Luftknoten für den Ton hinzufügen, wodurch
ein selbst vergleichsweise einfaches Gewebe schnell an Komplexität
gewinnt und es damit schwer wird, alle Sinne einer Person vollständig
überzeugend zu täuschen. Glücklicherweise sind jene Sinne, die am
schwierigsten zu täuschen sind, auch jene die die geringste Bedeutung
haben. Auf magische Art und Weise den Tastsinn zu täuschen ist zwar
schwierig, aber machbar. Geruchs- und Geschmackssinn überzeugend zu
täuschen hingegen ist noch deutlich schwerer und wird daher in den
meisten Fällen nicht gemacht, da das Ziel der Illusion sich durch eine
überzeugende Darbietung der anderen drei Sinne meistens von der Realität
einer Sache überzeugen lässt.

Illusionen selbst lassen sich nun in zwei Kategorien einteilen.

## Objektiv

Objektivillusionen sind solche, die objektiv von allen Personen am Ort
der Illusion wahrgenommen werden können. Wenn ein Graumagier sich
beispielsweise unsichtbar macht, hüllt er sich letztendlich nur in eine
Lichtillusion, die den Raum direkt hinter dem Magier zeigt, so dass er
selbst nicht sichtbar ist. Dies ist für alle Personen an einem Ort
gleichermaßen der Fall (bei einer vollständig einhüllenden Illusion).
Objektivillusionen sind aus pragmatischer Sicht dann angebracht, wenn es
gilt eine größere Zahl von Personen zu beeinflussen, weil ein einzelner
Zauber hier genügt. Allerdings ist es sehr aufwendig, eine objektive
Illusion größerer Fläche und hoher Komplexität zu wirken, z.B. ein
ganzes Haus illusionistisch so zu schaffen, dass mehrere Sinne in einem
großen Gewebe getäuscht werden. Dementsprechend sollte der geneigte
Magier immer eine Abwägung zwischen Kosten und Nutzen machen, wenn er
eine Illusion plant und im Falle von großen und komplexen Illusionen
statt einer objektiven Illusion eine subjektive benutzen.

## Subjektiv

Bei einer subjektiven Illusion wird kein Gewebe \"in den Raum\"
gestellt, das jeder sehen kann, sondern das illusonistische Gewebe wird
auf die Person gelegt, die getäuscht werden soll. Es gibt
magietheoretische zwei größere Ansätze, wie dies getan werden kann. Bei
einer einzelnen Person, die man sehr umfassend täuschen möchte, kann man
die entsprechenden Gewebe aus Fäden direkt um diese legen, sprich
Lichtillusionen über die Augen, Erdgewebe über die Hände (oder andere zu
täuschende Körperteile), Luftgewebe an die Ohren. Damit kann man eine
Person effektiv vollständig von der Realität abtrennen und in eine
gänzlich andere versetzen. Da dies aber vergleichsweise aufwendig ist,
empfiehlt es sich, diese Methode nur bei sehr wenigen Personen
durchzuführen. Die alternative Methode besteht darin, den Rahmen der
Fadentheorie zu verlassen und die Aurentheorie zu verwenden. Hier werden
die Filiae Sensorei angetastet, welche sich in der Aura einer Person
befinden und quasi die Verbindung zwischen dem Geist und den Sinnen
darstellt. Somit beeinflusst das Gewebe die Sinne direkt und nicht mehr
indirekt durch ein arkanes Gewebe. Eine solche Manipulation wird in der
Regel durch Geistfäden durchgeführt, welche einen Einfluss auf die
Filiae Sensori nehmen und damit die Informationen, die dem Geist
zugetragen werden, manipulieren. Solche Gewebe sind in der Erschaffung
komplex, erlauben es aber mehrere Personen gleichzeitig illusonistisch
quasi perfekt zu täuschen und ihnen auch \"große\" Illusionen, z.B.
ganze Städte zu vermitteln, wenn man diese entsprechend planen kann.

Generell gilt hierbei, dass Illusionen anfälliger werden, desto
komplexer sie sein sollen. Denn letztendlich ist eine Illusion nur so
gut, wie ihre Überzeugungskraft und diese hängt direkt mit der
Authentizität des Dargestellten zusammen. Wenn die Uhren in der Illusion
nicht ticken oder der Teppich im Zimmer des Bezauberten die falsche
Textur hat, kann der Realismus der Illusion schlagartig beendet werden.
Zwar gelingt es dem Opfer dann in der Regel dennoch nicht, den Zauber an
sich loszuwerden, aber in dem Moment in dem er weiß, dass er in einer
Illusion ist hat diese zumeist ihren Zweck verfehlt. Inbesondere Magier,
die man vielleicht durch eine sehr gute Illusion täuschen kann, da sie
ihren arkanen Sinn nicht angewandt haben, würden spätestens in dem
Moment in dem sie Verdacht schöpfen die Illusion sehr schnell
durchschauen.

# Kampfmagie

Die Kampfmagie wird oft als Königsdisziplin des grauen Pfades
bezeichnet. Dem möchte ich insofern widersprechen, dass die Kampfmagie
sicherlich eine Spezialität des grauen Pfades ist, die Anwendung von
Kampfmagie jedoch jedes Mal zeigt, dass die eigentlichen Werte von
Information, Kontrolle und Illusion des grauen Pfades nicht eingehalten
werden konnten. Sie wird generell in zwei Ebenen der Kampfmagie
unterteilt, der ordinären und der Kriegsmagie. Erste bezieht sich in
erster Linie auf den Konflikt zwischen wenigen Personen, bzw sehr
kleinen Gruppen während die Kriegsmagie sich als Element des
Schlachtgeschehens versteht und dort einreiht. In diesem Kapitel werden
wir uns hauptsächlich der Kampfmagie widmen, da die Kriegsmagie nur in
Kombination mit Wissen über Strategie, Führung und Taktik und Logistik
verstanden werden kann.

Generell ist das Ziel der Kampfmagie, offensichtlicher Weise, einen
Feind unschädlich zu machen. Während dieses Ziel im Weißen Pfad
traditionell mit eher weichen Methoden erreicht wird, verwendet der
Graue Pfad hier in erster Linie Methoden bei denen nur der Grad der
Anwendung darüber entscheidet, ob das Ziel des Zaubers jemals wieder in
der Lage sein wird Widerstand zu leisten. Dementsprechend umfasst das
Repertoire hier eine ganze Reihe von Zaubern und Methoden um ein Ziel
unschädlich zu machen. Zum Zwecke der Übersicht unterteile ich die Arten
der Kampfmagie in vier Subkapitel.

\- Direkte Kampfmagie

Die direkte Kampfmagie umfasst all jene Zauber, die darauf ausgerichtet
sind einen direkten schädlichen Effekt an einem Ziel zu erfassen.

\- Indirekte Kampfmagie

\- Flächenmagie

\- Beschwörungen

# Translokation

## Sphärenrisse

## Geistreise

## 

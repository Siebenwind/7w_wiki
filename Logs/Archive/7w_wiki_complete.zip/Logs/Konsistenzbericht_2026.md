# Konsistenzbericht 2026 - Batch 120-145

**Status:** ⚠️ Dokumentierte Lücken
**Datum:** 2026-02-12

## Prüfobjekte
- Siebenwind Bote 120 - 145
- Personenregister.md (Einträge 120-145)

## Identifizierte Entitäten & Fakten
- **Zentralschicksale:** Elares Valjean (Bote 122), Woran Lebensmüh (Bote 130).
- **Orte:** Brandenstein (Zentrum), Falkensee (Baustelle), Greifenklipp (Nortraven).
- **Organisationen:** Handelsbund (aufgelöst in 130), Lehensbanner, Baronsgarde.

## Konsistenzprüfung
1. **Personenbenennung:**
    - *Steiner / von Steiner:* In 127 als " Steiner" erwähnt, in 130 als "Haus Steiner". Konsistent als Adelsgeschlecht.
    - *Laurelin:* Konsistent als Beraterin in 124 und 128.
2. **Chronologie:**
    - Alle Berichte liegen im Jahr 15 n.H. (Sekar, Carmar, Oner). Konsistent.
3. **Logikbrüche:**
    - **Handelsbund:** Grüßwort (121) -> Turnier (123) -> Anschlag/Auflösung (130). Konsistent.
    - **Baronsgarde:** Ausnahme Waffenrecht (127) -> Auflösungsfeier (128). Konsistent.

## Ergebnis
Keine kritischen Widersprüche in der Erzählung gefunden, jedoch strukturelle Defizite in der Verlinkung und fehlende fundamentale Artikel.

---
## [STRUKTUR] Verwaiste Boten-Artikel
**Quelle:** [Siebenwind_Wiki/04_Chronik/](file:///Users/alexandrerabe/siebenwind/7w_wiki/Siebenwind_Wiki/04_Chronik/)
**Inhalt:** Alle neu erstellten Bote-Artikel (120-130) sind verwaist, da kein zentrales Archiv-Verzeichnis existiert.
**Status:** ⚠️ Offen
**Aktion:** Erstellung eines Boten-Archivs oder Integration in [[Die_Chronik]].

---
## [GEOGRAFIE] Fehlende Orts-Stubs
**Quelle:** Diverse Boten / [[Personenregister]]
**Inhalt:** Zentrale Orte wie [[Brandenstein]], [[Falkensee]] und [[Greifenklipp]] werden verlinkt, existieren aber nicht in `/02_Geografie/`.
**Status:** ⚠️ Offen
**Aktion:** Erstellung von Basis-Stubs für die Hauptstädte und Siedlungen.

---
## [ENRICHMENT] Detail-Artikel erstellt
**Quelle:** [[Elares_Valjean]], [[Madame_Estrella]], [[Niemand]], [[Aschene_Wüste]]
**Inhalt:** Wie vom Nutzer gefordert, wurden nicht nur Register-Einträge, sondern auch die tatsächlichen Wiki-Artikel mit ihrem Wissen aus den Boten erstellt bzw. aktualisiert.
**Status:** ✅ Fixiert
**Aktion:** Keine.

---
## [LOGIK] Konflikt Endophal - Falkenstein
**Quelle:** [[Siebenwind_Bote_142]]
**Inhalt:** Erwähnung eines Wiederaufbaus in [[Lurath]] nach einem "zwischenzeitlichen Konflikt".
**Status:** ✅ Dokumentiert
**Aktion:** Überwachung zukünftiger Berichte auf Details zu diesem Krieg.

---
## [ENRICHMENT] Detail-Artikel Batch 141-145
**Quelle:** [[Yota]], [[Sae]], [[Endophal]], [[Lurath]], [[Sire_Fedral_Lavid]], [[Harlas]], [[Llewellyen]], [[Ödland]]
**Inhalt:** Umfangreiche Erweiterung der Geografie- und Persönlichkeits-Sektionen basierend auf den Boten-Daten.
**Status:** ✅ Fixiert
**Aktion:** Keine.

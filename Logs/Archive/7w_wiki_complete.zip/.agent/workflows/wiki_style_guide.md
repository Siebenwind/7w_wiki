---
description: Siebenwind Wiki Style Guide & Convention
---

# [Display Title]

**Epistemischer Status:** #perspektive

To ensure portability, consistency, and a high narrative standard across the Siebenwind Chronicles, all wiki entries must follow this strict structure. We aim for **"Roman-Qualität" (Novel Quality)**—entries should be immersive, providing context on motivations, surroundings, and social atmosphere.

## 1. YAML Frontmatter
Every file must start with a YAML frontmatter block containing exactly these fields:

```yaml
---
layout: wiki_page
title: [Display Title]
category: [Persönlichkeit | Geschichte | Erzählung | Geografie | Religion | Magie]
---
```

## 2. Heading Structure
- **H1 Header:** The first line after the frontmatter must be a Level 1 Heading (`# Title`) matching the `title` field in the YAML.
- **H2 Headers:** Use for main sections (e.g., `## Beschreibung`, `## Wirken`, `## Quellen`).

## 3. Metadata Section (Optional but recommended for NPCs)
Directly under the H1, include key-value pairs for quick scanning:
- **Titel:** [Official Title]
- **Epistemischer Status:** [#canon | #bote | #perspektive | #überlieferung]
- **Zugehörigkeit:** [Faction/Family]
- **Zeitraum:** [Active Period in n.H.]

## 5. Narrative Content (Roman-Qualität)
Don't just list facts. Describe:
- **Atmosphere:** The smell of the forge, the cold of the North, the tension in a city.
- **Motivations:** Why does an NPC act? What are their fears and goals?
- **Social Context:** How is a person viewed by their peers? What is the social status of a region?

## 4. Internal Linking
- Use standard Wiki-brackets: `[[Page_Name]]`.
- For external or source links, use absolute paths: `[Label](file:///absolute/path/to/source.html)`.

## 5. Directory Mapping
- `00_Fundament/`: Core laws and axioms.
- `01_Pantheon/`: Gods and religion.
- `02_Geografie/`: Regions and cities.
- `05_Geschichte/`: Major historical events and epochs.
- `06_Erzählungen/`: Processed player stories and lore narratives.
- `07_Persoenlichkeiten/`: NPC biographies.

---
description: Standard workflow for processing raw data into Wiki artifacts (Read-Verify-Write Loop)
---

# [Entity Name]

**Epistemischer Status:** #perspektive

This workflow defines the standard process for the Oberarchivar agent to convert raw source material into valid Siebenwind Wiki entries.

## 1. INGESTION (Lesen & Verstehen)
*   **Step:** Identify a target file or folder (e.g., `Region Galadon`).
*   **Action:**
    *   `list_dir` to see available files.
    *   `view_file` to read content.
*   **Goal:** 
    - **Narrative Extraction:** Look beyond facts. Extract character motivations, social context, environmental descriptions, and emotional undertones. Aim for "Roman-Qualität" (Novel quality).
    - **Linguistic Extraction (Skill: Linguist):** Identify new vocabulary or language fragments (e.g., `[isd]`, `[dw]`).

## 2. VERIFICATION (Kanon-Check)
*   **Step:** Validate extracted facts against the "Live Canon".
*   **Action:**
    *   `search_web` with `site:siebenwind.de [Entity Name]`.
    *   *Decision:*
        *   If Web differs from File -> Web wins (mark file data as "old/legend"). **Log this conflict in [[Konsistenzbericht_2026]].**
        *   If Web matches File -> File is confirmed.
        *   If Web is empty -> File is "Legacy Canon".

## 3. PRODUCTION (Wiki-Schmied)
*   **Step:** Create the Wiki Artifact.
*   **Action:**
    *   `write_to_file` in `/Siebenwind_Wiki/[Kategorie]/`.
    *   **Filename:** `[Kategorie]_[Name].md` (e.g., `Rasse_Orken.md`).
    *   **Format:**
        ```markdown
        ---
layout: wiki_page
        title: [Entity Name]
        category: [Category]
        status: [Canon/Legend]
        ---
        # [Title]
        
        **Epistemischer Status:** #[tag]

        ... Narrative description (motivations, atmosphere, social status) ...
        ```
*   **Requirement:** Always include a `## Verlinkte Themen` section.

## 4. LOGGING (Abschluss)
*   **Step:** Finalize task.
*   **Action:**
    *   Update `task.md` (mark item as `[x]`).
    *   Clear temporary context (focus on next item).

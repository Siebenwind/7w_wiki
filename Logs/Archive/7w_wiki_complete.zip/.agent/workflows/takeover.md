---
layout: wiki_page
description: Onboarding-Prozess für einen neuen Agenten (Takeover)
---

Du übernimmst die Leitung der Siebenwind-Wiki-Rekonstruktion. Deine Aufgabe ist es, die Arbeit deines Vorgängers nahtlos fortzusetzen und die Integrität des Kanons zu wahren.

### 1. Synchronisation & Identität
Nimm deine Rolle als **Oberarchivar** an. Deine Identität und Arbeitsweise sind in folgenden Dokumenten definiert:
- [Oberarchivar - Master Prompt.md](file:///Users/alexandrerabe/siebenwind/7w_wiki/Oberarchivar%20-%20Master%20Prompt.md)
- [Archivar - Master Prompt.md](file:///Users/alexandrerabe/siebenwind/7w_wiki/Archivar%20-%20Master%20Prompt.md)

### 2. Den Stand der Dinge erfassen
Lies die letzten Übergabedokumente im Archiv-Verzeichnis (AppData), um zu verstehen, was zuletzt getan wurde und welche Probleme offen sind:
- `handover_dossier.md` (Strategischer Überblick)
- `walkthrough.md` (Letzte technische Änderungen)

### 3. Regelwerk & Standards prüfen
Stelle sicher, dass du die aktuellen Standards für das Wiki v2.0 kennst:
- [WORKFLOW_LORE_CONSISTENCY.md](file:///Users/alexandrerabe/siebenwind/7w_wiki/WORKFLOW_LORE_CONSISTENCY.md)
- [wiki_style_guide.md](file:///Users/alexandrerabe/siebenwind/7w_wiki/.agent/workflows/wiki_style_guide.md)

### 4. Werkzeugprüfung
Prüfe, ob die Automatisierungsskripte für dich erreichbar sind:
```bash
ls .agent/skills/wiki_schmied/scripts/
```
Du solltest dort `wiki_sanitizer.py`, `wiki_link_weaver.py` und `link_cleanup.py` finden.

### 5. Erste Amtshandlung
Führe eine kurze Bestandsaufnahme durch:
1.  Prüfe die Datei `INVENTUR_QUELLEN.md` auf noch nicht verarbeitete Dokumente.
3.  **Narrative Prüfung:** Wähle einen Artikel aus `/Siebenwind_Wiki/` und prüfe, ob er die Anforderungen an die "Roman-Qualität" (Atmosphäre, Motivation, Kontext) erfüllt. Falls er zu trocken ist, markiere ihn für eine Überarbeitung.
4.  **Inkonsistenzen loggen:** Falls du Widersprüche zwischen Wiki und Quellen findest, trage diese sofort in den [Konsistenzbericht](file:///Users/alexandrerabe/siebenwind/7w_wiki/Logs/Consistency_Report_Template.md) ein.

**Melde dich bereit, wenn du den Kontext vollständig erfasst hast.**

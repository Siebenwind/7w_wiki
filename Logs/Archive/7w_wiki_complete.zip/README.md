---
layout: wiki_page
title: README
category: Sonstiges
---

# README

**Epistemischer Status:** #perspektive

**Status:** Aktiv
**System:** Google Antigravity Agentic Framework
**Ziel:** Konsolidierung von 20 Jahren Rollenspiel-Lore in ein strukturiertes Markdown-Wiki.

## 1. Projekt-Übersicht

Dieses Projekt dient der Erstellung einer zentralen Wissensdatenbank ("Wiki") für die Welt von Siebenwind. Ein KI-Agent ("Oberarchivar") liest historische Quellen, verifiziert sie gegen den aktuellen Web-Kanon und erstellt standardisierte Markdown-Dateien.

### Verzeichnisstruktur

*   **`/.agent/`**: Die "Gehirn-Konfiguration" des Antigravity-Agenten.
    *   `/skills/`: Definierte Fähigkeiten (Scanner, Web-Check, Wiki-Schreiben).
    *   `/workflows/`: Definierte Prozesse (z.B. der RVW-Loop).
*   **`/Quellen/`**: Das Rohmaterial (Alte Website-Dumps, Zeitungsartikel, Geschichten).
*   **`/Siebenwind_Wiki/`**: Das Output-Verzeichnis (Das fertige Wiki).
    *   `00_Fundament`: Götter, Magie, Zeit, **Personenregister**, **Glossar**.
    *   `01_Pantheon`: Die Götterwelt.
    *   `02_Geografie`: Länder und Orte.
    *   `03_Gesellschaft`: Völker und Stände.
    *   `04_Chronik`: Zeitgeschichte.
    *   `05_Archive`: Dokumente und Archive.
    *   `05_Geschichte`: Wichtige Ereignisse, **Zeitstrahl**.
    *   `06_Erzählungen`: Verarbeitete Spielergeschichten.
    *   `07_Persoenlichkeiten`: Biografien von Personen.
*   **`PROZESS_EVALUATION.md`**: Analyse und Optimierung der Arbeitsweise.
*   **`WORKFLOW_LORE_CONSISTENCY.md`**: Best Practices für Konsistenz (v2.0).

## 2. Nutzung des Agenten

Der Agent arbeitet autonom nach dem **RVW-Standard (Read-Verify-Write)**.

### Initialisierung
Um den Agenten in einer neuen Session zu starten, nutze den Inhalt von `Kickoff-Prompt.md`. Dies lädt alle Skills und Workflows.

### Die Skills
*   **Scanner:** Liest Quellen ein.
*   **Kanon-Wächter:** Prüft Fakten auf `siebenwind.de`.
*   **Wiki-Schmied:** Erstellt formattierte `.md` Dateien.
*   **Hilfsskripte:**
    *   `fix_nested_links.py`: Repariert verschachtelte Wiki-Links.
    *   `standardize_filenames.py`: Passt Dateinamen an die Titel-Konvention an.

### Der Prozess (RVW-Loop)
1.  **READ:** Agent liest eine Quelle (z.B. `Region Galadon.html`).
2.  **VERIFY:** Agent prüft Fakten online (z.B. "Wer ist aktuell Baron von Ravel?").
3.  **WRITE:** Agent schreibt `Region_Ravel.md` ins Wiki.

## 3. Dokumentation für Maintainer

*   **`Archivar - Master Prompt.md`**: Die Persona-Definition.
*   **`Projektdossier Siebenwind Chroniken.md`**: Die "Bibel" des Projekts (Axiome, Regeln).
*   **`INVENTUR_QUELLEN.md`**: Eine halb-automatische Liste aller verfügbaren Quelldateien.

---
*Zuletzt aktualisiert: 12.02.2026*
